<?php

function styleTheme()
{
    wp_enqueue_style('bootstrp-style', get_theme_file_uri('assets/css/bootstrap.min.css'));
    wp_enqueue_style('bootstrap-icon', get_theme_file_uri('assets/css/bootstrap-icons.min.css'));
    wp_enqueue_style('main-style', get_theme_file_uri('assets/css/style.css'));
    
    // slick
    wp_enqueue_style('slick-style', get_theme_file_uri('assets/js/slick/slick.css'));
    wp_enqueue_style('slick-theme', get_theme_file_uri('assets/js/slick/slick-theme.css'));

    // script

    wp_enqueue_script('bootstrapMJs', get_theme_file_uri('assets/js/bootstrap.min.js'), [], '1.0', true);
    wp_enqueue_script('scriptJs', get_theme_file_uri('assets/js/script.js'), [], '1.0', true);
}

add_action('wp_enqueue_scripts','styleTheme');

// Theme Support

function thmwebsidnSupport(){

    register_nav_menu( 'top_menu', 'Menu atas' );
    add_theme_support( 'custom-logo');
    add_theme_support( 'post-thumbnails');

}

add_action( 'after_setup_theme', 'thmwebsidnSupport' );

// custom widget

function CustomWidget(){
    register_sidebar([
        'name'=>'Footer Start',
        'id'=>'footer-start',
        'before_widget'=>'<div class="start">',
        'after_widget'=>'</div>'
    ]);

    register_sidebar([
        'name'=>'Footer Mid',
        'id'=>'footer-mid',
        'before_widget'=>'<div class="mid">',
        'after_widget'=>'</div>'
    ]);

    register_sidebar([
        'name'=>'Footer end',
        'id'=>'footer-end',
        'before_widget'=>'<div class="end">',
        'after_widget'=>'</div>'
    ]);
}

add_action('widgets_init','CustomWidget');

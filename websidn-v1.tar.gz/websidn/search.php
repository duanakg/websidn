<?php get_header();?>

<div class="container-fluid" id="blog-wbn">

<div class="container-lg py-4 mt-5">
    <div class="row mt-5">
        <div class="col-12 my-3 d-flex justify-content-center flex-column align-items-center">
            <?php get_search_form()?>
            <span class="text-muted">Kamu Mencari Postingan : <?php the_search_query()?></span>
        </div>
        <div class="col-12 py-5">
            <div class="row">
            <?php

    if ( have_posts() ) :
        
        while ( have_posts() ) : 
            the_post();
        ?>
                <div class="mt-3 col-lg-4 col-md-6 col-sm-12">
                    <a href="<?php the_permalink()?>" class="card-blog">
                        <div class="card">
                            <div class="card-thumb-blog">
                                <img src="<?php the_post_thumbnail_url()?>" class="card-img-top" alt="<?php the_title()?>">
                            </div>
                            <div class="card-body mt-3">
                                <h5 class="card-title text-dark"><?php the_title()?></h5>
                                <p class="card-text text-muted"><?= wp_trim_words(get_the_content(), "20", "...")?></p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php
        endwhile;
    else:
        // Tidak ada posting yang ditemukan
        echo '<span class="text-center">404! Tidak ada postingan yang ditemukan tentang ';
        the_search_query();
        echo '</span>';
        echo '<a href="';
        echo get_home_url();
        echo '"class="btn btn-wbn w-auto mx-auto my-3">Go To Home</a>';
    endif;
    wp_reset_postdata();
?>
                
            </div>
        </div>
    </div>
</div>

<div class="container-lg">
    <div class="row">
         <!-- pagination -->
    <div class="pagination col-12 d-flex justify-content-center mb-5">
        <?php
            echo paginate_links( 
                [
                    'total'=> $postGetData ->max_num_pages,
                    'prev_text'=>'<<',
                    'next_text'=>'>>'
                ]
            )
        ?>
    </div>
    </div>
</div>
</div>

<style>
    .nav-link{color:#555 !important;}
    #blog-wbn{
background-image: url('<?= get_theme_file_uri('assets/img/bg-blog-page.svg')?>');
background-position: top;
background-repeat: no-repeat;
background-size: cover;

}
</style>
<?php get_footer();?>
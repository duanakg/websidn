<?php get_header()?>
<?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post()?>
    <!-- content -->
    <div class="container-lg py-5 my-5">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <img class="img-fluid" src="<?php the_post_thumbnail_url()?>" alt="Thumbnail Blog">
            </div>
            <div class="col-lg-10 mx-auto mt-2">
                <div class="meta"><span class="text-muted">Ditulis :</span> <span class="text-dark"><?php the_author()?></span> <span class="clr2-wbn-1">|</span> <?php the_date()?> <span class="clr2-wbn-1">|</span> <?php the_tags()?></div>
                <hr/>
            </div>
            <div class="col-lg-10 mx-auto py-3" style="color:#555; line-height:2rem;">
                <h2 class="fw-bolder mb-4"><?php the_title()?></h2>
                <?php the_content() ?>
            </div>
        </div>
    </div>
    
    <?php endwhile;?>
    
<?php endif;?>

<div id="websidn" class="bg-light">
<div id="blog-wbn">
<div class="container-lg py-4">
                <div class="row">
                    <div class="col-12 text-center text-muted"><h2>Baca Juga</h2></div>
                    <div class="col-12 py-3">
                        <div class="row">
                        <?php
                // Post Limit
                $postGetData = new WP_Query( [
                    'post_type' => 'post',
                    'posts_per_page' => 3
                ] );
    
                if ( $postGetData->have_posts() ) :
                    while ( $postGetData->have_posts() ) : 
                        $postGetData->the_post();
                    ?>
                            <div class="mt-3 col-lg-4 col-md-6 col-sm-12">
                                <a href="<?php the_permalink()?>" class="card-blog">
                                    <div class="card">
                                        <div class="card-thumb-blog">
                                            <img src="<?php the_post_thumbnail_url()?>" class="card-img-top" alt="<?php the_title()?>">
                                        </div>
                                        <div class="card-body mt-3">
                                            <h5 class="card-title text-dark"><?php the_title()?></h5>
                                            <p class="card-text text-muted"><?= wp_trim_words(get_the_content(), "20", "...")?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php
                    endwhile;
                else:
                    // Tidak ada posting yang ditemukan
                    echo 'Tidak ada posting yang ditemukan.';
                endif;
                wp_reset_postdata();
            ?>
                            
                        </div>
                    </div>
                </div>
            </div>
</div>
</div>

            <style>
                .nav-link{color:#555 !important;}
            </style>

<?php get_footer()?>
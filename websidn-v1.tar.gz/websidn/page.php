<?php get_header();?>
<h3>page</h3>
<?php get_footer();?>
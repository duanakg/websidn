<?php
/**
 * Template Name: 404
 * 
 */
?>

<?php get_header();?>

    <div class="container-lg">
        <div class="row">
            <div class="col-12 text-center d-flex flex-column justify-content-center align-items-center" style="height:50vh;">
                <h1 class="text-muted">404! Not Found</h1>
                <a href="<?= site_url('')?>" class="btn btn-wbn my-5">Go To Home</a>
            </div>
        </div>
    </div>

<style>
    .nav-link{color:#555 !important;}
</style>
<?php get_footer();?>
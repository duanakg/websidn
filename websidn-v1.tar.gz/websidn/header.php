<!DOCTYPE html>
<html lang="en" style="margin-top:0 !important;">
<head>
	<meta charset="UTF-8">
	<title>Websidn <?php wp_title( '|', true, 'left');?></title>
	<meta name="description" content="Websidn Jasa Pembuatan Website Lampung Terbaik Profesional. Harga Murah Terjangkau.
	">
	<meta name="keywords" content="Jasa Pembuatan Website, Jasa Pembuatan Website Murah, Jasa Pembuatan Website Harga Terjangkau, Jasa Pembuatan Website Company Profile, Jasa Pembuatan Website Landing Page, Jasa Pembuatan Website Wordpress, Jasa Pembuatan Website Custom, Jasa Design Feed, Jasa Pembuatan Website Lampung Terdekat, Jasa Pembuatan Website Terbaik Profesional">
	<meta name="author" content="Themexriver">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/icon-websidn.svg" type="image/x-icon">
	<?php wp_head()?>
</head>
<body style="overflow-x: hidden;">
    <div class="container-lg">

		<!-- navbar -->
		<div id="navbar-websidn" class="container-fluid p-0">
			<div class="container-lg">
				<nav class="navbar navbar-expand-lg navbar-light">
					<div class="container-fluid">
						<div class="navbar-brand-websidn">
							<?php
									if (function_exists('the_custom_logo')) {
										the_custom_logo();
									}
								?>
						</div>
						<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
						</button>
						<div class="collapse navbar-collapse" id="navbarNav">
						<ul class="navbar-nav ms-auto mb-2 mb-lg-0">
							<li class="nav-item">
							<a class="nav-link clr-wbn-1" href="<?= site_url('') ?>">Home</a>
							</li>
							<li class="nav-item">
							<a class="nav-link clr-wbn-1" href="<?= site_url('#about-wbn') ?>">About Us</a>
							</li>
							<li class="nav-item">
							<a class="nav-link clr-wbn-1" href="<?= site_url('#tc-wbn') ?>">Testimonial</a>
							</li>
							<li class="nav-item">
							<a class="nav-link clr-wbn-1" href="<?= site_url('#price-wbn') ?>">Pricing</a>
							</li>
							<li class="nav-item">
							<a class="nav-link clr-wbn-1" href="<?= site_url('blog') ?>">Blog</a>
							</li>
							<li class="nav-item">
							<a class="nav-link clr-wbn-1" href="<?= site_url('contact') ?>">Contact</a>
							</li>
							<li class="nav-item dropdown d-none">
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
								Dropdown
							</a>
							<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
								<li><a class="dropdown-item" href="#">Action</a></li>
								<li><a class="dropdown-item" href="#">Another action</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="#">Something else here</a></li>
							</ul>
							</li>
						</ul>
						</div>
					</div>
				</nav>
			</div>
		</div>

		<script>
			let bnav = document.getElementById('navbarNav');
			let mma = bnav.querySelector('ul');

			mma.classList.add('nvscrl');
			bnav.querySelector('ul').classList.add('navbar-nav');
			bnav.querySelectorAll('.navbar-nav li a').forEach(a => {
				a.classList.add('text-white');
				window.addEventListener('scroll', ()=>{
					if (window.pageYOffset > 50) {
						document.getElementById('navbar-websidn').classList.add('bg-white')
						mma.classList.remove('nvscrl')
						a.classList.remove('text-white');
					}else{
						a.classList.add('text-white');
						document.getElementById('navbar-websidn').classList.remove('bg-white')
						mma.classList.add('nvscrl')
					}
				})
			});

			let nw=document.querySelector('.navbar-brand-websidn .custom-logo');
			nw.style.width='150px';
			nw.style.height='unset';
		</script>

	</div>
    <div id="websidn" class="container-fluid p-0">

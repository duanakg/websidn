<?php
/**
 * Template Name: About
 * 
 */
?>

<?php get_header();?>

        <!-- about -->
        <div id="about-wbn" class="container-lg py-5 mt-5">
            <div class="row mt-5">
                <div class="col-12 text-center text-muted my-3"><h2 class="clr-wbn-1">About Us WEBSIDN</h2></div>
                <div class="col-12 pt-5 mb-3 hanim1">
                    <div class="row">
                        <div class="col-5 mx-auto d-flex justify-content-center mb-3">
                        <img src="<?= get_theme_file_uri('assets/img/bg-about.png')?>" alt="..." class="img-fluid">
                        </div>
                        <div class="col-lg-12 mb-3">
                            <p class="text-muted">
                            Kami adalah sebuah agensi digital yang berkomitmen untuk membantu UMKM (Usaha Mikro, Kecil, dan Menengah) dalam menghadirkan keberadaan online yang profesional dan efektif. Dengan fokus utama pada pengembangan website, tim ahli kami merancang dan membangun solusi digital yang sesuai dengan kebutuhan unik setiap UMKM. Melalui desain yang menarik, fungsionalitas yang optimal, serta pengalaman pengguna yang baik, kami membantu UMKM untuk meningkatkan visibilitas online mereka, dan berusaha mengoptimalkan kehadiran mereka di ranah digital. Dengan pendekatan yang berbasis pada pemahaman mendalam terhadap industri dan target pasar UMKM, kami menawarkan solusi yang terjangkau dan terukur untuk membantu mereka tumbuh dan berkembang dalam era digital ini.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 text-center text-muted my-3"><h4>Portfolio</h4></div>
                <div class="col-12">
                    <div class="row">
                        <div class="col-lg-12" id="nav-port">
                            <div class="d-flex justify-content-center my-3">
                                <span class="bg-wbn2 py-2 px-4">All</span>
                                <span data-port="web" class="py-2 px-4">Website</span>
                                <span data-port="sosmed" class="py-2 px-4">Social Media</span>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="row" id="box-port">
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-1.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Sistem Informasi</h5>
                                        <i>Simtaru Lampura</i>
                                        <a href="https://simtaru.lampungutarakab.go.id/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-5.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Company Profile</h5>
                                        <i>Balai Guru Penggerak</i>
                                        <a href="https://bgplampung.kemdikbud.go.id/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-2.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Website Pemesanan Travel</h5>
                                        <i>CV. Rama Trans Travel Lampung</i>
                                        <a href="https://ramatranzlampung.com/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-4.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Company Profile</h5>
                                        <i>SMA PERINTIS 2 BANDAR LAMPUNG</i>
                                        <a href="https://www.smaperintis2.sch.id/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-3.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Toko Online</h5>
                                        <i>Rumah Sanitary</i>
                                        <a href="https://rumahsanitary.com/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="sosmed">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/sosmed-1.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Social Media</h5>
                                        <i>Newus Technology</i>
                                        <a href="<?= get_theme_file_uri("assets/img/sosmed-1.jpg") ?>" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <script>
            let navPort=document.getElementById('nav-port'),
                boxPort=document.getElementById('box-port'),
                wbnPort=boxPort.querySelectorAll('.wbn-port');

                navPort.querySelectorAll('span').forEach(a=>{
                    a.addEventListener('click', ()=>{
                        document.querySelector('#about-wbn .bg-wbn2').classList.remove('bg-wbn2');
                        a.classList.add('bg-wbn2');
                    wbnPort.forEach(b=>{
                            let valueItem=b.getAttribute('data-port');
                            let valueSpan=a.getAttribute('data-port');
                            if(valueItem === valueSpan || a.textContent === "All"){
                                b.classList.remove('d-none')
                                b.classList.add('active-port')
                                setTimeout(() => {
                                    b.classList.remove('active-port')
                                }, 500);
                            }else{
                                b.classList.add('d-none')
                            }
                        })
                    })
                })

        </script>
        <style>
            .nav-link{color:#555 !important;}
        </style>
        
<?php get_footer();?>
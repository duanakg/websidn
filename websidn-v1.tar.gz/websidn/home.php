<?php 
/*

* Template Name: Home

*/
?>

<?php get_header() ?>

<!-- jquery -->
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/js/jquery.js"></script>

        <!-- header -->
        <div id="header-wbn" class="container-fluid p-0 header d-flex justify-content-center align-items-center mb-2">
           <div class="container-lg">
           <div class="row m-auto lg-px-5">
                <div class="anim1 col-lg-6 col-md-12 d-flex justify-content-center order-lg-1">
                    <img src="<?= get_theme_file_uri('assets/img/laptop.png')?>" alt="..." class="img-fluid">
                </div>
                <div class="anim1 col-lg-6 my-3">
                    <h1 class="clr-wbn-1">Digital Agency</h1>
                    <p class="text-white">
                    Onlinekan bisnismu dengan desain yang menarik, fitur dan teknologi website.
                    </p>
                    <a href="#price-wbn" class="btn btn-wbn">Get Started</a>
                </div>
            </div>
           </div>
        </div>

        <!-- about -->
        <div id="about-wbn" class="container-lg py-5">
            <div class="row">
                <div class="col-12 text-center text-muted my-3"><h2>About Us</h2></div>
                <div class="col-12 pt-5 mb-3 hanim1">
                    <div class="row d-flex justify-content-between">
                        <div class="col-lg-5 col-md-5 col-sm-8 mx-auto d-flex justify-content-center mb-3">
                            <img src="<?= get_theme_file_uri('assets/img/bg-about.png')?>" alt="..." class="img-fluid">
                        </div>
                        <div class="col-lg-6 d-flex flex-column align-items-center justify-content-center mb-3">
                            <div>
                                <h4 class="clr-wbn-1">WEBSIDN</h4>
                                <p class="text-muted">
                                Kami adalah sebuah agensi digital yang berkomitmen untuk membantu UMKM (Usaha Mikro, Kecil, dan Menengah) dalam menghadirkan keberadaan online yang profesional dan efektif. Dengan fokus utama pada pengembangan website, tim ahli kami merancang dan membangun solusi digital yang sesuai dengan kebutuhan unik setiap UMKM. Melalui desain yang .....
                                </p>
                                <a href="<?= site_url( 'about' )?>" class="btn btn-wbn">Learn More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 text-center text-muted my-3"><h4>Portfolio</h4></div>
                <div class="col-12">
                    <div class="row">
                        <div class="col-lg-12" id="nav-port">
                            <div class="d-flex justify-content-center my-3">
                                <span class="bg-wbn2 py-2 px-4">All</span>
                                <span data-port="web" class="py-2 px-4">Website</span>
                                <span data-port="sosmed" class="py-2 px-4">Social Media</span>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="row" id="box-port">
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-1.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Sistem Informasi</h5>
                                        <i>Simtaru Lampura</i>
                                        <a href="https://simtaru.lampungutarakab.go.id/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-5.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Company Profile</h5>
                                        <i>Balai Guru Penggerak</i>
                                        <a href="https://bgplampung.kemdikbud.go.id/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-2.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Website Pemesanan Travel</h5>
                                        <i>CV. Rama Trans Travel Lampung</i>
                                        <a href="https://ramatranzlampung.com/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-4.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Company Profile</h5>
                                        <i>SMA PERINTIS 2 BANDAR LAMPUNG</i>
                                        <a href="https://www.smaperintis2.sch.id/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="web">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/website-3.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Toko Online</h5>
                                        <i>Rumah Sanitary</i>
                                        <a href="https://rumahsanitary.com/" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6 mt-3 wbn-port" data-port="sosmed">
                                    <div class="card position-relative overflow-hidden">
                                    <img src="<?= get_theme_file_uri("assets/img/sosmed-1.jpg") ?>" class="card-img-top" alt="Landing Page">
                                    <div class="card-body position-absolute text-center d-flex flex-column align-items-center justify-content-center">
                                        <h5 class="card-title">Social Media</h5>
                                        <i>Newus Technology</i>
                                        <a href="<?= get_theme_file_uri("assets/img/sosmed-1.jpg") ?>" target="_blank" class="btn btn-wbn">View</a>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <script>
            let navPort=document.getElementById('nav-port'),
                boxPort=document.getElementById('box-port'),
                wbnPort=boxPort.querySelectorAll('.wbn-port');

                navPort.querySelectorAll('span').forEach(a=>{
                    a.addEventListener('click', ()=>{
                        document.querySelector('#about-wbn .bg-wbn2').classList.remove('bg-wbn2');
                        a.classList.add('bg-wbn2');
                    wbnPort.forEach(b=>{
                            let valueItem=b.getAttribute('data-port');
                            let valueSpan=a.getAttribute('data-port');
                            if(valueItem === valueSpan || a.textContent === "All"){
                                b.classList.remove('d-none')
                                b.classList.add('active-port')
                                setTimeout(() => {
                                    b.classList.remove('active-port')
                                }, 500);
                            }else{
                                b.classList.add('d-none')
                            }
                        })
                    })
                })

        </script>

        <!-- why choose us -->
        <div id="wcu-wbn" class="container-fluid p-0 bg-wbn2 text-center">
            <div class="container-lg py-4">
                <div class="row">
                    <div class="col-12 text-center text-muted my-3"><h2>Why Choose Us</h2></div>
                    <div class="col-12 mb-3">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 mt-3">
                                <div class="border border-1 rounded border-secondary p-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="bi bi-cash-coin clr-wbn-1" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M11 15a4 4 0 1 0 0-8 4 4 0 0 0 0 8m5-4a5 5 0 1 1-10 0 5 5 0 0 1 10 0"/>
                                <path d="M9.438 11.944c.047.596.518 1.06 1.363 1.116v.44h.375v-.443c.875-.061 1.386-.529 1.386-1.207 0-.618-.39-.936-1.09-1.1l-.296-.07v-1.2c.376.043.614.248.671.532h.658c-.047-.575-.54-1.024-1.329-1.073V8.5h-.375v.45c-.747.073-1.255.522-1.255 1.158 0 .562.378.92 1.007 1.066l.248.061v1.272c-.384-.058-.639-.27-.696-.563h-.668zm1.36-1.354c-.369-.085-.569-.26-.569-.522 0-.294.216-.514.572-.578v1.1zm.432.746c.449.104.655.272.655.569 0 .339-.257.571-.709.614v-1.195z"/>
                                <path d="M1 0a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h4.083q.088-.517.258-1H3a2 2 0 0 0-2-2V3a2 2 0 0 0 2-2h10a2 2 0 0 0 2 2v3.528c.38.34.717.728 1 1.154V1a1 1 0 0 0-1-1z"/>
                                <path d="M9.998 5.083 10 5a2 2 0 1 0-3.132 1.65 6 6 0 0 1 3.13-1.567"/>
                                </svg>
                                <h5 class="my-3">Harga Terjangkau</h5>
                                <p class="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis reprehenderit, exercitationem ea inventore</p>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 mt-3">
                                <div class="border border-1 rounded border-secondary p-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="bi bi-code-slash clr-wbn-1" viewBox="0 0 16 16">
                                <path d="M10.478 1.647a.5.5 0 1 0-.956-.294l-4 13a.5.5 0 0 0 .956.294zM4.854 4.146a.5.5 0 0 1 0 .708L1.707 8l3.147 3.146a.5.5 0 0 1-.708.708l-3.5-3.5a.5.5 0 0 1 0-.708l3.5-3.5a.5.5 0 0 1 .708 0m6.292 0a.5.5 0 0 0 0 .708L14.293 8l-3.147 3.146a.5.5 0 0 0 .708.708l3.5-3.5a.5.5 0 0 0 0-.708l-3.5-3.5a.5.5 0 0 0-.708 0"/>
                                </svg>
                                <h5 class="my-3">Proses Development Cepat</h5>
                                <p class="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis reprehenderit, exercitationem ea inventore</p>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 mt-3">
                                <div class="border border-1 rounded border-secondary p-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="bi bi-gear clr-wbn-1" viewBox="0 0 16 16">
                                <path d="M8 4.754a3.246 3.246 0 1 0 0 6.492 3.246 3.246 0 0 0 0-6.492M5.754 8a2.246 2.246 0 1 1 4.492 0 2.246 2.246 0 0 1-4.492 0"/>
                                <path d="M9.796 1.343c-.527-1.79-3.065-1.79-3.592 0l-.094.319a.873.873 0 0 1-1.255.52l-.292-.16c-1.64-.892-3.433.902-2.54 2.541l.159.292a.873.873 0 0 1-.52 1.255l-.319.094c-1.79.527-1.79 3.065 0 3.592l.319.094a.873.873 0 0 1 .52 1.255l-.16.292c-.892 1.64.901 3.434 2.541 2.54l.292-.159a.873.873 0 0 1 1.255.52l.094.319c.527 1.79 3.065 1.79 3.592 0l.094-.319a.873.873 0 0 1 1.255-.52l.292.16c1.64.893 3.434-.902 2.54-2.541l-.159-.292a.873.873 0 0 1 .52-1.255l.319-.094c1.79-.527 1.79-3.065 0-3.592l-.319-.094a.873.873 0 0 1-.52-1.255l.16-.292c.893-1.64-.902-3.433-2.541-2.54l-.292.159a.873.873 0 0 1-1.255-.52zm-2.633.283c.246-.835 1.428-.835 1.674 0l.094.319a1.873 1.873 0 0 0 2.693 1.115l.291-.16c.764-.415 1.6.42 1.184 1.185l-.159.292a1.873 1.873 0 0 0 1.116 2.692l.318.094c.835.246.835 1.428 0 1.674l-.319.094a1.873 1.873 0 0 0-1.115 2.693l.16.291c.415.764-.42 1.6-1.185 1.184l-.291-.159a1.873 1.873 0 0 0-2.693 1.116l-.094.318c-.246.835-1.428.835-1.674 0l-.094-.319a1.873 1.873 0 0 0-2.692-1.115l-.292.16c-.764.415-1.6-.42-1.184-1.185l.159-.291A1.873 1.873 0 0 0 1.945 8.93l-.319-.094c-.835-.246-.835-1.428 0-1.674l.319-.094A1.873 1.873 0 0 0 3.06 4.377l-.16-.292c-.415-.764.42-1.6 1.185-1.184l.292.159a1.873 1.873 0 0 0 2.692-1.115z"/>
                                </svg>
                                <h5 class="my-3">Service</h5>
                                <p class="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis reprehenderit, exercitationem ea inventore</p>
                                </div>
                            </div>
    
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pricing -->
        <div id="price-wbn" class="container-lg py-5">
            <div class="row mt-3">
                <div class="col-lg-12" id="nav-price">
                    <div class="d-flex justify-content-center my-3">
                        <span data-price="website" class="bg-wbn2 py-2 px-4">Website</span>
                        <span data-price="sosmed" class="py-2 px-4">Social Media</span>
                    </div>
                </div>

                <div class="item-price" data-price="website">
                    <div class="col-12 text-center text-muted mt-3"><h2>Pricing Website</h2></div>
                    <div class="col-12 py-3">
                        <div class="row">
                            <div class="col-lg-3 col-md-4 col-sm-10 mt-3 mx-auto">
                                <div class="card text-center">
                                    <div class="card-body bg2-wbn">
                                        <h5 class="card-title text-white">BASIC</h5>
                                    </div>
                                    <div class="price-wbn py-2">
                                    <p class="card-text m-0 text-muted">Cocok untuk pemula</p>
                                    <h4>Rp 300.000</h4>
                                    </div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">Subdomain (nama.websidn.com)</li>
                                        <li class="list-group-item">1 Halaman Static</li>
                                        <li class="list-group-item">Unlimited Bandwidth</li>
                                        <li class="list-group-item">Support Order Via Link/WA</li>
                                        <li class="list-group-item">Free Revisi 1 Kali</li>
                                    </ul>
                                    <div class="card-body">
                                        <a href="#" class="btn btn2-wbn">Order Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 col-sm-10 mt-3 mx-auto">
                                <div class="card text-center">
                                    <div class="card-body bg-wbn">
                                        <h5 class="card-title text-white">MEDIUM</h5>
                                    </div>
                                    <div class="price-wbn py-2">
                                    <p class="card-text m-0 text-muted">Cocok untuk
                                    personal branding anda</p>
                                    <h4>Rp 500.000</h4>
                                    </div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">Domain .xyz / .my.id /  .biz.id</li>
                                        <li class="list-group-item">Max 5 Halaman</li>
                                        <li class="list-group-item">Unlimited Bandwidth</li>
                                        <li class="list-group-item">Support Order Via Link/WA</li>
                                        <li class="list-group-item">Free Revisi 3 Kali</li>
                                        <li class="list-group-item">Email Domain (nama@domain.com)</li>
                                    </ul>
                                    <div class="card-body">
                                        <a href="#" class="btn btn-wbn">Order Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 col-sm-10 mt-3 mx-auto">
                                <div class="card text-center">
                                    <div class="card-body bg2-wbn">
                                        <h5 class="card-title text-white">PRO</h5>
                                    </div>
                                    <div class="price-wbn py-2">
                                    <p class="card-text m-0 text-muted">Cocok untuk bisnis menengah</p>
                                    <h4>Rp 1.000.000</h4>
                                    </div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">Domain .com</li>
                                        <li class="list-group-item">Max 10 Halaman</li>
                                        <li class="list-group-item">Unlimited Bandwidth</li>
                                        <li class="list-group-item">Support Order Via Link/WA</li>
                                        <li class="list-group-item">Free Revisi 3 Kali</li>
                                        <li class="list-group-item">Email Domain (nama@domain.com)</li>
                                        <li class="list-group-item">Support Blog</li>
                                    </ul>
                                    <div class="card-body">
                                        <a href="#" class="btn btn2-wbn">Order Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 col-sm-10 mt-3 mx-auto">
                                <div class="card text-center">
                                    <div class="card-body bg-wbn">
                                        <h5 class="card-title text-white">CUSTOM</h5>
                                    </div>
                                    <div class="price-wbn py-2">
                                    <p class="card-text m-0 text-muted">Cocok untuk anda yang
                                    memiliki usaha mengah ke atas</p>
                                    <h4>Negotiable</h4>
                                    </div>
                                    <!-- <ul class="list-group list-group-flush">
                                        <li class="list-group-item">Domain</li>
                                        <li class="list-group-item">Hosting</li>
                                        <li class="list-group-item">1 Halaman</li>
                                    </ul> -->
                                    <div class="card-body">
                                        <a href="#" class="btn btn-wbn">Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 py-3"><a target="_blank" href="<?= site_url('demo')?>" class="btn btn-wbn d-none">Demo Themes</a></div>
                </div>
                <div class="item-price d-none" data-price="sosmed">
                    <div class="col-12 text-center text-muted mt-3"><h2>Pricing Feed IG</h2></div>
                            <div class="col-12 py-3">
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 col-sm-10 mt-3 mx-auto">
                                        <div class="card text-center">
                                            <div class="card-body bg2-wbn">
                                                <h5 class="card-title text-white">BASIC</h5>
                                            </div>
                                            <div class="price-wbn py-2">
                                            <p class="card-text m-0 text-muted">Untuk 30 Hari</p>
                                            <h4>Rp 350.000</h4>
                                            </div>
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item">Design 15 Feed</li>
                                                <li class="list-group-item">Caption + Copywriting</li>
                                                <li class="list-group-item">Revisi 2 Kali</li>
                                                <li class="list-group-item">Desain Kreatif</li>
                                                <li class="list-group-item">Free Riset Hastag</li>
                                            </ul>
                                            <div class="card-body">
                                                <a href="#" class="btn btn2-wbn">Order Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-10 mt-3 mx-auto">
                                        <div class="card text-center">
                                            <div class="card-body bg-wbn">
                                                <h5 class="card-title text-white">MEDIUM</h5>
                                            </div>
                                            <div class="price-wbn py-2">
                                            <p class="card-text m-0 text-muted">Untuk 30 Hari</p>
                                            <h4>Rp 650.000</h4>
                                            </div>
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item">Design 30 Feed</li>
                                                <li class="list-group-item">Caption + Copywriting</li>
                                                <li class="list-group-item">Revisi 2 Kali</li>
                                                <li class="list-group-item">Desain Kreatif</li>
                                                <li class="list-group-item">Free Riset Hastag</li>
                                            </ul>
                                            <div class="card-body">
                                                <a href="#" class="btn btn-wbn">Order Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-4 col-sm-10 mt-3 mx-auto">
                                        <div class="card text-center">
                                            <div class="card-body bg2-wbn">
                                                <h5 class="card-title text-white">PRO</h5>
                                            </div>
                                            <div class="price-wbn py-2">
                                            <p class="card-text m-0 text-muted">Untuk 30 Hari</p>
                                            <h4>Rp 1.500.000</h4>
                                            </div>
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item">Design 60 Feed</li>
                                                <li class="list-group-item">Caption + Copywriting</li>
                                                <li class="list-group-item">Revisi 2 Kali</li>
                                                <li class="list-group-item">Desain Kreatif</li>
                                                <li class="list-group-item">Free Riset Hastag</li>
                                            </ul>
                                            <div class="card-body">
                                                <a href="#" class="btn btn2-wbn">Order Now</a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                    </div> 
                </div>

            </div>
        </div>

        <script>
            let navprice=document.getElementById('nav-price');
            let wbnprice=document.querySelectorAll('#price-wbn .item-price');

            wbnprice.forEach(b=>{
                            let valueItem=b.getAttribute('data-price');

                if (valueItem === 'website') {
                        b.querySelectorAll('.card').forEach(d=>{
                            d.querySelector('a').href="https://api.whatsapp.com/send/?phone=6287898644177&text=%2AHi%2CAdmin+Saya+Mau+Order%2A%0A%0A+Jasa+Website+Dengan+Paket+"+d.querySelector('.card-title').textContent;
                        })
                    }else{
                        b.querySelectorAll('.card').forEach(d=>{
                            d.querySelector('a').href="https://api.whatsapp.com/send/?phone=6287898644177&text=%2AHi%2CAdmin+Saya+Mau+Order%2A%0A%0A+Jasa+Social+Media+Dengan+Paket+"+d.querySelector('.card-title').textContent;
                        })
                    }
                })

                navprice.querySelectorAll('span').forEach(a=>{
                    a.addEventListener('click', ()=>{
                        document.querySelector('#price-wbn .bg-wbn2').classList.remove('bg-wbn2');
                        a.classList.add('bg-wbn2');
                    wbnprice.forEach(b=>{
                            let valueItem=b.getAttribute('data-price');
                            let valueSpan=a.getAttribute('data-price');

                            if(valueItem === valueSpan){
                                b.classList.remove('d-none')
                                b.querySelectorAll('.card').forEach(c=>{
                                    c.classList.add('active-price')
                                setTimeout(() => {
                                    c.classList.remove('active-price')
                                }, 500);
                                })
                            }else{
                                b.classList.add('d-none')
                            }
                        })
                    })
                })

        </script>

        <!-- Testimonial & client -->
        <div id="tc-wbn" class="container-fluid p-0 bg-wbn2" style="overflow-x: hidden;">
            <div class="container-lg py-5">
                <div class="row">
                    <div class="col-12 text-center text-muted my-3"><h2>Testimonial</h2></div>
                    <div class="col-12 pt-5">
                        <div class="row">
    
                            <!-- testimoni -->
                            <div class="col-12 track-testimoni">
                                <div class="row text-center">
                                    <div class="col-12">
                                        <div class="quote-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="bi bi-quote clr2-wbn-1" viewBox="0 0 16 16">
                                            <path d="M12 12a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1h-1.388q0-.527.062-1.054.093-.558.31-.992t.559-.683q.34-.279.868-.279V3q-.868 0-1.52.372a3.3 3.3 0 0 0-1.085.992 4.9 4.9 0 0 0-.62 1.458A7.7 7.7 0 0 0 9 7.558V11a1 1 0 0 0 1 1zm-6 0a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1H4.612q0-.527.062-1.054.094-.558.31-.992.217-.434.559-.683.34-.279.868-.279V3q-.868 0-1.52.372a3.3 3.3 0 0 0-1.085.992 4.9 4.9 0 0 0-.62 1.458A7.7 7.7 0 0 0 3 7.558V11a1 1 0 0 0 1 1z"/>
                                            </svg>
                                        </div>
                                        <p class="text-muted">Agency Digital Jasa Pembuatan Website Terbaik Di Lampung</p>
                                        <div class="tc-thumb"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/2.png" alt=""></div>
                                        <h5 class="clr-wbn-1">CV. Rama Trans Travel Lampung</h5>
                                    </div>
                                </div>
                                <div class="row text-center">
                                    <div class="col-12">
                                        <div class="quote-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="bi bi-quote clr2-wbn-1" viewBox="0 0 16 16">
                                            <path d="M12 12a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1h-1.388q0-.527.062-1.054.093-.558.31-.992t.559-.683q.34-.279.868-.279V3q-.868 0-1.52.372a3.3 3.3 0 0 0-1.085.992 4.9 4.9 0 0 0-.62 1.458A7.7 7.7 0 0 0 9 7.558V11a1 1 0 0 0 1 1zm-6 0a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1H4.612q0-.527.062-1.054.094-.558.31-.992.217-.434.559-.683.34-.279.868-.279V3q-.868 0-1.52.372a3.3 3.3 0 0 0-1.085.992 4.9 4.9 0 0 0-.62 1.458A7.7 7.7 0 0 0 3 7.558V11a1 1 0 0 0 1 1z"/>
                                            </svg>
                                        </div>
                                        <p class="text-muted">Pokoknya Rekomendasi Jasa Pembuatan Website Harga Terjangkau Lampung</p>
                                        <div class="tc-thumb"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/3.png" alt=""></div>
                                        <h5 class="clr-wbn-1">Rumah Sanitary</h5>
                                    </div>
                                </div>
                            </div>
    
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid bg-white">
                <div class="row">
                      <!-- client -->
                      <div class="col-lg-12">
                                <div class="row track-klient-logo">
                                    <div class="img-client col-lg-12 py-3">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/1.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/2.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/3.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/4.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/5.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/6.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/7.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/8.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/9.png" alt="client" width="100">
                                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/img/client/10.png" alt="client" width="100">
                                    </div>
                                </div>
                            </div>  
                </div>
            </div>
        </div>

        <!-- kontak -->
        <div id="kontak-wbn" class="container-fluid pt-5">
            <div class="row">
                <div class="col-12 text-center clr2-wbn-1 my-3"><h2>Get In Touch</h2></div>
                <div class="col-12 py-5">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <h5 class="text-dark fw-bolder">Konsultasi ?</h5>
                            <p class="text-muted">Mari, Kita Bicarakan Project Menakjubkan Selanjutnya!</p>
                            <a target="_blank" href="https://api.whatsapp.com/send/?phone=6287898644177&text=%2AHi%2CAdmin+Saya+Mau+Konsultasi%2A%0A%0A+Jasa+Di+Websidn" class="btn btn-wbn">Hubungi Kami</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

         <!-- Blog -->
         <div id="blog-wbn" class="container-lg py-5">
            <div class="row">
                <div class="col-12 text-center text-muted my-3"><h2>Latest Blogs</h2></div>
                <div class="col-12 py-5">
                    <div class="row">
                    <?php
                    // Post Limit
                    $arrP = array(
                        'post_type' => 'post',
                        'posts_per_page' => 6,
                        'post_status' => 'publish',
                        'category_name'=>'post,	uncategorized',
                    );
                    $postGetData = new WP_Query( $arrP );
                    if ( $postGetData->have_posts() ) :
                        while ( $postGetData->have_posts() ) : $postGetData->the_post();
                        ?>
                        <div class="mt-3 col-lg-4 col-md-6 col-sm-12">
                            <a href="<?php the_permalink()?>" class="card-blog">
                                <div class="card">
                                    <div class="card-thumb-blog">
                                        <img src="<?php the_post_thumbnail_url()?>" class="card-img-top" alt="<?php the_title()?>">
                                    </div>
                                    <div class="card-body mt-3">
                                        <h5 class="card-title text-dark"><?php the_title()?></h5>
                                        <p class="card-text text-muted"><?= wp_trim_words(get_the_content(), "20", "...")?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php
                        endwhile;
                    else:
                        // Tidak ada posting yang ditemukan
                        echo 'Tidak ada posting yang ditemukan.';
                    endif;
                    wp_reset_postdata();
                ?>
                        <div class="col-12 mt-5 text-center">
                            <a href="<?= site_url('blog')?>" class="btn btn-wbn">More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  

            <!-- slick -->
            <script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());  ?>/assets/js/slick/slick.min.js"></script>

            <script>
                $(document).ready(function(){
                $('.track-klient-logo .img-client').slick({
                slidesToShow: 10,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 500,
                responsive: [
                    {
                        breakpoint: 3000,
                        settings: {
                        slidesToShow: 5,
                        slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 992,
                        settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        }
                    },
                     {
                        breakpoint: 576,
                        settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        }
                    },
                    ]
                });

                $('.track-testimoni').slick({
                dots:true,
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: false,
                autoplaySpeed: 2000,
                });

            });

            </script>

            <script>
                window.addEventListener('scroll', ()=>{
                    let sA=document.getElementById('about-wbn');
                    if(window.pageYOffset > sA.offsetHeight/pageYOffset * 100 ){
                        sA.querySelector('.hanim1').classList.add('anim1')
                        // sA.querySelector('.hanim2').classList.add('anim1')
                    }
                })
            </script>

        </div>
    
<?php get_footer();?>


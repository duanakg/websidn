<?php
/**
 * Template Name: Kontak
 * 
 */
?>

<?php get_header();?>

<!-- kontak -->
<div id="kontak-wbn" class="container-fluid pt-5 d-flex flex-column justify-content-center align-items-center" style="min-height:500px;">
    <div class="row">
        <div class="col-12 text-center clr2-wbn-1 my-3"><h2>Get In Touch</h2></div>
        <div class="col-12 py-5">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h5 class="text-dark fw-bolder">Konsultasi ?</h5>
                    <p class="text-muted">Mari, Kita Bicarakan Project Menakjubkan Selanjutnya!</p>
                    <a target="_blank" href="https://api.whatsapp.com/send/?phone=6287898644177&text=%2AHi%2CAdmin+Saya+Mau+Konsultasi%2A%0A%0A+Jasa+Di+Websidn" class="btn btn-wbn">Hubungi Kami</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .nav-link{color:#555 !important;}
</style>

<?php get_footer();?>
	<div class="container-fluid py-3 bg-light">
		<div class="container-lg">
			<div class="row">
				<div class="col-12">
					<h4 class="text-muted pb-3 text-center">Tags Post Popular</h4>
					<div class="d-flex no-wrap w-100" style="overflow-x:auto;">
						<?php
						$tags = get_tags();
						if ($tags) {?>

						<?php
							foreach ($tags as $tag) {
								echo '<a class="btn clr-wbn-1 border px-2 me-3 tags" href="' . get_tag_link( $tag->term_id ) . '" 
								title="' . sprintf( __( "View all posts in %s" ), $tag->name ) . '" ' . '>' . $tag->name.'</a>';
						}
						?>
						<?php }?>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
	<div class="container-lg py-3">
		<div class="row">
			<div class="col-lg-6 col-md-12">
				<div class="detail-footer">
					<div class="logo-foot mb-3">
					<?php
									if (function_exists('the_custom_logo')) {
										the_custom_logo();
									}
								?>
					</div>
					<div class="detail-foot">
						<p class="text-muted">
						Kami adalah sebuah agensi digital yang berkomitmen untuk membantu UMKM (Usaha Mikro, Kecil, dan Menengah) dalam menghadirkan keberadaan online yang profesional dan efektif.
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-12">
				<div class="list-group">
					<div class="list-group-item border-0"><h5 class="text-muted">Company</h5></div>
					<a href="<?= site_url('#about-wbn') ?>" class="list-group-item list-group-item-action border-0 clr-wbn-1">About Us</a>
					<a href="<?= site_url('career') ?>" class="list-group-item list-group-item-action border-0 clr-wbn-1">Career</a>
					<a href="<?= site_url('blog') ?>" class="list-group-item list-group-item-action border-0 clr-wbn-1">Blog</a>
				</div>
			</div>
			<div class="col-lg-12 col-md-12">
				<div class="list-group">
					<div class="list-group-item border-0"><h5 class="text-muted">Maps</h5></div>
					<div class="maps">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3971.832682421464!2d105.27250479999996!3d-5.442360099999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e40dbff9e63c95f%3A0x6bd3c394975d3800!2sCV.%20NEWUS%20TEKNOLOGI!5e0!3m2!1sid!2sid!4v1711514995468!5m2!1sid!2sid" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid py-4 bg-wbn">
		<div class="row d-flex justify-content-between">
			<div class="col-lg-4 text-white text-center">Copyright 2024 | <a class="text-decoration-none link-light" href="<?= site_url("") ?>">Websidn</a></div>
			<div class="col-lg-4 text-white text-center">Powered By | <a class="text-decoration-none link-light" href="#">Newus Technology</a></div>
		</div>
	</div>

<!-- For Js Library -->
<?php wp_footer()?>

	</div>
</body>
</html>		
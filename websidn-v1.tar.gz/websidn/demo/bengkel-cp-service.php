<?php 
/*

* Template Name: bengekel cp service

*/
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- For Window Tab Color -->
		<!-- Chrome, Firefox OS and Opera -->
		<meta name="theme-color" content="#061948">
		<!-- Windows Phone -->
		<meta name="msapplication-navbutton-color" content="#061948">
		<!-- iOS Safari -->
		<meta name="apple-mobile-web-app-status-bar-style" content="#061948">
		<title>Bengkel Budi</title>
		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="56x56" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/fav-icon/icon.png">
		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/css/style.css">
		<!-- responsive style sheet -->
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/css/responsive.css">
	</head>

	<body>
		<div class="main-page-wrapper">

			<!-- ===================================================
				Loading Transition
			==================================================== -->
			<div id="loader-wrapper">
				<div id="loader"></div>
			</div>

			
			<!-- 
			=============================================
				Theme Header One
			============================================== 
			-->
			<header class="header-one">
				<div class="top-header">
					<div class="container clearfix">
						<div class="logo float-left"><a href="index.html"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/logo/logo.png" alt=""></a></div>
						<div class="address-wrapper float-right">
							<ul>
								<li class="address">
									<i class="icon flaticon-placeholder"></i>
									<h6>Address:</h6>
									<p>2A0, Queenstown St, USA.</p>
								</li>
								<li class="address">
									<i class="icon flaticon-multimedia"></i>
									<h6>Mail us:</h6>
									<p>supporthere@mail.com</p>
								</li>
							</ul>
						</div> <!-- /.address-wrapper -->
					</div> <!-- /.container -->
				</div> <!-- /.top-header -->

				<div class="theme-menu-wrapper">
					<div class="container">
						<div class="bg-wrapper clearfix">
							<!-- ============== Menu Warpper ================ -->
					   		<div class="menu-wrapper float-left">
					   			<nav id="mega-menu-holder" class="clearfix">
								   <ul class="clearfix">
									    <li><a href="<?= site_url('bengkel cp')?>">Home</a></li>
									    <li><a href="<?= site_url('bengkel cp about')?>">About</a></li>
									    <li><a href="<?= site_url('bengkel cp service')?>">Service</a></li>
									    <li><a href="<?= site_url('bengkel cp contact')?>">Contact</a></li>
									    <li><a href="<?= site_url('bengkel cp blog')?>">Blog</a></li>
								   </ul>
								</nav> <!-- /#mega-menu-holder -->
					   		</div> <!-- /.menu-wrapper -->

					   		<div class="right-widget float-right" style="padding-right: 1rem;">
					   			<ul>
					   				<li class="social-icon">
					   					<ul>
											<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										</ul>
					   				</li>
					   			</ul>
					   		</div> <!-- /.right-widget -->
						</div> <!-- /.bg-wrapper -->
					</div> <!-- /.container -->
				</div> <!-- /.theme-menu-wrapper -->
			</header> <!-- /.header-one -->

			
			<!-- 
			=============================================
				Theme Inner Banner
			============================================== 
			-->
			<div class="theme-inner-banner section-spacing">
				<div class="overlay">
					<div class="container">
						<h2>Our Service</h2>
					</div> <!-- /.container -->
				</div> <!-- /.overlay -->
			</div> <!-- /.theme-inner-banner -->

			<!-- 
			=============================================
				Feature Banner
			============================================== 
			-->
			<div id="service" class="feature-banner section-spacing">
				<div class="opacity">
					<div class="container">
						<h2>WExpert Care, Hassle-Free: Oil Changes, Tune-Ups, &amp; and More for Long-Lasting Performance for your Motorcycle.</h2>
						<a href="#" class="theme-button-one">GET A QUOTES</a>
					</div> <!-- /.container -->
				</div> <!-- /.opacity -->
			</div> <!-- /.feature-banner -->


			<!-- 
			=============================================
				Service Style One
			============================================== 
			-->
			<div class="service-style-one section-spacing">
				<div class="container">
					<div class="theme-title-one">
						<h2>Our SERVICES</h2>
						<p>More for Long-Lasting Performance for your Motorcycle.</p>
					</div> <!-- /.theme-title-one -->
					<div class="wrapper">
						<div class="row">
							<div class="col-xl-4 col-md-6 col-12">
								<div class="single-service">
									<div class="img-box"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/home/3.jpg" alt=""></div>
									<div class="text">
										<h5>COMPETITIVE PRICING</h5>
										<p>Transparent Quotes, Affordable Solutions</p>
									</div> <!-- /.text -->
								</div> <!-- /.single-service -->
							</div> <!-- /.col- -->
							<div class="col-xl-4 col-md-6 col-12">
								<div class="single-service">
									<div class="img-box"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/home/4.jpg" alt=""></div>
									<div class="text">
										<h5>GENUINE OEM PARTS</h5>
										<p>Maintain Your Bike's Integrity with Original</p>
									</div> <!-- /.text -->
								</div> <!-- /.single-service -->
							</div> <!-- /.col- -->
							<div class="col-xl-4 col-md-6 col-12">
								<div class="single-service">
									<div class="img-box"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/home/5.jpg" alt=""></div>
									<div class="text">
										<h5>ROUTINE MAINTENANCE</h5>
										<p>Expert Care, Hassle-Free: Oil Changes, Tune-Ups</p>
									</div> <!-- /.text -->
								</div> <!-- /.single-service -->
							</div>
						</div> <!-- /.row -->
					</div> <!-- /.wrapper -->
					<div class="contact-text">
						<h4>You can also send us an email and we’ll get in touch shortly, or Call us</h4>
						<h5><a href="#">info@support.com</a>  (or)  <a href="#">+1 234 6780 900</a></h5>
					</div>
				</div> <!-- /.container -->
			</div> <!-- /.service-style-one -->


			<!--
			=====================================================
				Testimonial Slider
			=====================================================
			-->
			<div class="testimonial-section section-spacing">
				<div class="overlay">
					<div class="container">
						<div class="wrapper">
							<div class="bg">
								<div class="testimonial-slider">
									<div class="item">
										<p>“ Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, assumenda asperiores! Mollitia consequatur enim voluptatem sequi eius voluptate, dignissimos voluptatum sapiente libero ratione corrupti. Inventore fuga quam molestias esse maiores! ”</p>
										<div class="name">
											<h6>Kamal</h6>
											<span>Founder, Mnc Inc.</span>
										</div> <!-- /.name -->
									</div> <!-- /.item -->
									<div class="item">
										<p>“ Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, assumenda asperiores! Mollitia consequatur enim voluptatem sequi eius voluptate, dignissimos voluptatum sapiente libero ratione corrupti. Inventore fuga quam molestias esse maiores! ”</p>
										<div class="name">
											<h6>Rashed Ka.</h6>
											<span>Founder, Mnc Inc.</span>
										</div> <!-- /.name -->
									</div> <!-- /.item -->
									<div class="item">
										<p>“ Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam, assumenda asperiores! Mollitia consequatur enim voluptatem sequi eius voluptate, dignissimos voluptatum sapiente libero ratione corrupti. Inventore fuga quam molestias esse maiores! ”</p>
										<div class="name">
											<h6>Mahfuz Riad</h6>
											<span>Founder, Mnc Inc.</span>
										</div> <!-- /.name -->
									</div> <!-- /.item -->
								</div> <!-- /.testimonial-slider -->
							</div> <!-- /.bg -->
						</div> <!-- /.wrapper -->
					</div> <!-- /.container -->
				</div> <!-- /.overlay -->
			</div> <!-- /.testimonial-section -->

			<!--
			=====================================================
				Footer
			=====================================================
			-->
			<footer class="theme-footer-one">
				<div class="top-footer">
					<div class="container">
						<div class="row">
							<div class="col-12 about-widget">
								<h6 class="title">Bengkel Budi</h6>
								<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deserunt omnis quibusdam quia</p>
								<div class="queries"><i class="flaticon-phone-call"></i> Any Queries : <a href="#">(+1) 234 567 900</a></div>
							</div> <!-- /.about-widget -->
							<div style="display: none;" class="col-xl-4 col-lg-3 col-sm-6 footer-recent-post">
								<h6 class="title">RECENT POSTS</h6>
								<ul>
									<li class="clearfix">
										<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/blog/1.jpg" alt="" class="float-left">
										<div class="post float-left">
											<a href="blog-details.html">Till wanted by theam govern they survive as soldiers.</a>
											<div class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> Feb 06, 2018</div>
										</div>
									</li>
									<li class="clearfix">
										<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/blog/2.jpg" alt="" class="float-left">
										<div class="post float-left">
											<a href="blog-details.html">World don't move to beat of just one drum.</a>
											<div class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> Mar 20, 2018</div>
										</div>
									</li>
								</ul>
							</div> <!-- /.footer-recent-post -->
							<div style="display: none;" class="col-xl-2 col-lg-3 col-sm-6 footer-list">
								<h6 class="title">SOLUTIONS</h6>
								<ul>
									<li><a href="#">Travel and Aviation</a></li>
									<li><a href="#">Business Services</a></li>
									<li><a href="#">Consumer Products</a></li>
									<li><a href="#">Financial Services</a></li>
									<li><a href="#">Software Research</a></li>
									<li><a href="#">Quality Resourcing</a></li>
								</ul>
							</div> <!-- /.footer-list -->
							<div style="display: none;" class="col-xl-3 col-lg-2 col-sm-6 footer-newsletter">
								<h6 class="title">NEWSLETTER</h6>
								<form action="#">
									<input type="text" placeholder="Name *">
									<input type="email" placeholder="Email *">
									<button class="theme-button-one">SUBSCRIBE</button>
								</form>
							</div>
						</div> <!-- /.row -->
					</div> <!-- /.container -->
				</div> <!-- /.top-footer -->
				<div class="bottom-footer">
					<div class="container">
						<div class="row">
							<div class="col-12">
								<p> © 2024. All rights reserved. Powered by <a style="color: #fff;" href="https://websidn.com" target="_blank">Websidn</a>: Bengkel Budi by <a style="color: #fff;" href="https://newus.id" target="_blank">Newus Technology</a></p>
							</div>
							<div class="col-md-6 col-12" style="display: none;">
								<ul>
									<li><a href="about.html">About</a></li>
									<li><a href="service.html">Solutions</a></li>
									<li><a href="#">FAQ’s</a></li>
									<li><a href="contact.html">Contact</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div> <!-- /.bottom-footer -->
			</footer> <!-- /.theme-footer -->
			

	        

	        <!-- Scroll Top Button -->
			<button class="scroll-top tran3s">
				<i class="fa fa-angle-up" aria-hidden="true"></i>
			</button>
			


		<!-- Optional JavaScript _____________________________  -->

    	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
    	<!-- jQuery -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/jquery.2.2.3.min.js"></script>
		<!-- Popper js -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/popper.js/popper.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/bootstrap/js/bootstrap.min.js"></script>
		<!-- Camera Slider -->
		<script src='vendor/Camera-master/scripts/jquery.mobile.customized.min.js'></script>
	    <script src='vendor/Camera-master/scripts/jquery.easing.1.3.js'></script> 
	    <script src='vendor/Camera-master/scripts/camera.min.js'></script>
	    <!-- menu  -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/menu/src/js/jquery.slimmenu.js"></script>
		<!-- WOW js -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/WOW-master/dist/wow.min.js"></script>
		<!-- owl.carousel -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/owl-carousel/owl.carousel.min.js"></script>
		<!-- js count to -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/jquery.appear.js"></script>
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/jquery.countTo.js"></script>
		<!-- Fancybox -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/fancybox/dist/jquery.fancybox.min.js"></script>

		<!-- Theme js -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/js/theme.js"></script>
		</div> <!-- /.main-page-wrapper -->
	</body>
</html>
<?php 
/*

* Template Name: bengekel cp about

*/
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- For Window Tab Color -->
		<!-- Chrome, Firefox OS and Opera -->
		<meta name="theme-color" content="#061948">
		<!-- Windows Phone -->
		<meta name="msapplication-navbutton-color" content="#061948">
		<!-- iOS Safari -->
		<meta name="apple-mobile-web-app-status-bar-style" content="#061948">
		<title>Bengkel Budi</title>
		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="56x56" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/fav-icon/icon.png">
		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/css/style.css">
		<!-- responsive style sheet -->
		<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/css/responsive.css">
	</head>

	<body>
		<div class="main-page-wrapper">

			<!-- ===================================================
				Loading Transition
			==================================================== -->
			<div id="loader-wrapper">
				<div id="loader"></div>
			</div>

			
			<!-- 
			=============================================
				Theme Header One
			============================================== 
			-->
			<header class="header-one">
				<div class="top-header">
					<div class="container clearfix">
						<div class="logo float-left"><a href="index.html"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/logo/logo.png" alt=""></a></div>
						<div class="address-wrapper float-right">
							<ul>
								<li class="address">
									<i class="icon flaticon-placeholder"></i>
									<h6>Address:</h6>
									<p>2A0, Queenstown St, USA.</p>
								</li>
								<li class="address">
									<i class="icon flaticon-multimedia"></i>
									<h6>Mail us:</h6>
									<p>supporthere@mail.com</p>
								</li>
							</ul>
						</div> <!-- /.address-wrapper -->
					</div> <!-- /.container -->
				</div> <!-- /.top-header -->

				<div class="theme-menu-wrapper">
					<div class="container">
						<div class="bg-wrapper clearfix">
							<!-- ============== Menu Warpper ================ -->
					   		<div class="menu-wrapper float-left">
					   			<nav id="mega-menu-holder" class="clearfix">
								   <ul class="clearfix">
									    <li><a href="<?= site_url('bengkel cp')?>">Home</a></li>
									    <li><a href="<?= site_url('bengkel cp about')?>">About</a></li>
									    <li><a href="<?= site_url('bengkel cp service')?>">Service</a></li>
									    <li><a href="<?= site_url('bengkel cp contact')?>">Contact</a></li>
									    <li><a href="<?= site_url('bengkel cp blog')?>">Blog</a></li>
								   </ul>
								</nav> <!-- /#mega-menu-holder -->
					   		</div> <!-- /.menu-wrapper -->

					   		<div class="right-widget float-right" style="padding-right: 1rem;">
					   			<ul>
					   				<li class="social-icon">
					   					<ul>
											<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
										</ul>
					   				</li>
					   			</ul>
					   		</div> <!-- /.right-widget -->
						</div> <!-- /.bg-wrapper -->
					</div> <!-- /.container -->
				</div> <!-- /.theme-menu-wrapper -->
			</header> <!-- /.header-one -->

			<!-- 
			=============================================
				Theme Inner Banner
			============================================== 
			-->
			<div class="theme-inner-banner section-spacing">
				<div class="overlay">
					<div class="container">
						<h2>About Us</h2>
					</div> <!-- /.container -->
				</div> <!-- /.overlay -->
			</div> <!-- /.theme-inner-banner -->

			<!-- 
			=============================================
				Top Feature
			============================================== 
			-->
			<div id="about" class="top-feature section-spacing">
				<div class="top-features-slide">
					<div class="item">
						<div class="main-content" style="background:#fafafa;">
							<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/icon/1.png" alt="">
							<h4><a href="#">NEW MOTORCYCLES</a></h4>
							<p>Sparkling. From Sporty Thrill Machines to Rugged Adventure Companions, Find Your Perfect Match.</p>
						</div> <!-- /.main-content -->
					</div> <!-- /.item -->
					<div class="item">
						<div class="main-content" style="background:#f6f6f6;">
							<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/icon/2.png" alt="">
							<h4><a href="#">USED MOTORCYCLES</a></h4>
							<p>Ride Away with Confidence: Certified Pre-Owned Bikes with Transparent History and Warranty.</p>
						</div> <!-- /.main-content -->
					</div> <!-- /.item -->
					<div class="item">
						<div class="main-content" style="background:#efefef;">
							<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/icon/3.png" alt="">
							<h4><a href="#">24/7 BEST SUPPORT</a></h4>
							<p>Get Back on the Road Fast: 24/7 Support for Any Motorcycle Issue, Day or Night. We're Always in Your Corner</p>
						</div> <!-- /.main-content -->
					</div> <!-- /.item -->
					<div class="item">
						<div class="main-content" style="background:#e9e9e9;">
							<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/icon/4.png" alt="">
							<h4><a href="#">ROUTINE MAINTENANCE</a></h4>
							<p>Expert Care, Hassle-Free: Oil Changes, Tune-Ups, and More for Long-Lasting Performance for your Motorcycle.</p>
						</div> <!-- /.main-content -->
					</div> <!-- /.item -->
				</div> <!-- /.top-features-slide -->
			</div> <!-- /.top-feature -->


			<!-- 
			=============================================
				About Company
			============================================== 
			-->
			<div class="about-compnay section-spacing">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 col-12"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/home/1.jpg" alt=""></div>
						<div class="col-lg-6 col-12">
							<div class="text">
								<div class="theme-title-one">
									<h2>About Our Company</h2>
									<p>Expert Care, Hassle-Free: Oil Changes, Tune-Ups, and More for Long-Lasting Performance for your Motorcycle.Expert Care, Hassle-Free: Oil Changes, Tune-Ups, and More for Long-Lasting Performance for your Motorcycle.</p>
									<p>Expert Care, Hassle-Free: Oil Changes, Tune-Ups, and More for Long-Lasting Performance for your Motorcycle.</p>
								</div> <!-- /.theme-title-one -->
								<ul class="mission-goal clearfix">
									<li>
										<i class="icon flaticon-star"></i>
										<h4>Vision</h4>
									</li>
									<li>
										<i class="icon flaticon-medal"></i>
										<h4>Missions</h4>
									</li>
									<li>
										<i class="icon flaticon-target"></i>
										<h4>Goals</h4>
									</li>
								</ul> <!-- /.mission-goal -->
							</div> <!-- /.text -->
						</div> <!-- /.col- -->
					</div> <!-- /.row -->
				</div> <!-- /.container -->
			</div> <!-- /.about-compnay -->


			<!--
			=====================================================
				Partner Slider
			=====================================================
			-->
			<div class="partner-section bg-color">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-4 col-12">
							<h6>OUR <br>PARTNERS</h6>
						</div>
						<div class="col-md-9 col-sm-8 col-12">
							<div class="partner-slider">
								<div class="item"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/logo/p-1.png" alt=""></div>
								<div class="item"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/logo/p-2.png" alt=""></div>
								<div class="item"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/logo/p-3.png" alt=""></div>
								<div class="item"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/logo/p-4.png" alt=""></div>
								<div class="item"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/logo/p-5.png" alt=""></div>
							</div>
						</div>
					</div>
				</div>
			</div> <!-- /.partner-section -->


			<!--
			=====================================================
				Footer
			=====================================================
			-->
			<footer class="theme-footer-one">
				<div class="top-footer">
					<div class="container">
						<div class="row">
							<div class="col-12 about-widget">
								<h6 class="title">Bengkel Budi</h6>
								<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deserunt omnis quibusdam quia</p>
								<div class="queries"><i class="flaticon-phone-call"></i> Any Queries : <a href="#">(+1) 234 567 900</a></div>
							</div> <!-- /.about-widget -->
							<div style="display: none;" class="col-xl-4 col-lg-3 col-sm-6 footer-recent-post">
								<h6 class="title">RECENT POSTS</h6>
								<ul>
									<li class="clearfix">
										<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/blog/1.jpg" alt="" class="float-left">
										<div class="post float-left">
											<a href="blog-details.html">Till wanted by theam govern they survive as soldiers.</a>
											<div class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> Feb 06, 2018</div>
										</div>
									</li>
									<li class="clearfix">
										<img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/images/blog/2.jpg" alt="" class="float-left">
										<div class="post float-left">
											<a href="blog-details.html">World don't move to beat of just one drum.</a>
											<div class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> Mar 20, 2018</div>
										</div>
									</li>
								</ul>
							</div> <!-- /.footer-recent-post -->
							<div style="display: none;" class="col-xl-2 col-lg-3 col-sm-6 footer-list">
								<h6 class="title">SOLUTIONS</h6>
								<ul>
									<li><a href="#">Travel and Aviation</a></li>
									<li><a href="#">Business Services</a></li>
									<li><a href="#">Consumer Products</a></li>
									<li><a href="#">Financial Services</a></li>
									<li><a href="#">Software Research</a></li>
									<li><a href="#">Quality Resourcing</a></li>
								</ul>
							</div> <!-- /.footer-list -->
							<div style="display: none;" class="col-xl-3 col-lg-2 col-sm-6 footer-newsletter">
								<h6 class="title">NEWSLETTER</h6>
								<form action="#">
									<input type="text" placeholder="Name *">
									<input type="email" placeholder="Email *">
									<button class="theme-button-one">SUBSCRIBE</button>
								</form>
							</div>
						</div> <!-- /.row -->
					</div> <!-- /.container -->
				</div> <!-- /.top-footer -->
				<div class="bottom-footer">
					<div class="container">
						<div class="row">
							<div class="col-12">
								<p> © 2024. All rights reserved. Powered by <a style="color: #fff;" href="https://websidn.com" target="_blank">Websidn</a>: Bengkel Budi by <a style="color: #fff;" href="https://newus.id" target="_blank">Newus Technology</a></p>
							</div>
							<div class="col-md-6 col-12" style="display: none;">
								<ul>
									<li><a href="about.html">About</a></li>
									<li><a href="service.html">Solutions</a></li>
									<li><a href="#">FAQ’s</a></li>
									<li><a href="contact.html">Contact</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div> <!-- /.bottom-footer -->
			</footer> <!-- /.theme-footer -->
			

	        

	        <!-- Scroll Top Button -->
			<button class="scroll-top tran3s">
				<i class="fa fa-angle-up" aria-hidden="true"></i>
			</button>
			


		<!-- Optional JavaScript _____________________________  -->

    	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
    	<!-- jQuery -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/jquery.2.2.3.min.js"></script>
		<!-- Popper js -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/popper.js/popper.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/bootstrap/js/bootstrap.min.js"></script>
		<!-- Camera Slider -->
		<script src='vendor/Camera-master/scripts/jquery.mobile.customized.min.js'></script>
	    <script src='vendor/Camera-master/scripts/jquery.easing.1.3.js'></script> 
	    <script src='vendor/Camera-master/scripts/camera.min.js'></script>
	    <!-- menu  -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/menu/src/js/jquery.slimmenu.js"></script>
		<!-- WOW js -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/WOW-master/dist/wow.min.js"></script>
		<!-- owl.carousel -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/owl-carousel/owl.carousel.min.js"></script>
		<!-- js count to -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/jquery.appear.js"></script>
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/jquery.countTo.js"></script>
		<!-- Fancybox -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/vendor/fancybox/dist/jquery.fancybox.min.js"></script>

		<!-- Theme js -->
		<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/bengkel-cp/js/theme.js"></script>
		</div> <!-- /.main-page-wrapper -->
	</body>
</html>
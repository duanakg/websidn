<?php 
/*

* Template Name: laundry lp

*/
?>
<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SuperLaundry</title> 

<!-- Favicons -->

<link rel="shortcut icon" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/favicon.png">

<!-- Fonts -->

<link href='<?php echo esc_url(get_template_directory_uri());  ?>https://fonts.googleapis.com/css?family=Hind:300,400,500,600,700,300' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url(get_template_directory_uri());  ?>https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

<!-- Styles -->

<link href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/css/style.css" rel="stylesheet"  media="screen">
</head>
<body>

  <!-- Loader -->

  	<div class="loader">
   	<div class="loader-brand"><img alt="" class="img-responsive center-block" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/brand.png"></div>
   </div>

	   <!-- Header -->

		<header id="top">
	      <div class="navbar navbar-2 affix">
		      <div class="container">
		        <div class="navbar-header">
		          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		          </button> 
		          <a href="#top" class="brand js-target-scroll">
		            <img class="brand-white" alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/brand-white.png">
		            <img class="brand-dark" alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/brand.png">
		          </a>
		        </div>
		        <div class="collapse navbar-collapse" id="navbar-collapse">
		            <ul class="nav navbar-nav navbar-right">                                                   
			            <li class="active">
			            	<a href="#top" class="js-target-scroll">Home</a>
			            </li>
			            <li>
			            	<a href="#features" class="js-target-scroll">Services</a>
			            </li>
			            <li>
			            	<a href="#about-product" class="js-target-scroll">About</a>
			            </li>
			            <li>
			            	<a href="#team" class="js-target-scroll">Team</a>
			            </li>
			            <li>
			            	<a href="#contact" class="js-target-scroll">Contact</a>
			            </li>
			         </ul>
		        </div>
		      </div>
	      </div>
		</header>

   	<!-- Masthead -->

      <div class="masthead">
	    	<div class="masthead-entry-3 text-right parallax" data-stellar-background-ratio="0.3">
  	         <div class="inner rel-1">
	  	         <div class="container">
	  	        	<h2 class="page-subtitle wow fadeInDown">Quality Laundry</h2>
	      	   		<h1 class="wow fadeInUp">Service In <span class="underline">Your City</span></h1>
		            <div class="row">
		            	<div class="col-md-8 col-md-offset-4 col-lg-6 col-lg-offset-6">
		            		<p>We take care about cleenness of your cloth</p>
		            	</div>
		            </div>
		            <div class="inline-buttons">
			            <div class="row-base">
				            <a href="#services" class="col-base btn-lead btn-red btn">
				            	<span class="text">Explore Service</span>
				            	<span class="flip-front">Explore Service</span>
				            	<span class="flip-back">Start now</span>
				            </a>
				            <a href="#" class="col-base btn-lead btn-b-white btn" style="display: none;">
				            	<span class="text">Buy now</span>
				            	<span class="flip-front">Buy now</span>
				            	<span class="flip-back">Yeaah!</span>
				            </a>
			            </div>
		            </div>
	            </div>
	            <div class="entry-line"></div>
            </div>
       	</div>
      </div>

		<!-- Main -->

	   <main class="main">

			<!-- Banner -->

			<section class="section-banner banner-style-3 bgc-light">
			   <div class="container">
			      <div class="row-base row">
			         <header class="col-base col-md-9">
			        		<h2 class="banner-title">Make An Appoitment</h2>
			         </header>
			         <div class="col-base col-md-3">
			        		<a href="#contact" class="btn-lead btn-b-dark btn wow swing">
			            	<span class="text">Call now</span>
			            	<span class="flip-front">Call now</span>
			            	<span class="flip-back">Start now</span>
			            </a>
			        	</div>
			      </div>
			   </div>
			</section>

			<!-- Reviews -->

			<section id="reviews" class="reviews-2 masked text-center section">
			   <div class="container rel-1">
			   	<div class="custom-controls">
	            	<div class="thumbnail-pagination">
	            		<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/reviews/4.jpg"></a>
	            		<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/reviews/5.jpg"></a>
	            		<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/reviews/6.jpg"></a>
	            	</div>
	            </div>
			      <i class="icon-review fa fa-quote-left"></i>
				   <div class="review-carousel carousel">
	               <div class="review">
	                  <div class="col-review col-md-8 col-md-offset-2">
	                  	<p class="review-text">This is the best of the PSD which has been well organized and focused on the smallest details and carefully placed, <strong>from every point of view</strong> has a lot of potential that</p>
	                  	<div class="reviewer">
			                	<h3 class="reviewer-name">Mail</h3>
		                	</div>
	                  </div>	
	               </div>
	               <div class="review">
	                  <div class="col-review col-md-8 col-md-offset-2">
	                  	<p class="review-text">This is the best of the PSD which has been well organized and focused on the smallest details and carefully placed, <strong>from every point of view</strong> has a lot of potential that</p>
	                  	<div class="reviewer">
			                	<h3 class="reviewer-name">Afgan</h3>
		                	</div>
	                  </div>	
	               </div>
	               <div class="review">
	                  <div class="col-review col-md-8 col-md-offset-2">
	                  	<p class="review-text">This is the best of the PSD which has been well organized and focused on the smallest details and carefully placed, <strong>from every point of view</strong> has a lot of potential that can be explored This is the best of the PSD which has been well organized and focused on the smallest</p>
	                  	<div class="reviewer">
			                	<h3 class="reviewer-name">Abdul</h3>
		                	</div>
	                  </div>	
	               </div>
		         </div>
	         </div>
			</section>

			<!-- About product -->

			<section id="about-product" class="about-product section">
			   <div class="container">
			      <div class="row">
			      	<div class="col-product-img col-lg-6 col-lg-push-6 wow fadeInRight" data-wow-duration="2s">
			      		<img alt="" class="img-responsive" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/feature-img3.png">
			      	</div>
			      	<div class="col-about-product col-lg-6 col-lg-pull-6">
			      		<div class="row-advantage-2 row">
					         <div class="col-advantage col-md-6 col-lg-6">
					          	<div class="inner">
						          	<div class="media-left"><i class="fa fa-clock-o"></i></div>
						            <h3 class="media-right">Fast</h3>
						            <p>Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum</p>
					            </div>
					         </div>
					         <div class="col-advantage col-md-6 col-lg-6">
					         	<div class="inner">
						          	<div class="media-left"><i class="fa fa-cogs"></i></div>
						            <h3 class="media-right">High Service</h3>
						            <p>Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum</p>
					            </div>
					         </div>
					         <div class="col-advantage col-md-6 col-lg-6">
					          	<div class="inner">
						          	<div class="media-left"><i class="fa fa-briefcase"></i></div>
						            <h3 class="media-right">Experience</h3>
						            <p>Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum</p>
					            </div>
					         </div>
					         <div class="col-advantage col-md-6 col-lg-6">
					         	<div class="inner">
						          	<div class="media-left"><i class="fa fa-diamond"></i></div>
						            <h3 class="media-right">Professional</h3>
						            <p>Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum</p>
					            </div>
					         </div>
					         <div class="col-advantage col-md-6 col-lg-6">
					          	<div class="inner">
						          	<div class="media-left"><i class="fa fa-laptop"></i></div>
						            <h3 class="media-right">Ezzy Order</h3>
						            <p>Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum</p>
					            </div>
					         </div>
					         <div class="col-advantage col-md-6 col-lg-6">
					         	<div class="inner">
						          	<div class="media-left"><i class="fa fa-comments-o"></i></div>
						            <h3 class="media-right">Support 24/7</h3>
						            <p>Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum</p>
					            </div>
					         </div>
					      </div>
			      	</div>
			      </div>
			   </div>
			</section>

			<!-- Features -->

			<section id="features" class="features2 bgc-light section">
				<div class="container">
			      <div class="row">
			        <header class="text-center col-md-8 col-md-offset-2">
			        	<h2>Why Choose us</h2>
			        	<p class="section-entry">Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque debitis nihil voluptas obcaecati maiores beatae tempora adipisci veritatis explicabo</p>
			        </header>
			      </div>
			      <div class="section-body">
			         <div class="row">
				         <div class="col-feature-img2 col-md-6 wow fadeInLeft" data-wow-duration="2s">
				        		<img alt="" class="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/feature-img2.png">
				         </div>
				         <div class="section-body-x2 col-feature col-md-6">
				        		<h2 class="feature-title">
				        			Professional
				        		</h2>
				        		<p class="feature-subtitle">We Deliver High Quality</p>
				        		<div class="title-space"></div>
				        		<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum consectetur perferendis harum sint nesciunt, labore culpa unde, eius temporibus</p>
				        		<p>repellendus velit sunt quidem possimus dolores sint hic eligendi, voluptate ratione voluptatibus eaque iusto delectus quisquam?</p>
			        			<a href="#" class="btn-lead btn-red btn wow swing">
				            	<span class="text">Purchased</span>
				            	<span class="flip-front">Purchased</span>
				            	<span class="flip-back">Start now</span>
			            	</a>
				         </div>
			         </div>
			      </div>
			     	<div class="section-body-x2">
			         <div class="row">
				         <div class="col-feature-img2 col-md-6 col-md-push-6 wow fadeInRight" data-wow-duration="2s">
				        		<img alt="" class="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/feature-img4.png">
				         </div>
				         <div class="col-feature col-md-6 col-md-pull-6">
				        		<div class="feature">
				        			<div class="media-left">
				        				<div class="icon-round icon-feature"><i class="fa fa-clock-o"></i></div>
				        			</div>
				        			<div class="media-body">
				        				<h3>Fast</h3>
				        				<p>Sed porta sollicitudin eros, vel sagittis turpis consequat nec. Donec ac viverra ligula, in scelerisque leo. Proin massa quam, ornare</p>
				        			</div>
				        		</div>
				        		<div class="feature">
				        			<div class="media-left">
				        				<div class="icon-round icon-feature"><i class="fa fa-comments-o"></i></div>
				        			</div>
				        			<div class="media-body">
				        				<h3>Support 24/7</h3>
				        				<p>Sed porta sollicitudin eros, vel sagittis turpis consequat nec. Donec ac viverra ligula, in scelerisque leo. Proin massa quam, ornare</p>
				        			</div>
				        		</div>
				        		<div class="feature">
				        			<div class="media-left">
				        				<div class="icon-round icon-feature"><i class="fa fa-diamond"></i></div>
				        			</div>
				        			<div class="media-body">
				        				<h3>Professional</h3>
				        				<p>Sed porta sollicitudin eros, vel sagittis turpis consequat nec. Donec ac viverra ligula, in scelerisque leo.</p>
				        			</div>
				        		</div>
				         </div>
			         </div>
			      </div>
			   </div>
			</section>

			<!-- Team -->

			<section id="team" class="team-3 text-center section">
			   <div class="container">
			      <div class="row">
			        <header class="text-center col-md-8 col-md-offset-2">
			        	<h2>Team</h2>
			        	<p class="section-entry">Some of our recent work of the hundreds that we have for our customers around the world are displayed in Fusce lacinia arcu et nulla. Nulla vitae mauris non felis mollis faucipus.</p>
			        </header>
			      </div>
			      <div class="section-body">
			      	<div class="row-base row">
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/team3/1.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Rahmat</h3>
					      				<p class="profile-spec">Ceo / Co-fuder</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/team3/2.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Novan</h3>
					      				<p class="profile-spec">Admin</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/team3/3.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Kamal</h3>
					      				<p class="profile-spec">Admin</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/team3/4.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Mail</h3>
					      				<p class="profile-spec">Admin</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
			      	</div>
			      </div>
			   </div>
			</section>

			<!-- Clients -->

			<section id="clients" class="clients bgc-light section">
				<div class="container">
					<div class="row">
						<header class="text-center col-md-8 col-md-offset-2">
				        	<h2>Clients</h2>
				        	<p class="section-entry">Some of our recent work of the hundreds that we have for our customers around the world are displayed in Fusce lacinia arcu et nulla. Nulla vitae mauris non felis mollis faucipus.</p>
			         </header>
		         </div>
				   <div class="section-body">
				   	<div class="clients-carousel">
				   		<div class="client">
				   			<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/clients/1.png"></a>
				   		</div>
				   		<div class="client">
				   			<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/clients/2.png"></a>
				   		</div>
				   		<div class="client">
				   			<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/clients/3.png"></a>
				   		</div>
				   		<div class="client">
				   			<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/clients/4.png"></a>
				   		</div>
				   		<div class="client">
				   			<a href=""><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/clients/1.png"></a>
				   		</div>
				   	</div>
				   </div>
			   </div>
			</section>

			<!-- Contact -->

			<section id="contact" class="contact contact-2 section">
			   <div class="container">
		         <div class="row">
			        <header class="text-center col-md-8 col-md-offset-2">
			        	<h2>Contact</h2>
			        	<p class="section-entry">Some of our recent work of the hundreds that we have for our customers around the world are displayed in Fusce lacinia arcu et nulla. Nulla vitae mauris non felis mollis faucipus.</p>
			        </header>
			      </div>
			      <div class="section-body">
			      	<div class="row">
				      	<div class="col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3">
					      	<form class="js-ajax-form">
				      			<div class="form-group">
				      				<div class="form-control-layout">
				      					<i class="fa fa-user"></i>
				      					<input type="text" class="form-control" name="name" placeholder="Name">
				      				</div>
				      			</div>
				      			<div class="form-group">
					      			<div class="form-control-layout">
					      				<i class="fa fa-envelope-o"></i>
					      				<input type="text" class="form-control" name="email" required placeholder="Email address *">
					      			</div>
				      			</div>
				      			<div class="form-group">
				      				<div class="form-control-layout">
				      					<i class="fa fa-phone"></i>
				      					<input type="text" class="form-control" name="phone" placeholder="Phone number">
				      				</div>
				      			</div>
				      			<div class="form-group">
				      				<div class="form-control-layout">
					      				<i class="fa fa-pencil"></i>
					      				<textarea class="form-control" name="message" required placeholder="Write message *"></textarea>
					      			</div>
				      			</div>
				      			<div class="form-group">
				      				<button type="submit" class="btn-yellow-2 btn-lg btn-block btn">
						            	<span class="text">Send message</span>
						            	<span class="flip-front">Send message</span>
						            	<span class="flip-back">Submit</span>
						            </button>
				      			</div>
					      	</form>
				      	</div>
			      	</div>
			      </div>
			   </div>
			</section>

	   </main>


	   <!-- Footer -->

	   <footer class="footer">
	   	<section class="section bgc-dark">
	   		<div class="container rel-1">
	   			<a href="#top" class="scroll-top hvr-wobble-vertical js-target-scroll">
	   				<i class="fa fa-chevron-up"></i>
	   			</a>
	   			<div class="row-base row">
	   				<aside style="display: none;" class="bottom-widget-posts col-footer col-base col-md-6 col-lg-4">
							<h2 class="bottom-widget-title">News Post</h2>
							<ul class="bottom-post-list">
								<li>
									<div class="bottom-post-img">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/posts/1-75x75px.jpg"></a>
									</div>
									<div class="media-body">
										<h3><a href="#">Tips Useful For Web Designers</a></h3>
										<p>Phasellus pulvinar iaculis nunc at placerat. Sed porta sollicitudin</p>
										<ul class="bottom-post-meta">
											<li><a href="#">Simon McCool </a></li>
											<li>2 Weeks ago</li>
											<li>Views 3,098</li>
										</ul>
									</div>
								</li>
								<li>
									<div class="bottom-post-img">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/posts/2-75x75px.jpg"></a>
									</div>
									<div class="media-body">
										<h3><a href="#">Tips Useful For Designers</a></h3>
										<p>Phasellus pulvinar iaculis nunc at placerat. Sed porta sollicitudin</p>
										<ul class="bottom-post-meta">
											<li><a href="#">Simon McCool </a></li>
											<li>2 Weeks ago</li>
											<li>Views 3,098</li>
										</ul>
									</div>
								</li>
							</ul>
	   				</aside>
	   				<aside style="display: none;" class="bottom-widget-gallery col-footer col-base col-md-6 col-lg-4">
							<h2 class="bottom-widget-title">Favorites Flickr</h2>
							<ul class="bottom-gallery-list">
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/widget-gallery/1.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/widget-gallery/2.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/widget-gallery/3.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/widget-gallery/4.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/widget-gallery/5.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/widget-gallery/6.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
							</ul>
							<div class="widget-gallery-control">
								<a href="#" class="more text-white">
									<i class="fa fa-chevron-circle-right"></i>
									<span>View more</span>
								</a>
							</div>
	   				</aside>
	   				<aside class="bottom-widget-text col-footer col-base col-12">
							<img alt="" class="img-responsive" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/img/brand-white.png">
							<div class="text-content">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vehicula mollis urna vel dignissim. Integer tincidunt viverra est, non congue.</p>
								<p>Sed dolor velit, convallis quis erat in, molestie eleifend enim. Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum </p>
							</div>
							<div class="social social-round">
					   		<a href="#" class="fa fa-facebook"></a>
					   		<a href="#" class="fa fa-twitter"></a>
					   		<a href="#" class="fa fa-linkedin"></a>
					   		<a href="#" class="fa fa-google-plus"></a>
					   		<a href="#" class="fa fa-pinterest-p"></a>
					   		<a href="#" class="fa fa-flickr"></a>
					   		<a href="#" class="fa fa-dribbble"></a>
				   	   </div>
	   				</aside>
	   			</div>
	   		</div>
	   	</section>
	   	<div class="footer-bottom">
	   		<div class="container">
		   		<div class="row-base row">
		   			<div class="copy col-base col-md-6">
		   				© 2024. All rights reserved. Powered by <a href="https://websidn.com" target="_blank">Websidn</a>: SuperLaundry by <a href="https://newus.id" target="_blank">Newus Technology</a>
		   			</div>
		   		</div>
	   		</div>
	   	</div>
	   </footer>

<!-- Scripts -->

<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/jquery.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/bootstrap.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/smoothscroll.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/wow.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/imagesloaded.pkgd.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/isotope.pkgd.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/owl.carousel.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/jquery.validate.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/jquery.stellar.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/jquery.easypiechart.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/interface.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/https://maps.googleapis.com/maps/api/js?v=3.exp.js"></script> 
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-lp/js/gmap.js"></script> 
</body>
</html>
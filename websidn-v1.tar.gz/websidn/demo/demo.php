<?php 
/*

* Template Name: Demo

*/
?>
<?php get_header() ?>


    <div class="container-fluid bg-wbn2 d-flex justify-content-center flex-column align-items-center py-5">
        <div class="row py-5 my-5">
            <div class="col-lg-12 text-center">
                <h2>Demo Desain Website</h2>
                <span class="text-muted">Banyak pilihan desain website menarik</span>
            </div>
        </div>
    </div>

    <div class="container-lg py-5">

        <div class="row">
            <div class="col-12">
                <div class="accordion" id="accordionExample">

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Laundry
                        </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="row">
                                    
                                    <div class="col-lg-4 col-sm-6 col-12 mx-auto">
                                        <div class="card text-center mt-3">
                                            <div class="card-imgg">
                                                <img src="<?= get_theme_file_uri( 'assets/img/laundry-theme1.jpg' ) ?>" class="card-img-top" alt="websidn - landing page 1">
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title">Laundry Themes</h5>
                                                <a target="_blank" href="<?= site_url('laundry lp')?>" class="btn btn-primary mx-1">Landing Page</a>
                                                <a target="_blank" href="<?= site_url('laundry cp')?>" class="btn btn-primary mx-1">Company Profile</a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Otomotive
                        </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="row">
                                        
                                    <div class="col-lg-4 col-sm-6 col-12 mx-auto">
                                        <div class="card text-center mt-3">
                                            <div class="card-imgg">
                                                <img src="<?= get_theme_file_uri( 'assets/img/otomotive-theme1.jpg' ) ?>" class="card-img-top" alt="websidn - landing page 1">
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title">Otomotive Themes</h5>
                                                <a target="_blank" href="<?= site_url('bengkel lp')?>" class="btn btn-primary mx-1">Landing Page</a>
                                                <a target="_blank" href="<?= site_url('bengkel cp')?>" class="btn btn-primary mx-1">Company Profile</a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTigo" aria-expanded="false" aria-controls="collapseTigo">
                            Interior / Home
                        </button>
                        </h2>
                        <div id="collapseTigo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="row">
                                        
                                    <div class="col-lg-4 col-sm-6 col-12 mx-auto">
                                        <div class="card text-center mt-3">
                                            <div class="card-imgg">
                                                <img src="<?= get_theme_file_uri( 'assets/img/v-play.png' ) ?>" class="card-img-top" alt="websidn - landing page 1">
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title">Interior / Home Themes</h5>
                                                <a target="_blank" href="<?= site_url('demo#')?>" class="btn btn-primary mx-1">Landing Page</a>
                                                <a target="_blank" href="<?= site_url('demo#')?>" class="btn btn-primary mx-1">Company Profile</a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse4" aria-expanded="false" aria-controls="collapse4">
                            Travel
                        </button>
                        </h2>
                        <div id="collapse4" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="row">
                                        
                                    <div class="col-lg-4 col-sm-6 col-12 mx-auto">
                                        <div class="card text-center mt-3">
                                            <div class="card-imgg">
                                                <img src="<?= get_theme_file_uri( 'assets/img/screenshot.jpg' ) ?>" class="card-img-top" alt="websidn - landing page 1">
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title">Travel Themes</h5>
                                                <a target="_blank" href="<?= site_url('demo#')?>" class="btn btn-primary mx-1">Landing Page</a>
                                                <a target="_blank" href="<?= site_url('demo#')?>" class="btn btn-primary mx-1">Company Profile</a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>

    </div>


    <style>
    .nav-link{color:#555 !important;}
</style>
<?php get_footer() ?>
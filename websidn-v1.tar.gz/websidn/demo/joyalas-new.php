<?php 
/*

* Template Name: joyalas lp

*/
?>
<!DOCTYPE html>
<html class="csstransforms csstransforms3d csstransitions no-js skrollr skrollr-desktop" lang="en">
    <head>
        <title>JOYALAS</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/favicon.png" />
        <!-- google font -->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" />
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>http://fonts.googleapis.com/css?family=Oswald:300,400,700" />
        <!-- font awesome-->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/font-awesome.min.css" />
        <!-- Animation -->
        <link rel="stylesheet" type="text/css"  id="animationcss" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/animation.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/bootstrap.css" />
        <!-- custom style -->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/style.css" />
        <!-- custom scrollbar -->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/custom-scrollbar.css">
        <!-- color style -->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/colors/gold.css" />
        <!-- responsive -->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/responsive.css">
        <!-- gold-responsive -->
        <link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/css/colors/gold-responsive.css">
    </head>

    <body>
        <!-- main page -->
        <div class="main gold"> 
            <!-- header-->
            <header id="home" data-stellar-background-ratio="0.5" class="header animated interior">
                <nav class="navbar navbar-default navbar-fixed-top nav-transparent overlay-nav sticky-nav" role="navigation">
                    <div class="container main-navigation">
                        <div class="col-md-3 float-left"> <a class="logo-dark" href="#home"><span style="font-size: 1.5rem; font-weight: bolder; color: #555;">JOYALAS</span></a> <a class="logo-light" href="#home"><span style="font-size: 1.5rem; font-weight: bolder; color: #fff;">JOYALAS</span></a> </div>
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle Navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                        </div>
                        <div class="col-md-9 text-left float-right collapse-navation">
                            <div class="navbar-collapse collapse navbar-inverse no-transition">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="#about">About</a></li>
                                    <li><a href="#work">Products</a></li>
                                    <li><a href="#expertise">Services</a></li>
                                    <li class="last"><a href="#contact">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
                <div class="intro-bg"></div>
                <div class="color-overlay full-screen"> 
                    <!-- header text -->
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <div class="intro-section os-animation" data-os-animation="fadeIn">
                                    <h1 class="intro"><span class="highlight">Bengkel Las Listrik</span><br>
                                        Terbaik Di Lampung</h1>
                                    <a id="hrefabout" class="highlight-button inner-link" href="#about">Selengkapnya</a> </div>
                            </div>
                        </div>
                    </div>
                    <div class="scrollDownWrap os-animation" data-os-animation="fadeIn">
                        <div class="scrollDown"> <a id="href_about" href="#about"><i class="fa fa-angle-down"></i></a> </div>
                    </div>
                </div>
            </header>
            <!-- header end --> 

            <!-- about -->
            <section id="about" class="gray-bg">
                <div class="container">
                    <div class="row border-bottom os-animation text-center" data-os-animation="fadeInUp">
                        <div class="col-md-6 col-sm-6 title-text border-right">
                            <h2 class="title">Tentang Kami</h2>
                        </div>
                        <div class="col-md-6 col-sm-6 simple-text">
                            <p class="description text-left">Layanan jasa bengkel las listrik untuk kebutuhan aksesoris rumah, kantor, apartemen, dan fasilitas umum yang membutuhkan produk-produk besi dengan model tertentu.</p>
                        </div>
                    </div>
                    <div class="row border-bottom os-animation" data-os-animation="fadeInUp">
                        <div class="col-md-3 col-sm-3 service-box border-right text-center">
                            <div class="service-icon"> <i class="fa fa-pencil-square-o"></i> </div>
                            <h6>Pemesanan Mudah</h6>
                            <p class="content"></p>
                        </div>
                        <div class="col-md-3 col-sm-3 service-box border-right text-center">
                            <div class="service-icon"> <i class="fa fa-comment-o"></i> </div>
                            <h6>Gratis Konsultasi</h6>
                            <p class="content"></p>
                        </div>
                        <div class="col-md-3 col-sm-3 service-box border-right text-center">
                            <div class="service-icon"> <i class="fa fa-cut"></i> </div>
                            <h6>Kreative</h6>
                            <p class="content"></p>
                        </div>
                        <div class="col-md-3 col-sm-3 service-box text-center">
                            <div class="service-icon"> <i class="fa fa-bell-o"></i> </div>
                            <h6>Pengerjaan Cepat</h6>
                            <p class="content"></p>
                        </div>
                    </div>
                    <div class="row os-animation text-center" data-os-animation="fadeInUp">
                        <p class="lead width">We grow brands by making decisions that are rooted in business strategy.</p>
                        <br>
                        <a id="href-about" class="highlight-button-black inner-link" href="#contact">Let's work together</a> </div>
                </div>
            </section>
            <!-- about end --> 

            <!-- products -->
            <section id="grid-gallery" class="grid-gallery no-padding-top no-padding-bottom">
                <div id="work" class="work grid-wrap"> 
                    <!-- portfolio tab -->
                    <ul class="isotope-filters text-center os-animation" data-os-animation="fadeInUp">
                        <li class="active"><a class="active" data-filter="*" href="#">all</a></li>
                        <li><a data-filter=".pagar" href="#">Pagar Besi</a></li>
                        <li><a data-filter=".kanopi" href="#">Kanopi</a></li>
                        <li><a data-filter=".kerajinan" href="#">Kerajinan Besi</a></li>
                        <li><a data-filter=".lainnya" href="#">Lainnya</a></li>
                    </ul>
                    <ul class="grid portfolio isotope no-transition portfolio-hex portfolio-shadows row demo-3 os-animation" data-os-animation="fadeInUp">
                        <li class="portfolio-item col-md-3 col-sm-3 lainnya grid cs-style-3">
                            <figure class="portfolio-figure"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-4.jpg" alt="work-01" />
                                <figcaption>
                                    <h4 class="title">Others Service</h4>
                                    <span>High Quality</span> <a class="text-right" href="javascript:;"><i class="fa fa-angle-right"></i></a> </figcaption>
                            </figure>
                        </li>
                        <li class="portfolio-item col-md-3 col-sm-3 kanopi grid cs-style-3">
                            <figure class="portfolio-figure"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-2.jpg" alt="work-02" />
                                <figcaption>
                                    <h4 class="title">Kanopi</h4>
                                    <span>High Quality</span> <a class="text-right" href="javascript:;"><i class="fa fa fa-angle-right"></i></a> </figcaption>
                            </figure>
                        </li>
                        <li class="portfolio-item col-md-3 col-sm-3 kerajinan grid cs-style-3">
                            <figure class="portfolio-figure"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-3.jpg" alt="work-03" />
                                <figcaption>
                                    <h4 class="title">Kerajinan Besi</h4>
                                    <span>High Quality</span> <a class="text-right" href="javascript:;"><i class="fa fa fa-angle-right"></i></a> </figcaption>
                            </figure>
                        </li>
                        <li class="portfolio-item col-md-3 col-sm-3 pagar grid cs-style-3">
                            <figure class="portfolio-figure"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-1.jpg" alt="work-04" />
                                <figcaption>
                                    <h4 class="title">Pagar Besi</h4>
                                    <span>High Quality</span> <a class="text-right" href="javascript:;"><i class="fa fa fa-angle-right"></i></a> </figcaption>
                            </figure>
                        </li>
                    </ul>
                </div>
                <!-- products popup -->
                <div class="slideshow">
                    <ul class="popup-slide">
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel1" class="carousel slide" data-ride="carousel">
                                            <ol class="carousel-indicators">
                                                <li data-target="#carousel1" data-slide-to="0" class="active"></li>
                                                <li data-target="#carousel1" data-slide-to="1"></li>
                                                <li data-target="#carousel1" data-slide-to="2"></li>
                                            </ol>
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-1.jpg" alt="work-01"/> </div>
                                                <div class="item"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-2.jpg" alt="work-02"/> </div>
                                                <div class="item"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-3.jpg" alt="work-03"/> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title text-left">Lainnya</h4>
                                        <span class="text-left category">Fashion Industry&nbsp;&nbsp;•&nbsp;&nbsp;United Kingdom</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Magento Development + Mobile Website + WordPress Development</span>
                                        <div class="popup-line"></div>
                                        <p class="text-left">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                       
                                    </div>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel-example-generic-01" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-2.jpg" alt="work-02"/> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title">Kanopi</h4>
                                        <span class="category">product Industry&nbsp;&nbsp;•&nbsp;&nbsp;JOYALAS</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Baja Ringan, Las Listrik</span>
                                        <div class="popup-line"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <div class="popup-line"></div>
                                    </div>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel-example-generic-02" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-3.jpg" alt="work-g03"/> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title">Kerajinan Besi</h4>
                                        <span class="category">Project JOYALAS&nbsp;&nbsp;•&nbsp;&nbsp;Kerajinan Besi</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Las</span>
                                        <div class="popup-line"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                    </div>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel2" class="carousel slide" data-ride="carousel">
                                            <ol class="carousel-indicators">
                                                <li data-target="#carousel2" data-slide-to="0" class="active"></li>
                                                <li data-target="#carousel2" data-slide-to="1"></li>
                                                <li data-target="#carousel2" data-slide-to="2"></li>
                                            </ol>
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-1.jpg" alt="work-01"/> </div>
                                                <div class="item"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-1.jpg" alt="work-02"/> </div>
                                                <div class="item"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-1.jpg" alt="work-03"/> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title">PAGAR BESI</h4>
                                        <span class="text-left category">JOYALAS&nbsp;&nbsp;•&nbsp;&nbsp;Project Pagar Besi</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Las</span>
                                        <div class="popup-line"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                    </div>
                                </figcaption>
                            </figure>
                        </li>

                        <!-- batas -->
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel-example-generic-04" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-3.jpg" alt="work-05"/> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title">satra jean brand</h4>
                                        <span class="text-left category">design Industry&nbsp;&nbsp;•&nbsp;&nbsp;australia</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">WordPress Development + Blog + Branding + eNewsletter</span>
                                        <div class="popup-line"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Client Speak</span>
                                        <p class="client-speak">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.<span>Jacskon Smith&nbsp;&nbsp;•&nbsp;&nbsp;Google Inc</span></p>
                                    </div>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel-example-generic-05" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-3.jpg" alt="work-06"/> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title">flat screen wall</h4>
                                        <span class="text-left category">Fashion Industry&nbsp;&nbsp;•&nbsp;&nbsp;United Kingdom</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Magento Development + WordPress Development + Mobile Website</span>
                                        <div class="popup-line"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Client Speak</span>
                                        <p class="client-speak">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.<span>Stella Kromstain&nbsp;&nbsp;•&nbsp;&nbsp;Google Inc</span></p>
                                    </div>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel-example-generic-06" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-4.jpg" alt="work-07"/> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title">parament action</h4>
                                        <span class="text-left category">product Industry&nbsp;&nbsp;•&nbsp;&nbsp;United States of America</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Custom Website Development + Facebook Pages Design + eNewsletter</span>
                                        <div class="popup-line"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Client Speak</span>
                                        <p class="client-speak">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.<span>Jerry Gordinter&nbsp;&nbsp;•&nbsp;&nbsp;Google Inc</span></p>
                                    </div>
                                </figcaption>
                            </figure>
                        </li>
                        <li class="popup-slideshow content-scroll">
                            <figure class="ipad-scroll">
                                <figcaption>
                                    <div class="popup-slider">
                                        <div id="carousel-example-generic-07" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="item active"> <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/lv-4.jpg" alt="work-08" /> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right-part">
                                        <h4 class="title">visual art exibition</h4>
                                        <span class="text-left category">Fashion Industry&nbsp;&nbsp;•&nbsp;&nbsp;australia</span>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Custom Website Development + Branding + Campaign </span>
                                        <div class="popup-line"></div>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                        <div class="popup-line"></div>
                                        <span class="work-details">Client Speak</span>
                                        <p class="client-speak">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.<span>Jone Doe&nbsp;&nbsp;•&nbsp;&nbsp;Google Inc</span></p>
                                    </div>
                                </figcaption>
                            </figure>
                        </li>
                    </ul>
                    <nav class="popup-navigation"> <span class="icon nav-prev"></span> <span class="icon nav-next"></span> <span class="icon nav-close"></span> </nav>
                </div>
            </section>
            <!-- products end --> 

            <!-- skills -->
            <section class="orange-bg work-count">
                <div class="container">
                    <div class="row">
                        <div class="work-count-box col-md-4 col-sm-4 os-animation" data-os-animation="bounceIn"> <span class="title-top">01.</span> <span class="title">Metodology</span>
                            <div class="black-line-top"></div>
                            <div class="black-line-bottom"></div>
                            <p class="content-white">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                            <!-- <a href="#expertise" class="small-button inner-link">Read More</a>  -->
                        </div>
                        <div class="work-count-box col-md-4 col-sm-4 os-animation" data-os-animation="bounceIn"> <span class="title-top">02.</span> <span class="title">Strategy</span>
                            <div class="black-line-top"></div>
                            <div class="black-line-bottom"></div>
                            <p class="content-white">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                            <!-- <a href="#expertise" class="small-button inner-link">Read More</a>  -->
                        </div>
                        <div class="work-count-box col-md-4 col-sm-4 os-animation" data-os-animation="bounceIn"> <span class="title-top">03.</span> <span class="title">Results</span>
                            <div class="black-line-top"></div>
                            <div class="black-line-bottom"></div>
                            <p class="content-white">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                            <!-- <a href="#expertise" class="small-button inner-link">Read More</a>  -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- skills end --> 

            <!-- testimonial -->
            <section id="testimonial" class="testimonial testimonial-int">
                <div class="color-overlay">
                    <div class="container">
                        <div class="row text-center os-animation" data-os-animation="fadeInUp">
                            <h2 class="title">Testimonial</h2>
                        </div>
                        <div class="row text-center os-animation" data-os-animation="fadeInUp">
                            <div data-ride="carousel" class="carousel slide" id="myCarousel">
                                <ol class="carousel-indicators">
                                    <li data-slide-to="0" data-target="#myCarousel"></li>
                                    <li data-slide-to="1" data-target="#myCarousel"></li>
                                    <li data-slide-to="2" data-target="#myCarousel" class="active"></li>
                                    <li data-slide-to="3" data-target="#myCarousel"></li>
                                    <li data-slide-to="4" data-target="#myCarousel"></li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="item">
                                        <div class="container">
                                            <div class="carousel-caption">
                                                <p>We build pretty complex tools and this allows us to take designs and turn them into functional prototypes quickly and easily.</p>
                                                <div class="white-line"></div>
                                                <span>Andi</span> </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="container">
                                            <div class="carousel-caption">
                                                <p>We build pretty complex tools and this allows us to take designs and turn them into functional prototypes quickly and easily.</p>
                                                <div class="white-line"></div>
                                                <span>Hamid</span> </div>
                                        </div>
                                    </div>
                                    <div class="item active">
                                        <div class="container">
                                            <div class="carousel-caption">
                                                <p>We build pretty complex tools and this allows us to take designs and turn them into functional prototypes quickly and easily.</p>
                                                <div class="white-line"></div>
                                                <span>Jarjit</span> </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="container">
                                            <div class="carousel-caption">
                                                <p>We build pretty complex tools and this allows us to take designs and turn them into functional prototypes quickly and easily.</p>
                                                <div class="white-line"></div>
                                                <span>Fizi</span> </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="container">
                                            <div class="carousel-caption">
                                                <p>We build pretty complex tools and this allows us to take designs and turn them into functional prototypes quickly and easily.</p>
                                                <div class="white-line"></div>
                                                <span>Ikhsan</span> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- testimonial end --> 

            <!-- services -->
            <section id="expertise" class="expertise">
                <div class="container">
                    <div class="row border-bottom os-animation text-center" data-os-animation="fadeInUp">
                        <div class="col-md-6 col-sm-6 title-text border-right">
                            <h2 class="title">Services</h2>
                        </div>
                        <div class="col-md-6 col-sm-6 simple-text">
                            <p class="description text-left">Layanan Kami : Kanopi | Kerajinan Besi | Konstruksi Baja | Pintu Besi | Pintu Garasi | Pagar Besi | Railing Balkon | Railing Tangga | Tangga Besi | Teralis Jendela | Teralis Pintu </p>
                        </div>
                    </div>
                    <div class="row feature-content os-animation" data-os-animation="fadeInUp">
                        <div class="col-md-6 col-sm-6">
                            <div class="feature">
                                <div class="icon-container"> <i class="fa fa-paper-plane-o"></i> </div>
                                <div class="fetaure-details">
                                    <h4 class="title">Discover. <span>Understand the situation.</span></h4>
                                    <p class="content">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="feature">
                                <div class="icon-container"> <i class="fa fa-bullhorn"></i> </div>
                                <div class="fetaure-details">
                                    <h4 class="title">Strategise. <span>Chart the course.</span></h4>
                                    <p class="content">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 os-animation" data-os-animation="fadeInUp">
                        <div class="expertise-img"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/service.jpg" class="animated fadeIn" alt="expertise-img" /></div>
                    </div>
                </div>
            </section>
            <!-- services end --> 

            <!-- Piechart -->
            <section id="count" class="count orange-bg">
                <div class="container">
                    <div class="row os-animation" data-os-animation="fadeInUp">
                        <div class="col-md-3 col-sm-5 text-center count-box">
                            <div class="chart2 easyPieChart" data-line-width="8" data-percent="70" data-size="200"><span>70%</span></div>
                            <h3 class="title margin-top">Living Room</h3>
                            <p>Lorem Ipsum is simply.</p>
                        </div>
                        <div class="col-md-3 col-sm-5 text-center count-box">
                            <div class="chart2 easyPieChart" data-line-width="8" data-percent="50" data-size="200"><span>50%</span></div>
                            <h3 class="title margin-top">Kitchen</h3>
                            <p>Lorem Ipsum is simply.</p>
                        </div>
                        <div class="col-md-3 col-sm-5 text-center count-box">
                            <div class="chart2 easyPieChart" data-line-width="8" data-percent="92" data-size="200"><span>92%</span></div>
                            <h3 class="title margin-top">Wardrobes</h3>
                            <p>Lorem Ipsum is simply.</p>
                        </div>
                        <div class="col-md-3 col-sm-5 text-center count-box">
                            <div class="chart2 easyPieChart" data-line-width="8" data-percent="100" data-size="200"><span>100%</span></div>
                            <h3 class="title margin-top">Bedroom</h3>
                            <p>Lorem Ipsum is simply.</p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Piechart end --> 

            <!-- team -->
            <section id="team" class="team gray-bg">
                <div class="container">
                    <div class="row border-bottom os-animation text-center" data-os-animation="fadeInUp">
                        <div class="col-md-6 col-sm-6 title-text border-right">
                            <h2 class="title">our team</h2>
                        </div>
                        <div class="col-md-6 col-sm-6 simple-text">
                            <p class="description text-left">We are a fun mix of designers and strategists with a great passion for all things creative. We love what we do, it's a way of life.</p>
                        </div>
                    </div>
                    <div class="row os-animation" data-os-animation="fadeInUp">
                        <p class="lead width">We grow brands by making decisions that are rooted in business strategy.</p>
                    </div>
                    <div class="row os-animation" data-os-animation="fadeInUp">
                        <div class="col-md-3 team-details os-animation text-center" data-os-animation="bounceIn">
                            <figure class="team-profile"><!-- 800 X 966 --><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/team/1.jpg" alt="team-01" />
                                <figcaption class="text-center our-team">
                                    <p class="content-white text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <div class="orange-line"></div>
                                    <div class="social"> <a href="http://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a> <a href="http://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a> <a href="http://plus.google.com/" target="_blank"><i class="fa fa-google-plus"></i></a></div>
                                </figcaption>
                            </figure>
                            <div class="namerol"> <span>Akbar</span>
                                <div class="orange-line text-center"></div>
                                <p class="content">Founder and ceo</p>
                            </div>
                        </div>
                        <div class="col-md-3 team-details os-animation text-center" data-os-animation="bounceIn">
                            <figure class="team-profile"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/team/2.jpg" alt="team-02" />
                                <figcaption class="text-center our-team">
                                    <p class="content-white text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <div class="orange-line"></div>
                                    <div class="social"> <a href="http://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a> <a href="http://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a> <a href="http://plus.google.com/" target="_blank"><i class="fa fa-google-plus"></i></a></div>
                                </figcaption>
                            </figure>
                            <div class="namerol"> <span>Upin</span>
                                <div class="orange-line text-center"></div>
                                <p class="content">creative studio head</p>
                            </div>
                        </div>
                        <div class="col-md-3 team-details os-animation text-center" data-os-animation="bounceIn">
                            <figure class="team-profile"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/team/3.jpg" alt="team-03" />
                                <figcaption class="text-center our-team">
                                    <p class="content-white text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <div class="orange-line"></div>
                                    <div class="social"> <a href="http://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a> <a href="http://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a> <a href="http://plus.google.com/" target="_blank"><i class="fa fa-google-plus"></i></a></div>
                                </figcaption>
                            </figure>
                            <div class="namerol"> <span>Ipin</span>
                                <div class="orange-line text-center"></div>
                                <p class="content">magento developer</p>
                            </div>
                        </div>
                        <div class="col-md-3 team-details os-animation text-center" data-os-animation="bounceIn">
                            <figure class="team-profile"><img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/team/4.jpg" alt="team-04" />
                                <figcaption class="text-center our-team">
                                    <p class="content-white text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                    <div class="orange-line"></div>
                                    <div class="social"> <a href="http://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a> <a href="http://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a> <a href="http://plus.google.com/" target="_blank"><i class="fa fa-google-plus"></i></a></div>
                                </figcaption>
                            </figure>
                            <div class="namerol"> <span>Dudung</span>
                                <div class="orange-line text-center"></div>
                                <p class="content">Logo / branding designer</p>
                            </div>
                        </div>
                    </div>
                    <div class="text-center row os-animation" data-os-animation="fadeInUp">
                        <p class="light">Creative thinkers, clever developer and marketing</p>
                        <p class="lead big">superheroes apply here.</p>
                        <p class="label">we're hiring</p>
                    </div>
                </div>
            </section>
            <!-- team end --> 

            <!-- counter -->
            <section id="conter-box" class="conter-box">
                <div class="color-overlay">
                    <div class="container">
                        <div class="row os-animation" data-os-animation="fadeInUp">
                            <div class="col-md-3 col-sm-5 text-center">
                                <div id="conterbox-01" class="counterBox counterWithAnimation" data-delay="400" data-animation="fade-in-left" data-countNmber="312"> <span class="counterBoxNumber">312</span>
                                    <div class="orange-line"></div>
                                    <h6 class="counterBoxDetails">Pizzas Ordered</h6>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-5 text-center">
                                <div id="conterbox-02" class="counterBox counterWithAnimation" data-delay="400" data-animation="fade-in-left" data-countNmber="980"> <span class="counterBoxNumber">980</span>
                                    <div class="orange-line"></div>
                                    <h6 class="counterBoxDetails">Happy Clients</h6>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-5 text-center">
                                <div id="conterbox-03" class="counterBox counterWithAnimation" data-delay="400" data-animation="fade-in-left" data-countNmber="810"> <span class="counterBoxNumber">810</span>
                                    <div class="orange-line"></div>
                                    <h6 class="counterBoxDetails">Projects Completed</h6>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-5 last text-center">
                                <div id="conterbox-04" class="counterBox counterWithAnimation" data-delay="400" data-animation="fade-in-left" data-countNmber="600"> <span class="counterBoxNumber">600</span>
                                    <div class="orange-line"></div>
                                    <h6 class="counterBoxDetails">Comments</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- counter --> 

            <!-- client logos -->
            <section class="client-logos">
                <div class="color-overlay">
                    <div class="container">
                        <div class="row os-animation" data-os-animation="bounceIn">
                            <div class="clients-slider text-center">
                                <ul class="slides">
                                    <li><img alt="Client Logo" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/client/1.png" /></li>
                                    <li><img alt="Client Logo" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/client/2.png" /></li>
                                    <li><img alt="Client Logo" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/client/3.png" /></li>
                                    <li><img alt="Client Logo" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/images/client/4.png" /></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- client logos end  --> 

            <!-- contact -->
            <section id="contact" class="contact gray-bg">
                <div class="container">
                    <div class="row border-bottom os-animation text-center" data-os-animation="fadeInUp">
                        <div class="col-md-6 col-sm-6 title-text border-right">
                            <h2 class="title">Contact</h2>
                        </div>
                        <div class="col-md-6 col-sm-6 simple-text">
                            <p class="description text-left">How we can help you. We like to talk and on the strength of that you are invited for a coffee at our head office.</p>
                        </div>
                    </div>
                    <div class="row contact-info os-animation" data-os-animation="fadeInUp">
                        <div class="col-md-6 col-sm-6 left-part">
                            <div class="head"> <span class="contact-title">how to reach us</span>
                                <p class="content contact-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                            <div class="head"> <span class="contact-title">our address</span>
                                <p class="content contact-text address">Sturlly Technologies<br>
                                    PO Box 16122, Collins Street West,<br>
                                    Victoria 8007, United States.</p>
                            </div>
                            <ul class="icon-list">
                                <li><i class="fa fa-phone"></i>+61 123 456 7890</li>
                                <li class="divider"></li>
                                <li><i class="fa fa-envelope-o"></i><a href="mailto:no-reply@domain.com">no-reply@domain.com</a></li>
                                <li class="divider"></li>
                                <li><i class="fa fa-globe"></i><a href="javascript:;">www.domain.com</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 col-sm-6 right-part">
                            <div class="form-group">
                                <form action="javascript:void(0)" method="post">
                                    <input class="form-control" name="name" placeholder="Your Name" type="text">
                                    <input class="form-control" name="email" placeholder="Your Email" type="text">
                                    <input class="form-control" name="website" placeholder="Your Website" type="text">
                                    <textarea class="form-control" placeholder="Your Comment" name="comment"></textarea>
                                    <button id="submit-button" class="small-button text-left">Send message</button>
                                </form>
                            </div>
                            <div id="success"></div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact end --> 

            <!-- footer -->
            <footer id="footer" class="footer">
                <div class="color-overlay">
                    <div class="container">
                        <div class="row os-animation" data-os-animation="bounceIn">
                            <ul class="social footer-social text-center">
                                <li><a href="http://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="http://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="http://www.linkedin.com/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="http://www.youtube.com/" target="_blank"><i class="fa fa-youtube"></i></a></li>
                                <li><a href="http://www.dribbble.com/" target="_blank"><i class="fa fa-dribbble"></i></a></li>
                                <li><a href="javascript:;"><i class="fa fa-rss"></i></a></li>
                            </ul>
                        </div>
                        <div class="row os-animation" data-os-animation="bounceIn">
                            <div class="transparent-line"></div>
                        </div>
                        <div class="row os-animation" data-os-animation="bounceIn">
                            <div class="text-center content-white copy">
                                <p> © 2024. All rights reserved. Powered by <a style="color: #fff;" href="https://websidn.com" target="_blank">Websidn</a>: Homeweb by <a style="color: #fff;" href="https://newus.id" target="_blank">Newus Technology</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- footer end --> 

            <!-- scroll to top --> 
            <a href="javascript:;" class="scrollToTop"><i class="fa fa-angle-up"></i></a> 
            <!-- scroll to top End... --> 

        </div>
        <!-- main page end --> 
        <!-- javascript  -->  
        <!-- jQuery --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/jquery.js"></script>
        <!-- page loading -->  
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/loader.min.js"></script>
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/preloader.js"></script>
        <!-- smoth hover --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/hover.min.js"></script> 
        <!-- parallax background --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/parallel.min.js"></script> 
        <!-- jQuery UI --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/jquery-ui.min.js"></script> 
        <!-- modernizr --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/modernizr.custom.js"></script> 
        <!-- smooth page scrolling --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/smooth-scroll.js"></script> 
        <!-- custom javascript  --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/custom.js"></script> 
        <!-- counter  --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/conter.js"></script> 
        <!-- bootstrap  --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/bootstrap-custom.js"></script> 
        <!-- portfolio  --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/portfolio.js"></script> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/jquery.nav.js"></script> 
        <!-- portfolio  --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/imagesloaded.pkgd.min.js"></script> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/cbpGridGallery.js"></script> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/classie.js"></script> 
        <!-- custom scrollbar  --> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/custom-scrollbar.min.js"></script> 
        <!-- google map API --> 
       <script type="text/javascript" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/http://maps.googleapis.com/maps/api/js?sensor=true"></script>
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/map.js"></script> 
        <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/js/load-gridgallery.js"></script>
    </body>
</html>
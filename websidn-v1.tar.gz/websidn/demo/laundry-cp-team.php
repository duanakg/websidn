<?php 
/*

* Template Name: laundry cp team

*/
?>
<!DOCTYPE HTML>
<html>
<head>
<meta  charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SuperLaundry</title> 

<!-- Favicons -->

<link rel="shortcut icon" href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/favicon.png">

<!-- Fonts -->

<link href='<?php echo esc_url(get_template_directory_uri());  ?>https://fonts.googleapis.com/css?family=Hind:300,400,500,600,700,300' rel='stylesheet' type='text/css'>
<link href='<?php echo esc_url(get_template_directory_uri());  ?>https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

<!-- Styles -->

<link href="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/css/style.css" rel="stylesheet"  media="screen">
</head>
<body>

  <!-- Loader -->

  	<div class="loader">
   	<div class="loader-brand"><img alt="" class="img-responsive center-block" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/brand.png"></div>
   </div>

	  <!-- Header -->

		<header id="top">
	      <div class="navbar navbar-2 affix">
		      <div class="container">
		        <div class="navbar-header">
		          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		          </button> 
		          <a href="#top" class="brand js-target-scroll">
		            <img class="brand-white" alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/brand-white.png">
		            <img class="brand-dark" alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/brand.png">
		          </a>
		        </div>
		        <div class="collapse navbar-collapse" id="navbar-collapse">
		            <ul class="nav navbar-nav navbar-right">                                                   
			            <li>
			            	<a href="<?= site_url('laundry cp')?>" class="js-target-scroll">Home</a>
			            </li>
			            <li>
			            	<a href="<?= site_url('laundry cp service')?>" class="js-target-scroll">Services</a>
			            </li>
			            <li>
			            	<a href="<?= site_url('laundry cp about')?>" class="js-target-scroll">About</a>
			            </li>
			            <li class="active">
			            	<a href="<?= site_url('laundry cp team')?>" class="js-target-scroll">Team</a>
			            </li>
			            <li>
			            	<a href="<?= site_url('laundry cp contact')?>" class="js-target-scroll">Contact</a>
			            </li>
						<li>
			            	<a href="<?= site_url('laundry cp blog')?>" class="js-target-scroll">Blog</a>
			            </li>
			         </ul>
		        </div>
		      </div>
	      </div>
		</header>

			<!-- Masthead -->

			<div class="masthead">
				<div class="masthead-entry-3 text-right parallax" data-stellar-background-ratio="0.3">
				   <div class="inner rel-1">
					   <div class="container">
						  <h2 class="page-subtitle wow fadeInDown">Our Team</h2>
							 <h1 class="wow fadeInUp">Super <span class="underline">Laundry</span></h1>
					</div>
					<div class="entry-line"></div>
				</div>
			   </div>
		  </div>

		<!-- Main -->

	   <main class="main">

			<!-- Team -->

			<section id="team" class="team-3 text-center section">
			   <div class="container">
			      <div class="row">
			        <header class="text-center col-md-8 col-md-offset-2">
			        	<h2>Team</h2>
			        	<p class="section-entry">Some of our recent work of the hundreds that we have for our customers around the world are displayed in Fusce lacinia arcu et nulla. Nulla vitae mauris non felis mollis faucipus.</p>
			        </header>
			      </div>
			      <div class="section-body">
			      	<div class="row-base row">
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/team3/1.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Rahmat</h3>
					      				<p class="profile-spec">Ceo / Co-fuder</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/team3/2.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Novan</h3>
					      				<p class="profile-spec">Admin</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/team3/3.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Kamal</h3>
					      				<p class="profile-spec">Admin</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
				      	<div class="col-base col-sm-6 col-md-3">
				      		<figure class="team-profile-2">
				      			<div class="image-holder image-holder-gradient"><img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/team3/4.jpg"></div>
				      			<figcaption>
				      				<div class="profile-info">
					      				<h3 class="profile-name">Mail</h3>
					      				<p class="profile-spec">Admin</p>
					      				<div class="team-social social-round">
							   	   		<a href="#" class="fa fa-facebook"></a>
							   	   		<a href="#" class="fa fa-twitter"></a>
							   	   		<a href="#" class="fa fa-pinterest-p"></a>
							   	   		<a href="#" class="fa fa-flickr"></a>
							      	   </div>
				      				</div>
				      			</figcaption>
				      		</figure>
				      	</div>
			      	</div>
			      </div>
			   </div>
			</section>

	   </main>


	   <!-- Footer -->

	   <footer class="footer">
	   	<section class="section bgc-dark">
	   		<div class="container rel-1">
	   			<a href="#top" class="scroll-top hvr-wobble-vertical js-target-scroll">
	   				<i class="fa fa-chevron-up"></i>
	   			</a>
	   			<div class="row-base row">
	   				<aside style="display: none;" class="bottom-widget-posts col-footer col-base col-md-6 col-lg-4">
							<h2 class="bottom-widget-title">News Post</h2>
							<ul class="bottom-post-list">
								<li>
									<div class="bottom-post-img">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/posts/1-75x75px.jpg"></a>
									</div>
									<div class="media-body">
										<h3><a href="#">Tips Useful For Web Designers</a></h3>
										<p>Phasellus pulvinar iaculis nunc at placerat. Sed porta sollicitudin</p>
										<ul class="bottom-post-meta">
											<li><a href="#">Simon McCool </a></li>
											<li>2 Weeks ago</li>
											<li>Views 3,098</li>
										</ul>
									</div>
								</li>
								<li>
									<div class="bottom-post-img">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/posts/2-75x75px.jpg"></a>
									</div>
									<div class="media-body">
										<h3><a href="#">Tips Useful For Designers</a></h3>
										<p>Phasellus pulvinar iaculis nunc at placerat. Sed porta sollicitudin</p>
										<ul class="bottom-post-meta">
											<li><a href="#">Simon McCool </a></li>
											<li>2 Weeks ago</li>
											<li>Views 3,098</li>
										</ul>
									</div>
								</li>
							</ul>
	   				</aside>
	   				<aside style="display: none;" class="bottom-widget-gallery col-footer col-base col-md-6 col-lg-4">
							<h2 class="bottom-widget-title">Favorites Flickr</h2>
							<ul class="bottom-gallery-list">
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/widget-gallery/1.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/widget-gallery/2.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/widget-gallery/3.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/widget-gallery/4.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/widget-gallery/5.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
								<li>
									<div class="link-overlay">
				      				<a href="#">
				      					<img alt="" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/widget-gallery/6.jpg">
				      					<i class="fa fa-unlink"></i>
				      				</a>
				      			</div>
								</li>
							</ul>
							<div class="widget-gallery-control">
								<a href="#" class="more text-white">
									<i class="fa fa-chevron-circle-right"></i>
									<span>View more</span>
								</a>
							</div>
	   				</aside>
	   				<aside class="bottom-widget-text col-footer col-base col-12">
							<img alt="" class="img-responsive" src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/img/brand-white.png">
							<div class="text-content">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vehicula mollis urna vel dignissim. Integer tincidunt viverra est, non congue.</p>
								<p>Sed dolor velit, convallis quis erat in, molestie eleifend enim. Integer eu metus at orci scelerisque rutrum. Vivamus condimentum, ipsum </p>
							</div>
							<div class="social social-round">
					   		<a href="#" class="fa fa-facebook"></a>
					   		<a href="#" class="fa fa-twitter"></a>
					   		<a href="#" class="fa fa-linkedin"></a>
					   		<a href="#" class="fa fa-google-plus"></a>
					   		<a href="#" class="fa fa-pinterest-p"></a>
					   		<a href="#" class="fa fa-flickr"></a>
					   		<a href="#" class="fa fa-dribbble"></a>
				   	   </div>
	   				</aside>
	   			</div>
	   		</div>
	   	</section>
	   	<div class="footer-bottom">
	   		<div class="container">
		   		<div class="row-base row">
		   			<div class="copy col-base col-md-6">
		   				© 2024. All rights reserved. Powered by <a href="https://websidn.com" target="_blank">Websidn</a>: SuperLaundry by <a href="https://newus.id" target="_blank">Newus Technology</a>
		   			</div>
		   		</div>
	   		</div>
	   	</div>
	   </footer>

<!-- Scripts -->

<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/jquery.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/bootstrap.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/smoothscroll.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/wow.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/imagesloaded.pkgd.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/isotope.pkgd.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/owl.carousel.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/jquery.validate.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/jquery.stellar.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/jquery.easypiechart.min.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/interface.js"></script>
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/https://maps.googleapis.com/maps/api/js?v=3.exp.js"></script> 
<script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/laundry-cp/js/gmap.js"></script> 
</body>
</html>
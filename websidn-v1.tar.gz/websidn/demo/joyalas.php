<?php 
/*

* Template Name: Joyalas

*/
?>

<!DOCTYPE html>
<html lang="id-ID">

<head>
  <base>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>JOYALAS - Layanan Jasa Bengkel Las Listrik</title>
  <meta name="description" content="Layanan Jasa Bengkel Las Listrik Terbaik Di Lampung" />
  <!-- <link rel="icon" href="26387fa4f5b1e3f7b6217b27d79bf264.png" type="image/png" sizes="16x16">
  <link rel="icon" href="2d0b56e7e51cf11036ad8734bdb67e2d.png" type="image/png" sizes="32x32"> -->
  <!-- <link rel="apple-touch-icon" href="" sizes="180x180"> -->
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?= site_url('')?>">
  <meta property="og:title" content="Beranda">
  <meta property="og:image" content="<?php echo esc_url(get_template_directory_uri());  ?>screenshot.png">
  <meta property="og:image:type" content="image/png">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta name="twitter:card" content="summary_large_image">
  <style>
    :root {
      --ffsd: 0px;
      --1vw: calc((100vw - var(--sbw, 0px)) / 100);
      --1vh: var(--inner1Vh, 1vh);
    }

    @media (prefers-reduced-motion: reduce) {
      .animated {
        animation: none !important;
      }
    }

    html {
      zoom: var(--rzf, 1);
      font-size: max(calc(min(var(--1vw, 1vw), 13.66px) * var(--rfso, 1)), var(--minfs, 0px));
      -webkit-text-size-adjust: 100%;
      scroll-behavior: smooth;
    }

    body {
      font-size: calc(1rem * var(--bfso, 1));
    }

    body,
    html,
    p,
    ul,
    ol,
    li {
      margin: 0;
      padding: 0;
      font-synthesis: none;
      font-kerning: none;
      font-variant-ligatures: none;
      font-feature-settings: "kern" 0, "calt" 0, "liga" 0, "clig" 0, "dlig" 0, "hlig" 0;
      font-family: unset;
      -webkit-font-smoothing: subpixel-antialiased;
      -moz-osx-font-smoothing: grayscale;
      text-rendering: geometricprecision;
      white-space: normal;
    }

    li {
      text-align: unset;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    img {
      -webkit-user-drag: none;
      -moz-user-drag: none;
      -o-user-drag: none;
      user-drag: none;
      -webkit-touch-callout: none;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2e6cd6edd8c613b3bb97fea786423021.woff2);
      font-style: normal;
      font-weight: 400;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/5d3de1b2e62932b8223d7f271173fe57.woff2);
      font-style: normal;
      font-weight: 700;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9845755400f2c24d7c04b24e20caa6c5.woff2);
      font-style: italic;
      font-weight: 400;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/b732ddf09155ab8e9d675a4a9e6fe3db.woff2);
      font-style: italic;
      font-weight: 700;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2e6cd6edd8c613b3bb97fea786423021.woff2);
      font-style: normal;
      font-weight: 100;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9845755400f2c24d7c04b24e20caa6c5.woff2);
      font-style: italic;
      font-weight: 100;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2e6cd6edd8c613b3bb97fea786423021.woff2);
      font-style: normal;
      font-weight: 200;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9845755400f2c24d7c04b24e20caa6c5.woff2);
      font-style: italic;
      font-weight: 200;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2e6cd6edd8c613b3bb97fea786423021.woff2);
      font-style: normal;
      font-weight: 300;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9845755400f2c24d7c04b24e20caa6c5.woff2);
      font-style: italic;
      font-weight: 300;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2e6cd6edd8c613b3bb97fea786423021.woff2);
      font-style: normal;
      font-weight: 500;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9845755400f2c24d7c04b24e20caa6c5.woff2);
      font-style: italic;
      font-weight: 500;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/5d3de1b2e62932b8223d7f271173fe57.woff2);
      font-style: normal;
      font-weight: 600;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/b732ddf09155ab8e9d675a4a9e6fe3db.woff2);
      font-style: italic;
      font-weight: 600;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/5d3de1b2e62932b8223d7f271173fe57.woff2);
      font-style: normal;
      font-weight: 800;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/b732ddf09155ab8e9d675a4a9e6fe3db.woff2);
      font-style: italic;
      font-weight: 800;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/5d3de1b2e62932b8223d7f271173fe57.woff2);
      font-style: normal;
      font-weight: 900;
    }

    @font-face {
      font-family: YADW1-vpsoc-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/b732ddf09155ab8e9d675a4a9e6fe3db.woff2);
      font-style: italic;
      font-weight: 900;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/e5eb27e7c8df405c5aef73c5ff98462d.woff2);
      font-style: normal;
      font-weight: 400;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/fba54f633ce128d1b2c99eaac9b1faab.woff2);
      font-style: normal;
      font-weight: 700;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/73ca4f826fb90089741830fda43eeb41.woff2);
      font-style: italic;
      font-weight: 400;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f5a77da3b70274f636a82c36129dc468.woff2);
      font-style: italic;
      font-weight: 700;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/c59d1b8fed4e8e7f85a6ce3e4aee345b.woff2);
      font-style: normal;
      font-weight: 100;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/04b814e3af1d9256f0cda6a63bf2ec01.woff2);
      font-style: italic;
      font-weight: 100;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/c59d1b8fed4e8e7f85a6ce3e4aee345b.woff2);
      font-style: normal;
      font-weight: 200;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/04b814e3af1d9256f0cda6a63bf2ec01.woff2);
      font-style: italic;
      font-weight: 200;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/e5eb27e7c8df405c5aef73c5ff98462d.woff2);
      font-style: normal;
      font-weight: 300;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/73ca4f826fb90089741830fda43eeb41.woff2);
      font-style: italic;
      font-weight: 300;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2fb3e3dc31208bef0a1d63cac8bcfff3.woff2);
      font-style: normal;
      font-weight: 500;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/03c556f42acd0e493a1b75b1ab4d08c0.woff2);
      font-style: italic;
      font-weight: 500;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2fb3e3dc31208bef0a1d63cac8bcfff3.woff2);
      font-style: normal;
      font-weight: 600;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/03c556f42acd0e493a1b75b1ab4d08c0.woff2);
      font-style: italic;
      font-weight: 600;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/fba54f633ce128d1b2c99eaac9b1faab.woff2);
      font-style: normal;
      font-weight: 800;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f5a77da3b70274f636a82c36129dc468.woff2);
      font-style: italic;
      font-weight: 800;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/fba54f633ce128d1b2c99eaac9b1faab.woff2);
      font-style: normal;
      font-weight: 900;
    }

    @font-face {
      font-family: YAFdJkmvhGI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f5a77da3b70274f636a82c36129dc468.woff2);
      font-style: italic;
      font-weight: 900;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/88a36cab6d7cfa75bff7e49535b9642a.woff2);
      font-style: normal;
      font-weight: 400;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/c19f8e9cab364abc00a750036f731e21.woff2);
      font-style: normal;
      font-weight: 700;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/2939e26d0be644944cd621be7bec5f5e.woff2);
      font-style: italic;
      font-weight: 400;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/267ca74019c66328f093f6614fe3106e.woff2);
      font-style: italic;
      font-weight: 700;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/22ff9d894b6467b3ddab0f1989a2cb4d.woff2);
      font-style: normal;
      font-weight: 100;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/aeba314cd216c72b97019a6e8c17c9a5.woff2);
      font-style: italic;
      font-weight: 100;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/22ff9d894b6467b3ddab0f1989a2cb4d.woff2);
      font-style: normal;
      font-weight: 200;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/aeba314cd216c72b97019a6e8c17c9a5.woff2);
      font-style: italic;
      font-weight: 200;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/22ff9d894b6467b3ddab0f1989a2cb4d.woff2);
      font-style: normal;
      font-weight: 300;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/aeba314cd216c72b97019a6e8c17c9a5.woff2);
      font-style: italic;
      font-weight: 300;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/6f953f3e7ac9d894a97d59a06afcfa7b.woff2);
      font-style: normal;
      font-weight: 500;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/b146a0e8f0e873592940bcc60a355c0c.woff2);
      font-style: italic;
      font-weight: 500;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/3dae3800fab4aad097008bba4dfa94c1.woff2);
      font-style: normal;
      font-weight: 600;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/0f51da86a058aef1bb585a64cf664ab7.woff2);
      font-style: italic;
      font-weight: 600;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/c19f8e9cab364abc00a750036f731e21.woff2);
      font-style: normal;
      font-weight: 800;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/267ca74019c66328f093f6614fe3106e.woff2);
      font-style: italic;
      font-weight: 800;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/71d66fa3f70c070b9427b4baf1980061.woff2);
      font-style: normal;
      font-weight: 900;
    }

    @font-face {
      font-family: YAFdJs2qTWQ-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/1aaf8c95b881644a76961b6db0059fc0.woff2);
      font-style: italic;
      font-weight: 900;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/8f7934b3d45567e9cf1f541e008969a9.woff2);
      font-style: normal;
      font-weight: 400;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9340013c7d177c83df1edab0cf96ac10.woff2);
      font-style: normal;
      font-weight: 700;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/e005df7c7c34fefde116ba9b5a0e51e1.woff2);
      font-style: italic;
      font-weight: 400;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/83b37f2dcbb18c810da7cfa915708210.woff2);
      font-style: italic;
      font-weight: 700;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/8f7934b3d45567e9cf1f541e008969a9.woff2);
      font-style: normal;
      font-weight: 100;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/e005df7c7c34fefde116ba9b5a0e51e1.woff2);
      font-style: italic;
      font-weight: 100;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/8f7934b3d45567e9cf1f541e008969a9.woff2);
      font-style: normal;
      font-weight: 200;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/e005df7c7c34fefde116ba9b5a0e51e1.woff2);
      font-style: italic;
      font-weight: 200;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/8f7934b3d45567e9cf1f541e008969a9.woff2);
      font-style: normal;
      font-weight: 300;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/e005df7c7c34fefde116ba9b5a0e51e1.woff2);
      font-style: italic;
      font-weight: 300;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/8f7934b3d45567e9cf1f541e008969a9.woff2);
      font-style: normal;
      font-weight: 500;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/e005df7c7c34fefde116ba9b5a0e51e1.woff2);
      font-style: italic;
      font-weight: 500;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9340013c7d177c83df1edab0cf96ac10.woff2);
      font-style: normal;
      font-weight: 600;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/83b37f2dcbb18c810da7cfa915708210.woff2);
      font-style: italic;
      font-weight: 600;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9340013c7d177c83df1edab0cf96ac10.woff2);
      font-style: normal;
      font-weight: 800;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/83b37f2dcbb18c810da7cfa915708210.woff2);
      font-style: italic;
      font-weight: 800;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/9340013c7d177c83df1edab0cf96ac10.woff2);
      font-style: normal;
      font-weight: 900;
    }

    @font-face {
      font-family: YAD1aU3sLnI-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/83b37f2dcbb18c810da7cfa915708210.woff2);
      font-style: italic;
      font-weight: 900;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f8f199f09526f79e87644ed227e0f651.woff2);
      font-style: normal;
      font-weight: 400;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/98c4d2c0223fc8474641c77f923528e9.woff2);
      font-style: normal;
      font-weight: 700;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/d257a7100844bc3f98c9021168b6249e.woff2);
      font-style: italic;
      font-weight: 400;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/1060345c54d396e76d73f1da7ee200bd.woff2);
      font-style: italic;
      font-weight: 700;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f8f199f09526f79e87644ed227e0f651.woff2);
      font-style: normal;
      font-weight: 100;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/d257a7100844bc3f98c9021168b6249e.woff2);
      font-style: italic;
      font-weight: 100;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f8f199f09526f79e87644ed227e0f651.woff2);
      font-style: normal;
      font-weight: 200;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/d257a7100844bc3f98c9021168b6249e.woff2);
      font-style: italic;
      font-weight: 200;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f8f199f09526f79e87644ed227e0f651.woff2);
      font-style: normal;
      font-weight: 300;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/d257a7100844bc3f98c9021168b6249e.woff2);
      font-style: italic;
      font-weight: 300;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/f8f199f09526f79e87644ed227e0f651.woff2);
      font-style: normal;
      font-weight: 500;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/d257a7100844bc3f98c9021168b6249e.woff2);
      font-style: italic;
      font-weight: 500;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/98c4d2c0223fc8474641c77f923528e9.woff2);
      font-style: normal;
      font-weight: 600;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/1060345c54d396e76d73f1da7ee200bd.woff2);
      font-style: italic;
      font-weight: 600;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/98c4d2c0223fc8474641c77f923528e9.woff2);
      font-style: normal;
      font-weight: 800;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/1060345c54d396e76d73f1da7ee200bd.woff2);
      font-style: italic;
      font-weight: 800;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/98c4d2c0223fc8474641c77f923528e9.woff2);
      font-style: normal;
      font-weight: 900;
    }

    @font-face {
      font-family: YACgEZ1cb1Q-0;
      src: url(<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/fonts/1060345c54d396e76d73f1da7ee200bd.woff2);
      font-style: italic;
      font-weight: 900;
    }

    @media (max-width: 375px) {
      #m3SYDT9FKCM13HjP {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #llJYRpJEKd1IcIhk {
        grid-template-columns: 0 462.37715107%;
        left: -181.18857553%;
        grid-template-rows: 0 100%;
      }

      #r1EFlTFVXm2e0A3n {
        grid-area: 2 / 2 / 5 / 6;
        position: relative;
      }

      #TfH5lWrMgLRuuMdS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(6.57576em - var(--ffsd)));
      }

      #SXuGeBBgCKw0Kry7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 6.57576em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #YtRQL1tNQCJRcW5m {
        min-width: 27.74791667rem;
      }

      #MvKcRfpmrfune5AA {
        grid-area: 3 / 7 / 4 / 8;
        position: relative;
      }

      #jQOTOlXn1E4QD7ph {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(14.44252859em - var(--ffsd)));
      }

      #yTLbXVvBvrvkVFKM {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 14.44252859em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #kXL4EaoQAP8c1x5h {
        min-width: 91.6rem;
      }

      #UKdOD4U3PWwpTe0d {
        grid-area: 6 / 3 / 7 / 10;
        position: relative;
      }

      #Ta7XH3vixYn13PeA {
        stroke-width: calc(100rem * 0.0 / 375.0);
      }

      #zP5Shnye9HLNIW3b {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #s8b51UQOMuly5AiR {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.62224em - var(--ffsd)));
      }

      #wOCJaesTt6mgvpfr {
        min-width: 57.67218424rem;
      }

      #p0fSmdua70RtuE0X {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #haTF8OYQSfrQtohf {
        grid-template-columns: 0 1.06666667rem 57.53885091rem 1.06666667rem;
        grid-template-rows: 0 minmax(1.06666667rem, max-content) minmax(17.32112924rem, max-content) minmax(1.06666667rem, max-content);
      }

      #GmUp5asCngXTjcfw {
        grid-area: 8 / 4 / 9 / 9;
        grid-template-columns: 0 59.67218424rem;
        grid-template-rows: 0 minmax(19.45446257rem, max-content);
      }

      #tMAOrNb5A0aiK2Uu {
        grid-area: 8 / 4 / 9 / 9;
        position: relative;
      }

      #GEbfawZRSV21NOsR {
        grid-area: 10 / 5 / 11 / 11;
        position: relative;
      }

      #GvWlHEPhc7hdjMiF {
        grid-template-columns: 4.26666667rem 0 0 0 11.46227452rem 3.73418405rem 27.61458333rem 16.86114234rem 31.79448243rem 0 4.26666667rem;
        grid-template-rows: minmax(4.26666667rem, max-content) minmax(2.32659193rem, max-content) minmax(7.87575733rem, max-content) minmax(1.25992526rem, max-content) minmax(61.29743807rem, max-content) minmax(51.50272341rem, max-content) minmax(9.84331521rem, max-content) minmax(19.45446257rem, max-content) minmax(6.4rem, max-content) minmax(91.46666667rem, max-content) minmax(4.26666667rem, max-content);
      }

      #EVsnVfWBFziIwED4 {
        min-height: calc(calc(14.5010183 * var(--1vh, 1vh)) - 7.25050915px);
      }

      #Hdri1aIl6ToYC0vq {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #KJgycpXEEH2PHiBZ {
        grid-template-columns: 0 417.52738679%;
        left: -158.7636934%;
        grid-template-rows: 0 100%;
      }

      #APYUUhkfOlsktt4U {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(9.29503582em - var(--ffsd)));
      }

      #MKY7BtHq4RLFEHWV {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 9.29503582em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #EnWZ5NJ4wXZGyG1y {
        min-width: 91.6rem;
      }

      #YvCdtM9eTGVI7Fjj {
        grid-area: 2 / 2 / 3 / 9;
        position: relative;
      }

      #XU61H5mU1Hegxyg1 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.55110933em - var(--ffsd)));
      }

      #EbMz9lWN05xkfKiu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.55110933em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #fTR14lQXntxrP3Id {
        min-width: 91.6rem;
      }

      #HshH9YO9PWARaZlp {
        grid-area: 4 / 3 / 5 / 10;
        position: relative;
      }

      #miRUNBfS6pd7arzU {
        grid-area: 6 / 6 / 9 / 11;
        position: relative;
      }

      #nDTM1IrvTJqPqaWt {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #qJ34bvUj1ts5ONJ2 {
        grid-area: 7 / 5 / 10 / 8;
        grid-template-columns: 0 55.85276954rem;
        grid-template-rows: 0 minmax(72.08876957rem, max-content);
      }

      #CVKDDezLgdkzgo3I {
        grid-area: 7 / 5 / 10 / 8;
        position: relative;
      }

      #PrcyQ85wjjB0o08u {
        grid-area: 8 / 4 / 11 / 7;
        position: relative;
      }

      #vgwhkg6IqrGkge5w {
        grid-template-columns: 4.26666667rem 0 0 17.48361715rem 11.44587862rem 41.57788833rem 2.82900259rem 18.13027997rem 0 0 4.26666667rem;
        grid-template-rows: minmax(4.26666667rem, max-content) minmax(33.36253929rem, max-content) minmax(42.52443733rem, max-content) minmax(43.73093265rem, max-content) minmax(6.4rem, max-content) minmax(15.18077107rem, max-content) minmax(14.50513593rem, max-content) minmax(32.85126389rem, max-content) minmax(24.73236975rem, max-content) minmax(12.92375047rem, max-content) minmax(4.26666667rem, max-content);
      }

      #FP4D4N6LhJJOZuGj {
        min-height: calc(calc(13.09444523 * var(--1vh, 1vh)) - 6.54722261px);
      }

      #Etajan3P94FrCZA7 {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #PD7rGfJaSv9ew4C8 {
        grid-template-columns: 0 881.36191677%;
        left: -390.68095839%;
        grid-template-rows: 0 100%;
      }

      #K7Wrp4f1lV4ES9FE {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.54666667em - var(--ffsd)));
      }

      #wZeIsWv8ULwO9jcy {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.54666667em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #p7ihhOMm87c0ACEa {
        min-width: 91.6rem;
      }

      #fPv2t7YHnuejKHcU {
        grid-area: 2 / 2 / 3 / 7;
        position: relative;
      }

      #Tyc7EOWaz3bsR342 {
        grid-area: 4 / 3 / 5 / 8;
        position: relative;
      }

      #WXwIL7gFzMa67DCC {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #n5X4InqHj6OYLYsu {
        display: none;
      }

      #XldIT6cLv2fBUqKe {
        display: block;
      }

      #p4FFndj20RBGut1m {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #tdVKy05DzOadvHGI {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(6.0258802em - var(--ffsd)));
      }

      #tTqGqp9n1v6v5uis {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(6.0258802em - var(--ffsd)));
      }

      #Y5EhKDSdHrHmGzgW {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 6.0258802em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #iheXlR99lIzXx0Ne {
        min-width: 66rem;
      }

      #M6hbY4UwnTeNWRUt {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #yChP2nRcxzL1YOTN {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.33778133em - var(--ffsd)));
      }

      #LMwFKqTE7AJ7lbir {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.33778133em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #gHR2fRPhXDM6Hisl {
        min-width: 66rem;
      }

      #aCErBJkmtBUolALX {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #d11L9LwwZabvIXmW {
        grid-template-columns: 0 6.4rem 0 65.86666667rem 0 6.4rem;
        grid-template-rows: 0 minmax(9.22825606rem, max-content) minmax(14.78196409rem, max-content) minmax(1.51568587rem, max-content) minmax(10.64851729rem, max-content) minmax(9.22825606rem, max-content);
      }

      #OUm9F4uUfkGg3Gls {
        grid-template-columns: 0 78.66666667rem;
        grid-template-rows: 0 minmax(45.40267937rem, max-content);
      }

      #QgEfIIzf18D8RQKM {
        grid-template-columns: 0 6.4rem 78.66666667rem 6.4rem;
        grid-template-rows: 0 minmax(50.92532698rem, max-content) minmax(45.40267937rem, max-content) minmax(50.92532698rem, max-content);
      }

      #R4nH3NYK7paPPHzs {
        grid-area: 6 / 4 / 7 / 9;
        grid-template-columns: 0 91.46666667rem;
        grid-template-rows: 0 minmax(147.25333333rem, max-content);
      }

      #I86TgkNnnIdNV9mF {
        grid-area: 6 / 4 / 7 / 9;
        position: relative;
      }

      #BbzwfbFZPVrTIxUM {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #TpSjo6ksBYK1wmrg {
        display: none;
      }

      #Rb11CAnGbnPpu9vf {
        display: block;
      }

      #e2Ge0I5wUOeyD5zs {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #qyFXjYNNwMtVuZ89 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(6.25249753em - var(--ffsd)));
      }

      #rbiDzUNgYfDG2acu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 6.25249753em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #AZjTU9md2ADPAc0F {
        min-width: 66rem;
      }

      #i0XTZt0u3J9l3l1i {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #U7tJjD7Uh5gDxwn4 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.33778133em - var(--ffsd)));
      }

      #Za9xwVDCXA2pliP5 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.33778133em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #m2XOjdNXKmHeAHwO {
        min-width: 66rem;
      }

      #kLVpIMZoli7sYzrB {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #m9LXQfrbEmJr2k5p {
        grid-template-columns: 0 6.4rem 0 65.86666667rem 0 6.4rem;
        grid-template-rows: 0 minmax(9.70434848rem, max-content) minmax(15.62647665rem, max-content) minmax(1.51568587rem, max-content) minmax(9.92219143rem, max-content) minmax(9.70434848rem, max-content);
      }

      #hj6h0LScTtoij9rW {
        grid-template-columns: 0 78.66666667rem;
        grid-template-rows: 0 minmax(46.47305092rem, max-content);
      }

      #ufRvNwcU96kqYNf4 {
        grid-template-columns: 0 6.4rem 78.66666667rem 6.4rem;
        grid-template-rows: 0 minmax(50.39014121rem, max-content) minmax(46.47305092rem, max-content) minmax(50.39014121rem, max-content);
      }

      #CENlSefUjhP6YW5b {
        grid-area: 8 / 5 / 9 / 10;
        grid-template-columns: 0 91.46666667rem;
        grid-template-rows: 0 minmax(147.25333333rem, max-content);
      }

      #eG3ccb8SJFeXwIvJ {
        grid-area: 8 / 5 / 9 / 10;
        position: relative;
      }

      #NWUTtg2IQDYEhSaQ {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #Au7GoA1EJkmz0gKh {
        display: none;
      }

      #nNIE5ZjGqDvYRj1d {
        display: block;
      }

      #s5HzwVAW1mrDp3Uf {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #HIij7OCEh7guCFzz {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.83608816em - var(--ffsd)));
      }

      #dH3MoNpEwXMeCUcv {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.83608816em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #cRBRg221gqzDGxvu {
        min-width: 66rem;
      }

      #FElht4Ltr4nzQ0gg {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #LD9IOLtK8K47oyj9 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.33778212em - var(--ffsd)));
      }

      #GW2f5b3rlSSixum7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.33778212em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ACpGnJk4cZWHjwN4 {
        min-width: 66rem;
      }

      #YHrHHD87BdlARGfK {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #aKAA6U6yEUFEdwiB {
        grid-template-columns: 0 6.4rem 0 65.86666667rem 0 6.4rem;
        grid-template-rows: 0 minmax(13.5425169rem, max-content) minmax(7.00108095rem, max-content) minmax(1.51568587rem, max-content) minmax(10.5384869rem, max-content) minmax(13.5425169rem, max-content);
      }

      #z0bY5zYMRsmxpb4L {
        grid-template-columns: 0 78.66666667rem;
        grid-template-rows: 0 minmax(46.14028751rem, max-content);
      }

      #u4z6oRNJ98jyVNor {
        grid-template-columns: 0 6.4rem 78.66666667rem 6.4rem;
        grid-template-rows: 0 minmax(50.55652291rem, max-content) minmax(46.14028751rem, max-content) minmax(50.55652291rem, max-content);
      }

      #hb5jrqAkCXjZoTXa {
        grid-area: 10 / 6 / 11 / 11;
        grid-template-columns: 0 91.46666667rem;
        grid-template-rows: 0 minmax(147.25333333rem, max-content);
      }

      #xp0ymJ30yKJUmkXi {
        grid-area: 10 / 6 / 11 / 11;
        position: relative;
      }

      #ZMh7ecpl7smJEubs {
        grid-template-columns: 4.26666667rem 0 0 0 0 91.46666667rem 0 0 0 0 4.26666667rem;
        grid-template-rows: minmax(9.17333333rem, max-content) minmax(6.41323775rem, max-content) minmax(8.05333333rem, max-content) minmax(0.1508853rem, max-content) minmax(8rem, max-content) minmax(147.25333333rem, max-content) minmax(6.4rem, max-content) minmax(147.25333333rem, max-content) minmax(6.4rem, max-content) minmax(147.25333333rem, max-content) minmax(9.17333333rem, max-content);
      }

      #ISVkDXmJFMnWiq1K {
        min-height: calc(calc(27.64116968 * var(--1vh, 1vh)) - 13.82058484px);
      }

      #LtN1C7EnSNQGg89z {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #N4Tpdpnf4HghJVjr {
        grid-template-columns: 0 874.19779326%;
        left: -387.09889663%;
        grid-template-rows: 0 100%;
      }

      #Vc6Z6VzhJe15nxoy {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.54666667em - var(--ffsd)));
      }

      #Hiu5ffhXEx7BdDRZ {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.54666667em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #QXoE2maBBoNIF7Gr {
        min-width: 91.6rem;
      }

      #SlLTi6O24aPK1PQQ {
        grid-area: 2 / 2 / 3 / 7;
        position: relative;
      }

      #D9nPJ3DqM8BwWaHM {
        grid-area: 4 / 3 / 5 / 8;
        position: relative;
      }

      #lq2ZDpzWZEJvBMiM {
        display: none;
      }

      #LgXgkEOX3zElrFEM {
        display: block;
      }

      #uxnqO6yERfC4d65D {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ubGMOqeL5rvOuMqQ {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #gNE1pDRPU0FmfvzJ {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #wcHvYwrDbIHCRtHO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.55598888em - var(--ffsd)));
      }

      #oNwbURniyG6xEZN2 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.55598888em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #OAAB3fohcFyLYSft {
        min-width: 78.8rem;
      }

      #XlYyt0aMHu1Zh0hp {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #l0Q2nbieDbtvDa4I {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.51426538em - var(--ffsd)));
      }

      #j2c6GpMXEM9JHQu4 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.51426538em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GWVsMHfr8l8cFrc7 {
        min-width: 78.8rem;
      }

      #vileu7dt6s5TvraX {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #PyIzu2Slr4qCZW4c {
        grid-area: 6 / 4 / 7 / 9;
        grid-template-columns: 0 6.4rem 0 0 0 28.41004094rem 7.58776681rem 42.66885891rem 0 6.4rem;
        grid-template-rows: 0 minmax(17.48942617rem, max-content) minmax(28.4099273rem, max-content) minmax(8.02935459rem, max-content) minmax(5.497847rem, max-content) minmax(6.4rem, max-content) minmax(50.90683115rem, max-content) minmax(6.4618001rem, max-content) minmax(5.22610326rem, max-content) minmax(17.48942617rem, max-content);
      }

      #hJKy6v7Y1BQEtWBw {
        grid-area: 6 / 4 / 7 / 9;
        position: relative;
      }

      #ModsPUuKGeM9aeoC {
        display: none;
      }

      #eNI74A7dmWLhXMfg {
        display: block;
      }

      #N0NNQ9InTrpLFoFR {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #sOnczf1YqVUavn4q {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #Yf9A5IFd1HPZngBl {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #M4C1SZ1Dl6JYZrrm {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.55598888em - var(--ffsd)));
      }

      #eBBSxU69aAaJ4t6i {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.55598888em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #JEKIMuTIrrslKJoY {
        min-width: 78.8rem;
      }

      #Dt47wVyMxkdPTXKu {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #RuZHIV0XOwBNQvFf {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.51426538em - var(--ffsd)));
      }

      #XXI3z3eivyRQNAXD {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.51426538em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #Vew8JRHgXiDhwtsA {
        min-width: 78.8rem;
      }

      #ZJOgMyCQ7FBapqor {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #hUZCKysgaRhWfkMd {
        grid-area: 8 / 5 / 9 / 10;
        grid-template-columns: 0 6.4rem 0 0 0 28.41004094rem 7.58776681rem 42.66885891rem 0 6.4rem;
        grid-template-rows: 0 minmax(17.48942617rem, max-content) minmax(28.4099273rem, max-content) minmax(8.02935459rem, max-content) minmax(5.497847rem, max-content) minmax(6.4rem, max-content) minmax(50.90683115rem, max-content) minmax(6.4618001rem, max-content) minmax(5.22610326rem, max-content) minmax(17.48942617rem, max-content);
      }

      #bqItE7RCLOyv9rrN {
        grid-area: 8 / 5 / 9 / 10;
        position: relative;
      }

      #Wtde72kg8M6YwcMA {
        display: none;
      }

      #Jxv0NPP6UQRhz5Ra {
        display: block;
      }

      #iv1XCKpdSVjuCBKU {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ipvxIQqPGKvdy7s9 {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #isn5BP7r5XUWo3JL {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #zhcztrpvjlWNbTYO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.55598888em - var(--ffsd)));
      }

      #rbYxOfI8KuLu319s {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.55598888em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ODcjk0rSbCDnbjOX {
        min-width: 78.8rem;
      }

      #xD3maSGoVQRNCD0N {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #YZ1r4ouyXW9PTI9P {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.51426538em - var(--ffsd)));
      }

      #JGJ5JB5Kl8VZt7jR {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.51426538em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #UZYC6WCZAEKCjxAv {
        min-width: 78.8rem;
      }

      #tA4Agi2rzuBW6JML {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #knf3b6c1mVzKA7au {
        grid-area: 10 / 6 / 11 / 11;
        grid-template-columns: 0 6.4rem 0 0 0 28.41004094rem 7.58776681rem 42.66885891rem 0 6.4rem;
        grid-template-rows: 0 minmax(17.48942617rem, max-content) minmax(28.4099273rem, max-content) minmax(8.02935459rem, max-content) minmax(5.497847rem, max-content) minmax(6.4rem, max-content) minmax(50.90683115rem, max-content) minmax(6.4618001rem, max-content) minmax(5.22610326rem, max-content) minmax(17.48942617rem, max-content);
      }

      #qlIn6bf0FR92TyfT {
        grid-area: 10 / 6 / 11 / 11;
        position: relative;
      }

      #Zmq1BcGFaKOW7N0J {
        grid-template-columns: 4.26666667rem 0 0 0 0 91.46666667rem 0 0 0 0 4.26666667rem;
        grid-template-rows: minmax(9.17333333rem, max-content) minmax(6.41323775rem, max-content) minmax(8.05333333rem, max-content) minmax(0.1508853rem, max-content) minmax(8rem, max-content) minmax(145.91071575rem, max-content) minmax(6.4rem, max-content) minmax(145.91071575rem, max-content) minmax(6.4rem, max-content) minmax(145.91071575rem, max-content) minmax(9.17333333rem, max-content);
      }

      #X3JPx632LSRuAY4d {
        min-height: calc(calc(27.41648927 * var(--1vh, 1vh)) - 13.70824464px);
      }

      #uV27B7XrVHeA5mka {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #bKSg5iz4CZD3MEXc {
        grid-template-columns: 0 553.119763%;
        left: -226.5598815%;
        grid-template-rows: 0 100%;
      }

      #pDpxDsQDp1eh8Yid {
        grid-area: 2 / 11 / 5 / 20;
        position: relative;
      }

      #OyIXdjM3gEFMIKYH {
        grid-area: 3 / 9 / 6 / 19;
        position: relative;
      }

      #VWb2tvwkmBFDR6r8 {
        grid-area: 4 / 2 / 7 / 18;
        position: relative;
      }

      #a8b72Yi8nQo6EntT {
        grid-area: 8 / 3 / 9 / 21;
        position: relative;
      }

      #Qjm9rz6trR5oVzQt {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(7.31076096em - var(--ffsd)));
      }

      #FLP3ypFsLN95AyTg {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 7.31076096em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #sidsPanTaL76AHlA {
        min-width: 91.6rem;
      }

      #oAq0aeW9KFVXZ7Ol {
        grid-area: 10 / 4 / 11 / 22;
        position: relative;
      }

      #ZIWGPoApdy9Md8YU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.55110933em - var(--ffsd)));
      }

      #DF38PgX5ER3v0xDS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.55110933em - var(--ffsd)));
      }

      #jS79BHcqfEGhnveX {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.55110933em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #s8r64iDJxPOiPqdH {
        min-width: 91.6rem;
      }

      #yrzJJM1VddXStANX {
        grid-area: 12 / 5 / 13 / 23;
        position: relative;
      }

      #Ow1SV5SYpmuU64gX {
        stroke-width: calc(100rem * 0.0 / 375.0);
      }

      #nYFaUvsXej6k3ZQa {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #jNDmrDwxIvmpGN9F {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.62224em - var(--ffsd)));
      }

      #kVcd73LgvxkUf0bx {
        min-width: 46.31875527rem;
      }

      #PN5xyZDAshLeTFyz {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #g7JO7hLJFbhZ1c9v {
        grid-template-columns: 0 1.06666667rem 46.18542194rem 1.06666667rem;
        grid-template-rows: 0 minmax(1.06666667rem, max-content) minmax(17.32112924rem, max-content) minmax(1.06666667rem, max-content);
      }

      #jgIuBGdbY9hcjJbj {
        grid-area: 14 / 6 / 15 / 14;
        grid-template-columns: 0 48.31875527rem;
        grid-template-rows: 0 minmax(19.45446257rem, max-content);
      }

      #sEi0F6sKr42V43mj {
        grid-area: 14 / 6 / 15 / 14;
        position: relative;
      }

      #xawZlBw7Vmw28g8w {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(6.77793371em - var(--ffsd)));
      }

      #Q0d3leswLFoaxkqp {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 6.77793371em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GMCPj7pxIpKa6v2U {
        min-width: 91.6rem;
      }

      #hEfrwSXCUQX7IVuh {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #Rip6GLXcR8q0Bv3O {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.42235205em - var(--ffsd)));
      }

      #X6cBRlpJnMGJ8lUF {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.42235205em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #G0hWTx60TFTxFnyH {
        min-width: 91.6rem;
      }

      #iFyTMSfwG0AnexMm {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #BsIWI3L6rLZJsXHH {
        grid-area: 16 / 7 / 17 / 24;
        grid-template-columns: 0 0 91.46666667rem 0;
        grid-template-rows: 0 minmax(7.9640988rem, max-content) minmax(4.99244358rem, max-content) minmax(6.47294627rem, max-content);
      }

      #UI1WPzmkLr6SI09n {
        grid-area: 16 / 7 / 17 / 24;
        position: relative;
      }

      #BulTesQwb287ByAX {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(6.77793371em - var(--ffsd)));
      }

      #REVB22uHW9WFoxrd {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 6.77793371em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #RXjFLQF0zPPTOKwG {
        min-width: 91.6rem;
      }

      #mib8cPgYCBfUFFU7 {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #QsOasINka3ohBBZU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.42235205em - var(--ffsd)));
      }

      #D7RzeGAGeAZleErO {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.42235205em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #hnj0691Mo6sEMsz5 {
        min-width: 91.6rem;
      }

      #kk7Z1uC5TO81GwEN {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #uTxlUG5z05FDAAjp {
        grid-area: 18 / 8 / 19 / 25;
        grid-template-columns: 0 0 91.46666667rem 0;
        grid-template-rows: 0 minmax(7.9640988rem, max-content) minmax(4.99244358rem, max-content) minmax(6.47294627rem, max-content);
      }

      #trJdXGuJZuetLsGr {
        grid-area: 18 / 8 / 19 / 25;
        position: relative;
      }

      #LmO7NTL7CdAkUEzX {
        grid-area: 20 / 10 / 24 / 12;
        position: relative;
      }

      #Oe9rFuo4wMmT4FAU {
        grid-area: 21 / 13 / 25 / 15;
        position: relative;
      }

      #rJN6GzljJ2SbfRbK {
        grid-area: 22 / 16 / 23 / 17;
        position: relative;
      }

      #vtG7myf9p3vyMZDR {
        grid-template-columns: 4.26666667rem 0 0 0 0 0 0 14.97910125rem 9.61599577rem 7.14536826rem 3.46764185rem 5.21872115rem 7.89192699rem 2.72108312rem 5.4143289rem 10.41740236rem 0.4665936rem 12.92798693rem 11.20051649rem 0 0 0 0 0 4.26666667rem;
        grid-template-rows: minmax(4.72181035rem, max-content) minmax(5.60565912rem, max-content) minmax(45.64178246rem, max-content) minmax(8.4787598rem, max-content) minmax(46.69330722rem, max-content) minmax(12.16609623rem, max-content) minmax(6.4rem, max-content) minmax(0.2645853rem, max-content) minmax(8.26666667rem, max-content) minmax(8.77291316rem, max-content) minmax(3.90971886rem, max-content) minmax(10.86866707rem, max-content) minmax(8.04305219rem, max-content) minmax(19.45446257rem, max-content) minmax(47.31277105rem, max-content) minmax(19.42948864rem, max-content) minmax(13.78397217rem, max-content) minmax(19.42948864rem, max-content) minmax(6.4rem, max-content) 0 0 minmax(10.41740236rem, max-content) minmax(0.19560775rem, max-content) 0 minmax(4.72181035rem, max-content);
      }

      #U5lczSwYEnRk1Mt4 {
        min-height: calc(calc(17.34687752 * var(--1vh, 1vh)) - 8.67343876px);
      }
    }

    @media (min-width: 375.05px) and (max-width: 480px) {
      #m3SYDT9FKCM13HjP {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #llJYRpJEKd1IcIhk {
        grid-template-columns: 0 421.95244532%;
        left: -160.97622266%;
        grid-template-rows: 0 100%;
      }

      #r1EFlTFVXm2e0A3n {
        grid-area: 2 / 3 / 5 / 6;
        position: relative;
      }

      #TfH5lWrMgLRuuMdS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.1373125em - var(--ffsd)));
      }

      #SXuGeBBgCKw0Kry7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.1373125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #YtRQL1tNQCJRcW5m {
        min-width: 21.6780599rem;
      }

      #MvKcRfpmrfune5AA {
        grid-area: 3 / 7 / 4 / 8;
        position: relative;
      }

      #jQOTOlXn1E4QD7ph {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(14.7221875em - var(--ffsd)));
      }

      #yTLbXVvBvrvkVFKM {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 14.7221875em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #kXL4EaoQAP8c1x5h {
        min-width: 93.34195454rem;
      }

      #UKdOD4U3PWwpTe0d {
        grid-area: 6 / 4 / 7 / 10;
        position: relative;
      }

      #Ta7XH3vixYn13PeA {
        stroke-width: calc(100rem * 0.0 / 480.0);
      }

      #zP5Shnye9HLNIW3b {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #s8b51UQOMuly5AiR {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.611125em - var(--ffsd)));
      }

      #wOCJaesTt6mgvpfr {
        min-width: 45.05639394rem;
      }

      #p0fSmdua70RtuE0X {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #haTF8OYQSfrQtohf {
        grid-template-columns: 0 0.83333333rem 44.95222727rem 0.83333333rem;
        grid-template-rows: 0 minmax(0.83333333rem, max-content) minmax(13.53213222rem, max-content) minmax(0.83333333rem, max-content);
      }

      #GmUp5asCngXTjcfw {
        grid-area: 8 / 5 / 9 / 9;
        grid-template-columns: 0 46.61889394rem;
        grid-template-rows: 0 minmax(15.19879888rem, max-content);
      }

      #tMAOrNb5A0aiK2Uu {
        grid-area: 8 / 5 / 9 / 9;
        position: relative;
      }

      #GEbfawZRSV21NOsR {
        grid-area: 10 / 2 / 11 / 11;
        position: relative;
      }

      #GvWlHEPhc7hdjMiF {
        grid-template-columns: 3.33333333rem 0.04777273rem 0 0 8.95490197rem 2.91733129rem 21.57389323rem 13.17276745rem 46.61889394rem 0.04777273rem 3.33333333rem;
        grid-template-rows: minmax(3.33333333rem, max-content) minmax(1.81764994rem, max-content) minmax(6.15293542rem, max-content) minmax(0.98431661rem, max-content) minmax(47.8886235rem, max-content) minmax(52.5rem, max-content) minmax(7.69009001rem, max-content) minmax(15.19879888rem, max-content) minmax(5rem, max-content) minmax(93.33333333rem, max-content) minmax(3.33333333rem, max-content);
      }

      #EVsnVfWBFziIwED4 {
        min-height: calc(calc(15.94728108 * var(--1vh, 1vh)) - 7.97364054px);
      }

      #Hdri1aIl6ToYC0vq {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #KJgycpXEEH2PHiBZ {
        grid-template-columns: 0 401.60710123%;
        left: -150.80355061%;
        grid-template-rows: 0 100%;
      }

      #APYUUhkfOlsktt4U {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(9.48473043em - var(--ffsd)));
      }

      #MKY7BtHq4RLFEHWV {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 9.48473043em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #EnWZ5NJ4wXZGyG1y {
        min-width: 93.4375rem;
      }

      #YvCdtM9eTGVI7Fjj {
        grid-area: 2 / 2 / 3 / 9;
        position: relative;
      }

      #XU61H5mU1Hegxyg1 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.61322499em - var(--ffsd)));
      }

      #EbMz9lWN05xkfKiu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.61322499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #fTR14lQXntxrP3Id {
        min-width: 93.4375rem;
      }

      #HshH9YO9PWARaZlp {
        grid-area: 4 / 3 / 5 / 10;
        position: relative;
      }

      #miRUNBfS6pd7arzU {
        grid-area: 6 / 6 / 9 / 11;
        position: relative;
      }

      #nDTM1IrvTJqPqaWt {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #qJ34bvUj1ts5ONJ2 {
        grid-area: 7 / 5 / 10 / 8;
        grid-template-columns: 0 56.99262198rem;
        grid-template-rows: 0 minmax(73.55996895rem, max-content);
      }

      #CVKDDezLgdkzgo3I {
        grid-area: 7 / 5 / 10 / 8;
        position: relative;
      }

      #PrcyQ85wjjB0o08u {
        grid-area: 8 / 4 / 11 / 7;
        position: relative;
      }

      #vgwhkg6IqrGkge5w {
        grid-template-columns: 3.33333333rem 0 0 17.84042567rem 11.67946798rem 42.42641666rem 2.88673734rem 18.50028568rem 0 0 3.33333333rem;
        grid-template-rows: minmax(3.33333333rem, max-content) minmax(34.04340744rem, max-content) minmax(33.22221667rem, max-content) minmax(44.62340066rem, max-content) minmax(5rem, max-content) minmax(15.49058273rem, max-content) minmax(14.80115911rem, max-content) minmax(33.52169784rem, max-content) minmax(25.23711199rem, max-content) minmax(13.18750048rem, max-content) minmax(3.33333333rem, max-content);
      }

      #FP4D4N6LhJJOZuGj {
        min-height: calc(calc(15.17834865 * var(--1vh, 1vh)) - 7.58917432px);
      }

      #Etajan3P94FrCZA7 {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #PD7rGfJaSv9ew4C8 {
        grid-template-columns: 0 664.67654135%;
        left: -282.33827067%;
        grid-template-rows: 0 100%;
      }

      #K7Wrp4f1lV4ES9FE {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.45343346em - var(--ffsd)));
      }

      #wZeIsWv8ULwO9jcy {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.45343346em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #p7ihhOMm87c0ACEa {
        min-width: 93.4375rem;
      }

      #fPv2t7YHnuejKHcU {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #Tyc7EOWaz3bsR342 {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #WXwIL7gFzMa67DCC {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #n5X4InqHj6OYLYsu {
        display: block;
      }

      #XldIT6cLv2fBUqKe {
        display: none;
      }

      #p4FFndj20RBGut1m {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #tdVKy05DzOadvHGI {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.54885417em - var(--ffsd)));
      }

      #tTqGqp9n1v6v5uis {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.54885417em - var(--ffsd)));
      }

      #Y5EhKDSdHrHmGzgW {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.54885417em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #iheXlR99lIzXx0Ne {
        min-width: 61.21435857rem;
      }

      #M6hbY4UwnTeNWRUt {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #yChP2nRcxzL1YOTN {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.611125em - var(--ffsd)));
      }

      #LMwFKqTE7AJ7lbir {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.611125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #gHR2fRPhXDM6Hisl {
        min-width: 61.21435857rem;
      }

      #aCErBJkmtBUolALX {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #d11L9LwwZabvIXmW {
        grid-template-columns: 0 5rem 0 61.11019191rem 0 5rem;
        grid-template-rows: 0 minmax(4.70957505rem, max-content) minmax(13.61178125rem, max-content) minmax(1.18412959rem, max-content) minmax(9.73210564rem, max-content) minmax(4.7830194rem, max-content);
      }

      #OUm9F4uUfkGg3Gls {
        grid-template-columns: 0 71.11019191rem;
        grid-template-rows: 0 minmax(34.02061093rem, max-content);
      }

      #QgEfIIzf18D8RQKM {
        grid-template-columns: 0 6.16357573rem 71.11019191rem 4.55175115rem;
        grid-template-rows: 0 minmax(70.18772241rem, max-content) minmax(34.02061093rem, max-content) minmax(5.83333333rem, max-content);
      }

      #R4nH3NYK7paPPHzs {
        grid-area: 6 / 4 / 7 / 7;
        grid-template-columns: 0 81.82551879rem;
        grid-template-rows: 0 minmax(110.04166667rem, max-content);
      }

      #I86TgkNnnIdNV9mF {
        grid-area: 6 / 4 / 7 / 7;
        position: relative;
      }

      #BbzwfbFZPVrTIxUM {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #TpSjo6ksBYK1wmrg {
        display: block;
      }

      #Rb11CAnGbnPpu9vf {
        display: none;
      }

      #e2Ge0I5wUOeyD5zs {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #qyFXjYNNwMtVuZ89 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.54884534em - var(--ffsd)));
      }

      #rbiDzUNgYfDG2acu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.54884534em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #AZjTU9md2ADPAc0F {
        min-width: 61.21435857rem;
      }

      #i0XTZt0u3J9l3l1i {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #U7tJjD7Uh5gDxwn4 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.611125em - var(--ffsd)));
      }

      #Za9xwVDCXA2pliP5 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.611125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #m2XOjdNXKmHeAHwO {
        min-width: 61.21435857rem;
      }

      #kLVpIMZoli7sYzrB {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #m9LXQfrbEmJr2k5p {
        grid-template-columns: 0 5rem 0 61.11019191rem 0 5rem;
        grid-template-rows: 0 minmax(5.08152225rem, max-content) minmax(13.2651232rem, max-content) minmax(1.18412959rem, max-content) minmax(8.42282586rem, max-content) minmax(6.06701003rem, max-content);
      }

      #hj6h0LScTtoij9rW {
        grid-template-columns: 0 71.11019191rem;
        grid-template-rows: 0 minmax(34.02061093rem, max-content);
      }

      #ufRvNwcU96kqYNf4 {
        grid-template-columns: 0 5.35766344rem 71.11019191rem 5.35766344rem;
        grid-template-rows: 0 minmax(70.18772241rem, max-content) minmax(34.02061093rem, max-content) minmax(5.83333333rem, max-content);
      }

      #CENlSefUjhP6YW5b {
        grid-area: 8 / 5 / 9 / 8;
        grid-template-columns: 0 81.82551879rem;
        grid-template-rows: 0 minmax(110.04166667rem, max-content);
      }

      #eG3ccb8SJFeXwIvJ {
        grid-area: 8 / 5 / 9 / 8;
        position: relative;
      }

      #NWUTtg2IQDYEhSaQ {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #Au7GoA1EJkmz0gKh {
        display: block;
      }

      #nNIE5ZjGqDvYRj1d {
        display: none;
      }

      #s5HzwVAW1mrDp3Uf {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #HIij7OCEh7guCFzz {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.54884534em - var(--ffsd)));
      }

      #dH3MoNpEwXMeCUcv {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.54884534em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #cRBRg221gqzDGxvu {
        min-width: 62.72898256rem;
      }

      #FElht4Ltr4nzQ0gg {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #LD9IOLtK8K47oyj9 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.61112807em - var(--ffsd)));
      }

      #GW2f5b3rlSSixum7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.61112807em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ACpGnJk4cZWHjwN4 {
        min-width: 62.72898256rem;
      }

      #YHrHHD87BdlARGfK {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #aKAA6U6yEUFEdwiB {
        grid-template-columns: 0 4.24268801rem 0 62.6248159rem 0 4.24268801rem;
        grid-template-rows: 0 minmax(8.08009132rem, max-content) minmax(6.65649907rem, max-content) minmax(1.18412959rem, max-content) minmax(10.01979962rem, max-content) minmax(8.08009132rem, max-content);
      }

      #z0bY5zYMRsmxpb4L {
        grid-template-columns: 0 71.11019191rem;
        grid-template-rows: 0 minmax(34.02061093rem, max-content);
      }

      #u4z6oRNJ98jyVNor {
        grid-template-columns: 0 6.21201215rem 71.11019191rem 4.50331473rem;
        grid-template-rows: 0 minmax(70.18772241rem, max-content) minmax(34.02061093rem, max-content) minmax(5.83333333rem, max-content);
      }

      #hb5jrqAkCXjZoTXa {
        grid-area: 10 / 6 / 11 / 9;
        grid-template-columns: 0 81.82551879rem;
        grid-template-rows: 0 minmax(110.04166667rem, max-content);
      }

      #xp0ymJ30yKJUmkXi {
        grid-area: 10 / 6 / 11 / 9;
        position: relative;
      }

      #ZMh7ecpl7smJEubs {
        grid-template-columns: 3.33333333rem 0 5.75390727rem 0 0 81.82551879rem 0 0 5.75390727rem 0 3.33333333rem;
        grid-template-rows: minmax(7.16666667rem, max-content) minmax(6.54412015rem, max-content) minmax(6.29166667rem, max-content) minmax(0.15396459rem, max-content) minmax(6.25rem, max-content) minmax(110.04166667rem, max-content) minmax(5rem, max-content) minmax(110.04166667rem, max-content) minmax(5rem, max-content) minmax(110.04166667rem, max-content) minmax(7.16666667rem, max-content);
      }

      #ISVkDXmJFMnWiq1K {
        min-height: calc(calc(25.12080153 * var(--1vh, 1vh)) - 12.56040076px);
      }

      #LtN1C7EnSNQGg89z {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #N4Tpdpnf4HghJVjr {
        grid-template-columns: 0 664.67654135%;
        left: -282.33827067%;
        grid-template-rows: 0 100%;
      }

      #Vc6Z6VzhJe15nxoy {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.45343346em - var(--ffsd)));
      }

      #Hiu5ffhXEx7BdDRZ {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.45343346em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #QXoE2maBBoNIF7Gr {
        min-width: 93.4375rem;
      }

      #SlLTi6O24aPK1PQQ {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #D9nPJ3DqM8BwWaHM {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #lq2ZDpzWZEJvBMiM {
        display: block;
      }

      #LgXgkEOX3zElrFEM {
        display: none;
      }

      #uxnqO6yERfC4d65D {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ubGMOqeL5rvOuMqQ {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #gNE1pDRPU0FmfvzJ {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #wcHvYwrDbIHCRtHO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.4444375em - var(--ffsd)));
      }

      #oNwbURniyG6xEZN2 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.4444375em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #OAAB3fohcFyLYSft {
        min-width: 63.03249333rem;
      }

      #XlYyt0aMHu1Zh0hp {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #l0Q2nbieDbtvDa4I {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.611125em - var(--ffsd)));
      }

      #j2c6GpMXEM9JHQu4 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.611125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GWVsMHfr8l8cFrc7 {
        min-width: 63.03249333rem;
      }

      #vileu7dt6s5TvraX {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #PyIzu2Slr4qCZW4c {
        grid-area: 6 / 4 / 7 / 7;
        grid-template-columns: 0 8.38250746rem 0 0 0 22.19534449rem 5.92794282rem 34.80503935rem 0 10.51468467rem;
        grid-template-rows: 0 minmax(9.31812624rem, max-content) minmax(22.19525571rem, max-content) minmax(6.27293327rem, max-content) minmax(4.29519297rem, max-content) minmax(5rem, max-content) minmax(40.722225rem, max-content) minmax(5.04828132rem, max-content) minmax(4.18055rem, max-content) minmax(13.00910215rem, max-content);
      }

      #hJKy6v7Y1BQEtWBw {
        grid-area: 6 / 4 / 7 / 7;
        position: relative;
      }

      #ModsPUuKGeM9aeoC {
        display: block;
      }

      #eNI74A7dmWLhXMfg {
        display: none;
      }

      #N0NNQ9InTrpLFoFR {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #sOnczf1YqVUavn4q {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #Yf9A5IFd1HPZngBl {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #M4C1SZ1Dl6JYZrrm {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.4444375em - var(--ffsd)));
      }

      #eBBSxU69aAaJ4t6i {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.4444375em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #JEKIMuTIrrslKJoY {
        min-width: 63.03249333rem;
      }

      #Dt47wVyMxkdPTXKu {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #RuZHIV0XOwBNQvFf {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.611125em - var(--ffsd)));
      }

      #XXI3z3eivyRQNAXD {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.611125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #Vew8JRHgXiDhwtsA {
        min-width: 63.03249333rem;
      }

      #ZJOgMyCQ7FBapqor {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #hUZCKysgaRhWfkMd {
        grid-area: 8 / 5 / 9 / 8;
        grid-template-columns: 0 8.38250746rem 0 0 0 22.19534449rem 5.92794282rem 34.80503935rem 0 10.51468467rem;
        grid-template-rows: 0 minmax(9.31812624rem, max-content) minmax(22.19525571rem, max-content) minmax(6.27293327rem, max-content) minmax(4.29519297rem, max-content) minmax(5rem, max-content) minmax(40.722225rem, max-content) minmax(5.04828132rem, max-content) minmax(4.18055rem, max-content) minmax(13.00910215rem, max-content);
      }

      #bqItE7RCLOyv9rrN {
        grid-area: 8 / 5 / 9 / 8;
        position: relative;
      }

      #Wtde72kg8M6YwcMA {
        display: block;
      }

      #Jxv0NPP6UQRhz5Ra {
        display: none;
      }

      #iv1XCKpdSVjuCBKU {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ipvxIQqPGKvdy7s9 {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #isn5BP7r5XUWo3JL {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #zhcztrpvjlWNbTYO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.4444375em - var(--ffsd)));
      }

      #rbYxOfI8KuLu319s {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.4444375em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ODcjk0rSbCDnbjOX {
        min-width: 63.03249333rem;
      }

      #xD3maSGoVQRNCD0N {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #YZ1r4ouyXW9PTI9P {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.611125em - var(--ffsd)));
      }

      #JGJ5JB5Kl8VZt7jR {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.611125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #UZYC6WCZAEKCjxAv {
        min-width: 63.03249333rem;
      }

      #tA4Agi2rzuBW6JML {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #knf3b6c1mVzKA7au {
        grid-area: 10 / 6 / 11 / 9;
        grid-template-columns: 0 8.38250746rem 0 0 0 22.19534449rem 5.92794282rem 34.80503935rem 0 10.51468467rem;
        grid-template-rows: 0 minmax(9.31812624rem, max-content) minmax(22.19525571rem, max-content) minmax(6.27293327rem, max-content) minmax(4.29519297rem, max-content) minmax(5rem, max-content) minmax(40.722225rem, max-content) minmax(5.04828132rem, max-content) minmax(4.18055rem, max-content) minmax(13.00910215rem, max-content);
      }

      #qlIn6bf0FR92TyfT {
        grid-area: 10 / 6 / 11 / 9;
        position: relative;
      }

      #Zmq1BcGFaKOW7N0J {
        grid-template-columns: 3.33333333rem 0 5.75390727rem 0 0 81.82551879rem 0 0 5.75390727rem 0 3.33333333rem;
        grid-template-rows: minmax(7.16666667rem, max-content) minmax(6.54412015rem, max-content) minmax(6.29166667rem, max-content) minmax(0.15396459rem, max-content) minmax(6.25rem, max-content) minmax(110.04166667rem, max-content) minmax(5rem, max-content) minmax(110.04166667rem, max-content) minmax(5rem, max-content) minmax(110.04166667rem, max-content) minmax(7.16666667rem, max-content);
      }

      #X3JPx632LSRuAY4d {
        min-height: calc(calc(25.12080153 * var(--1vh, 1vh)) - 12.56040076px);
      }

      #uV27B7XrVHeA5mka {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #bKSg5iz4CZD3MEXc {
        grid-template-columns: 0 493.00828475%;
        left: -196.50414238%;
        grid-template-rows: 0 100%;
      }

      #pDpxDsQDp1eh8Yid {
        grid-area: 2 / 11 / 5 / 22;
        position: relative;
      }

      #OyIXdjM3gEFMIKYH {
        grid-area: 3 / 9 / 6 / 19;
        position: relative;
      }

      #VWb2tvwkmBFDR6r8 {
        grid-area: 4 / 2 / 7 / 18;
        position: relative;
      }

      #a8b72Yi8nQo6EntT {
        grid-area: 8 / 3 / 9 / 23;
        position: relative;
      }

      #Qjm9rz6trR5oVzQt {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(7.45996017em - var(--ffsd)));
      }

      #FLP3ypFsLN95AyTg {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 7.45996017em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #sidsPanTaL76AHlA {
        min-width: 93.4375rem;
      }

      #oAq0aeW9KFVXZ7Ol {
        grid-area: 10 / 4 / 11 / 24;
        position: relative;
      }

      #ZIWGPoApdy9Md8YU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.97863921em - var(--ffsd)));
      }

      #DF38PgX5ER3v0xDS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.97863921em - var(--ffsd)));
      }

      #jS79BHcqfEGhnveX {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.97863921em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #s8r64iDJxPOiPqdH {
        min-width: 93.4375rem;
      }

      #yrzJJM1VddXStANX {
        grid-area: 12 / 5 / 13 / 25;
        position: relative;
      }

      #Ow1SV5SYpmuU64gX {
        stroke-width: calc(100rem * 0.0 / 480.0);
      }

      #nYFaUvsXej6k3ZQa {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #jNDmrDwxIvmpGN9F {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.611125em - var(--ffsd)));
      }

      #kVcd73LgvxkUf0bx {
        min-width: 36.18652755rem;
      }

      #PN5xyZDAshLeTFyz {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #g7JO7hLJFbhZ1c9v {
        grid-template-columns: 0 0.83333333rem 36.08236089rem 0.83333333rem;
        grid-template-rows: 0 minmax(0.83333333rem, max-content) minmax(13.53213222rem, max-content) minmax(0.83333333rem, max-content);
      }

      #jgIuBGdbY9hcjJbj {
        grid-area: 14 / 6 / 15 / 12;
        grid-template-columns: 0 37.74902755rem;
        grid-template-rows: 0 minmax(15.19879888rem, max-content);
      }

      #sEi0F6sKr42V43mj {
        grid-area: 14 / 6 / 15 / 12;
        position: relative;
      }

      #xawZlBw7Vmw28g8w {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.55554167em - var(--ffsd)));
      }

      #Q0d3leswLFoaxkqp {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.55554167em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GMCPj7pxIpKa6v2U {
        min-width: 75.074932rem;
      }

      #hEfrwSXCUQX7IVuh {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #Rip6GLXcR8q0Bv3O {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.4444375em - var(--ffsd)));
      }

      #X6cBRlpJnMGJ8lUF {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.4444375em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #G0hWTx60TFTxFnyH {
        min-width: 75.074932rem;
      }

      #iFyTMSfwG0AnexMm {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #BsIWI3L6rLZJsXHH {
        grid-area: 16 / 7 / 17 / 20;
        grid-template-columns: 0 0 74.97076533rem 0;
        grid-template-rows: 0 minmax(6.52778333rem, max-content) minmax(3.90034654rem, max-content) minmax(5.30555833rem, max-content);
      }

      #UI1WPzmkLr6SI09n {
        grid-area: 16 / 7 / 17 / 20;
        position: relative;
      }

      #BulTesQwb287ByAX {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.55554167em - var(--ffsd)));
      }

      #REVB22uHW9WFoxrd {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.55554167em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #RXjFLQF0zPPTOKwG {
        min-width: 75.074932rem;
      }

      #mib8cPgYCBfUFFU7 {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #QsOasINka3ohBBZU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.4444375em - var(--ffsd)));
      }

      #D7RzeGAGeAZleErO {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.4444375em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #hnj0691Mo6sEMsz5 {
        min-width: 75.074932rem;
      }

      #kk7Z1uC5TO81GwEN {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #uTxlUG5z05FDAAjp {
        grid-area: 18 / 8 / 19 / 21;
        grid-template-columns: 0 0 74.97076533rem 0;
        grid-template-rows: 0 minmax(6.52778333rem, max-content) minmax(3.90034654rem, max-content) minmax(5.30555833rem, max-content);
      }

      #trJdXGuJZuetLsGr {
        grid-area: 18 / 8 / 19 / 21;
        position: relative;
      }

      #LmO7NTL7CdAkUEzX {
        grid-area: 20 / 10 / 24 / 13;
        position: relative;
      }

      #Oe9rFuo4wMmT4FAU {
        grid-area: 21 / 14 / 25 / 15;
        position: relative;
      }

      #rJN6GzljJ2SbfRbK {
        grid-area: 22 / 16 / 23 / 17;
        position: relative;
      }

      #vtG7myf9p3vyMZDR {
        grid-template-columns: 3.33333333rem 0 0 0 0 8.8885116rem 0.5855448rem 5.81074079rem 14.86762235rem 2.23581033rem 5.36079768rem 0.69480614rem 4.0771259rem 8.29141415rem 4.22994445rem 8.13859559rem 5.53149769rem 13.1918234rem 1.95504206rem 0.5855448rem 8.8885116rem 0 0 0 3.33333333rem;
        grid-template-rows: minmax(3.68891433rem, max-content) minmax(5.72006032rem, max-content) minmax(46.57324741rem, max-content) minmax(8.65179572rem, max-content) minmax(47.64623185rem, max-content) minmax(12.41438391rem, max-content) minmax(5rem, max-content) minmax(0.269985rem, max-content) minmax(6.45833333rem, max-content) minmax(8.9519522rem, max-content) minmax(3.05446786rem, max-content) minmax(11.0904766rem, max-content) minmax(6.28363453rem, max-content) minmax(15.19879888rem, max-content) minmax(36.96310239rem, max-content) minmax(15.73368821rem, max-content) minmax(10.76872826rem, max-content) minmax(15.73368821rem, max-content) minmax(5rem, max-content) 0 0 minmax(8.13859559rem, max-content) minmax(0.15281855rem, max-content) 0 minmax(3.68891433rem, max-content);
      }

      #U5lczSwYEnRk1Mt4 {
        min-height: calc(calc(18.63276722 * var(--1vh, 1vh)) - 9.31638361px);
      }
    }

    @media (min-width: 480.05px) and (max-width: 768px) {
      #m3SYDT9FKCM13HjP {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #llJYRpJEKd1IcIhk {
        grid-template-columns: 0 326.05743269%;
        left: -113.02871634%;
        grid-template-rows: 0 100%;
      }

      #r1EFlTFVXm2e0A3n {
        grid-area: 2 / 3 / 5 / 6;
        position: relative;
      }

      #TfH5lWrMgLRuuMdS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.21082031em - var(--ffsd)));
      }

      #SXuGeBBgCKw0Kry7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.21082031em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #YtRQL1tNQCJRcW5m {
        min-width: 13.54878743rem;
      }

      #MvKcRfpmrfune5AA {
        grid-area: 3 / 7 / 4 / 8;
        position: relative;
      }

      #jQOTOlXn1E4QD7ph {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(9.20136719em - var(--ffsd)));
      }

      #yTLbXVvBvrvkVFKM {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 9.20136719em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #kXL4EaoQAP8c1x5h {
        min-width: 58.33872159rem;
      }

      #UKdOD4U3PWwpTe0d {
        grid-area: 6 / 4 / 7 / 10;
        position: relative;
      }

      #Ta7XH3vixYn13PeA {
        stroke-width: calc(100rem * 0.0 / 768.0);
      }

      #zP5Shnye9HLNIW3b {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #s8b51UQOMuly5AiR {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695312em - var(--ffsd)));
      }

      #wOCJaesTt6mgvpfr {
        min-width: 28.16024621rem;
      }

      #p0fSmdua70RtuE0X {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #haTF8OYQSfrQtohf {
        grid-template-columns: 0 0.52083333rem 28.09514204rem 0.52083333rem;
        grid-template-rows: 0 minmax(0.52083333rem, max-content) minmax(8.45758264rem, max-content) minmax(0.52083333rem, max-content);
      }

      #GmUp5asCngXTjcfw {
        grid-area: 8 / 5 / 9 / 9;
        grid-template-columns: 0 29.13680871rem;
        grid-template-rows: 0 minmax(9.4992493rem, max-content);
      }

      #tMAOrNb5A0aiK2Uu {
        grid-area: 8 / 5 / 9 / 9;
        position: relative;
      }

      #GEbfawZRSV21NOsR {
        grid-area: 10 / 2 / 11 / 11;
        position: relative;
      }

      #GvWlHEPhc7hdjMiF {
        grid-template-columns: 5.91373186rem 14.94945943rem 0 0 5.59681373rem 1.82333206rem 13.48368327rem 8.23297966rem 29.13680871rem 14.94945943rem 5.91373186rem;
        grid-template-rows: minmax(4.16666667rem, max-content) minmax(1.13603121rem, max-content) minmax(3.84558464rem, max-content) minmax(0.61519788rem, max-content) minmax(29.93038968rem, max-content) minmax(32.8125rem, max-content) minmax(4.80630625rem, max-content) minmax(9.4992493rem, max-content) minmax(4.16666667rem, max-content) minmax(88.17253627rem, max-content) minmax(4.16666667rem, max-content);
      }

      #EVsnVfWBFziIwED4 {
        min-height: calc(calc(18.08014533 * var(--1vh, 1vh)) - 9.04007266px);
      }

      #Hdri1aIl6ToYC0vq {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #KJgycpXEEH2PHiBZ {
        grid-template-columns: 0 283.25969447%;
        left: -91.62984723%;
        grid-template-rows: 0 100%;
      }

      #APYUUhkfOlsktt4U {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(7.29166667em - var(--ffsd)));
      }

      #MKY7BtHq4RLFEHWV {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 7.29166667em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #EnWZ5NJ4wXZGyG1y {
        min-width: 91.73177083rem;
      }

      #YvCdtM9eTGVI7Fjj {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #XU61H5mU1Hegxyg1 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #EbMz9lWN05xkfKiu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.77777344em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #fTR14lQXntxrP3Id {
        min-width: 91.73177083rem;
      }

      #HshH9YO9PWARaZlp {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #miRUNBfS6pd7arzU {
        grid-area: 6 / 6 / 9 / 9;
        position: relative;
      }

      #nDTM1IrvTJqPqaWt {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #qJ34bvUj1ts5ONJ2 {
        grid-area: 7 / 5 / 10 / 8;
        grid-template-columns: 0 43.84500559rem;
        grid-template-rows: 0 minmax(56.59043465rem, max-content);
      }

      #CVKDDezLgdkzgo3I {
        grid-area: 7 / 5 / 10 / 8;
        position: relative;
      }

      #PrcyQ85wjjB0o08u {
        grid-area: 8 / 4 / 11 / 7;
        position: relative;
      }

      #vgwhkg6IqrGkge5w {
        grid-template-columns: 4.16666667rem 0 9.93219052rem 13.72482149rem 8.98513389rem 32.63907522rem 2.22079649rem 14.23245854rem 9.93219052rem 0 4.16666667rem;
        grid-template-rows: minmax(4.16666667rem, max-content) minmax(20.48622743rem, max-content) minmax(20.76388542rem, max-content) minmax(26.852927rem, max-content) minmax(4.16666667rem, max-content) minmax(11.91706334rem, max-content) minmax(11.38668272rem, max-content) minmax(25.78858418rem, max-content) minmax(19.41516775rem, max-content) minmax(10.14527867rem, max-content) minmax(4.16666667rem, max-content);
      }

      #FP4D4N6LhJJOZuGj {
        min-height: calc(calc(15.70697652 * var(--1vh, 1vh)) - 7.85348826px);
      }

      #Etajan3P94FrCZA7 {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #PD7rGfJaSv9ew4C8 {
        grid-template-columns: 0 426.77340711%;
        left: -163.38670355%;
        grid-template-rows: 0 100%;
      }

      #K7Wrp4f1lV4ES9FE {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.20833333em - var(--ffsd)));
      }

      #wZeIsWv8ULwO9jcy {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.20833333em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #p7ihhOMm87c0ACEa {
        min-width: 91.73177083rem;
      }

      #fPv2t7YHnuejKHcU {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #Tyc7EOWaz3bsR342 {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #WXwIL7gFzMa67DCC {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #n5X4InqHj6OYLYsu {
        display: block;
      }

      #XldIT6cLv2fBUqKe {
        display: none;
      }

      #p4FFndj20RBGut1m {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #tdVKy05DzOadvHGI {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.46803385em - var(--ffsd)));
      }

      #tTqGqp9n1v6v5uis {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.46803385em - var(--ffsd)));
      }

      #Y5EhKDSdHrHmGzgW {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.46803385em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #iheXlR99lIzXx0Ne {
        min-width: 37.97289896rem;
      }

      #M6hbY4UwnTeNWRUt {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #yChP2nRcxzL1YOTN {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695312em - var(--ffsd)));
      }

      #LMwFKqTE7AJ7lbir {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.25695312em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #gHR2fRPhXDM6Hisl {
        min-width: 37.97289896rem;
      }

      #aCErBJkmtBUolALX {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #d11L9LwwZabvIXmW {
        grid-template-columns: 0 3.26803758rem 0 37.90779479rem 0 3.26803758rem;
        grid-template-rows: 0 minmax(2.9434844rem, max-content) minmax(8.50736328rem, max-content) minmax(0.74008099rem, max-content) minmax(6.12846875rem, max-content) minmax(2.9434844rem, max-content);
      }

      #OUm9F4uUfkGg3Gls {
        grid-template-columns: 0 44.44386994rem;
        grid-template-rows: 0 minmax(21.26288183rem, max-content);
      }

      #QgEfIIzf18D8RQKM {
        grid-template-columns: 0 3.85223483rem 44.44386994rem 2.84484447rem;
        grid-template-rows: 0 minmax(43.8673265rem, max-content) minmax(21.26288183rem, max-content) minmax(3.64583333rem, max-content);
      }

      #R4nH3NYK7paPPHzs {
        grid-area: 6 / 4 / 7 / 7;
        grid-template-columns: 0 51.14094924rem;
        grid-template-rows: 0 minmax(68.77604167rem, max-content);
      }

      #I86TgkNnnIdNV9mF {
        grid-area: 6 / 4 / 7 / 7;
        position: relative;
      }

      #BbzwfbFZPVrTIxUM {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #TpSjo6ksBYK1wmrg {
        display: block;
      }

      #Rb11CAnGbnPpu9vf {
        display: none;
      }

      #e2Ge0I5wUOeyD5zs {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #qyFXjYNNwMtVuZ89 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.46802834em - var(--ffsd)));
      }

      #rbiDzUNgYfDG2acu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.46802834em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #AZjTU9md2ADPAc0F {
        min-width: 36.59889972rem;
      }

      #i0XTZt0u3J9l3l1i {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #U7tJjD7Uh5gDxwn4 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695312em - var(--ffsd)));
      }

      #Za9xwVDCXA2pliP5 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.25695312em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #m2XOjdNXKmHeAHwO {
        min-width: 36.59889972rem;
      }

      #kLVpIMZoli7sYzrB {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #m9LXQfrbEmJr2k5p {
        grid-template-columns: 0 3.9550372rem 0 36.53379555rem 0 3.9550372rem;
        grid-template-rows: 0 minmax(3.17595141rem, max-content) minmax(8.66742667rem, max-content) minmax(0.74008099rem, max-content) minmax(5.50347135rem, max-content) minmax(3.17595141rem, max-content);
      }

      #hj6h0LScTtoij9rW {
        grid-template-columns: 0 44.44386994rem;
        grid-template-rows: 0 minmax(21.26288183rem, max-content);
      }

      #ufRvNwcU96kqYNf4 {
        grid-template-columns: 0 3.34853965rem 44.44386994rem 3.34853965rem;
        grid-template-rows: 0 minmax(43.8673265rem, max-content) minmax(21.26288183rem, max-content) minmax(3.64583333rem, max-content);
      }

      #CENlSefUjhP6YW5b {
        grid-area: 8 / 5 / 9 / 8;
        grid-template-columns: 0 51.14094924rem;
        grid-template-rows: 0 minmax(68.77604167rem, max-content);
      }

      #eG3ccb8SJFeXwIvJ {
        grid-area: 8 / 5 / 9 / 8;
        position: relative;
      }

      #NWUTtg2IQDYEhSaQ {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #Au7GoA1EJkmz0gKh {
        display: block;
      }

      #nNIE5ZjGqDvYRj1d {
        display: none;
      }

      #s5HzwVAW1mrDp3Uf {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #HIij7OCEh7guCFzz {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.46802834em - var(--ffsd)));
      }

      #dH3MoNpEwXMeCUcv {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.46802834em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #cRBRg221gqzDGxvu {
        min-width: 39.2056141rem;
      }

      #FElht4Ltr4nzQ0gg {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #LD9IOLtK8K47oyj9 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695505em - var(--ffsd)));
      }

      #GW2f5b3rlSSixum7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.25695505em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ACpGnJk4cZWHjwN4 {
        min-width: 39.2056141rem;
      }

      #YHrHHD87BdlARGfK {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #aKAA6U6yEUFEdwiB {
        grid-template-columns: 0 2.65168rem 0 39.14050993rem 0 2.65168rem;
        grid-template-rows: 0 minmax(5.05005708rem, max-content) minmax(4.16031192rem, max-content) minmax(0.74008099rem, max-content) minmax(6.26237477rem, max-content) minmax(5.05005708rem, max-content);
      }

      #z0bY5zYMRsmxpb4L {
        grid-template-columns: 0 44.44386994rem;
        grid-template-rows: 0 minmax(21.26288183rem, max-content);
      }

      #u4z6oRNJ98jyVNor {
        grid-template-columns: 0 3.88250759rem 44.44386994rem 2.81457171rem;
        grid-template-rows: 0 minmax(43.8673265rem, max-content) minmax(21.26288183rem, max-content) minmax(3.64583333rem, max-content);
      }

      #hb5jrqAkCXjZoTXa {
        grid-area: 10 / 6 / 11 / 9;
        grid-template-columns: 0 51.14094924rem;
        grid-template-rows: 0 minmax(68.77604167rem, max-content);
      }

      #xp0ymJ30yKJUmkXi {
        grid-area: 10 / 6 / 11 / 9;
        position: relative;
      }

      #ZMh7ecpl7smJEubs {
        grid-template-columns: 4.16666667rem 0 20.26285871rem 0 0 51.14094924rem 0 0 20.26285871rem 0 4.16666667rem;
        grid-template-rows: minmax(5.52083333rem, max-content) minmax(6.25rem, max-content) minmax(3.93229167rem, max-content) minmax(0.15121522rem, max-content) minmax(3.90625rem, max-content) minmax(68.77604167rem, max-content) minmax(4.16666667rem, max-content) minmax(68.77604167rem, max-content) minmax(4.16666667rem, max-content) minmax(68.77604167rem, max-content) minmax(5.52083333rem, max-content);
      }

      #ISVkDXmJFMnWiq1K {
        min-height: calc(calc(23.66492663 * var(--1vh, 1vh)) - 11.83246331px);
      }

      #LtN1C7EnSNQGg89z {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #N4Tpdpnf4HghJVjr {
        grid-template-columns: 0 426.77340711%;
        left: -163.38670355%;
        grid-template-rows: 0 100%;
      }

      #Vc6Z6VzhJe15nxoy {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.20833333em - var(--ffsd)));
      }

      #Hiu5ffhXEx7BdDRZ {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.20833333em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #QXoE2maBBoNIF7Gr {
        min-width: 91.73177083rem;
      }

      #SlLTi6O24aPK1PQQ {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #D9nPJ3DqM8BwWaHM {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #lq2ZDpzWZEJvBMiM {
        display: block;
      }

      #LgXgkEOX3zElrFEM {
        display: none;
      }

      #uxnqO6yERfC4d65D {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ubGMOqeL5rvOuMqQ {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #gNE1pDRPU0FmfvzJ {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #wcHvYwrDbIHCRtHO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #oNwbURniyG6xEZN2 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.77777344em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #OAAB3fohcFyLYSft {
        min-width: 39.39530833rem;
      }

      #XlYyt0aMHu1Zh0hp {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #l0Q2nbieDbtvDa4I {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695312em - var(--ffsd)));
      }

      #j2c6GpMXEM9JHQu4 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.25695312em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GWVsMHfr8l8cFrc7 {
        min-width: 39.39530833rem;
      }

      #vileu7dt6s5TvraX {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #PyIzu2Slr4qCZW4c {
        grid-area: 6 / 4 / 7 / 7;
        grid-template-columns: 0 5.23906716rem 0 0 0 13.8720903rem 3.70496427rem 21.75314959rem 0 6.57167792rem;
        grid-template-rows: 0 minmax(5.8238289rem, max-content) minmax(13.87203482rem, max-content) minmax(3.92058329rem, max-content) minmax(2.68449561rem, max-content) minmax(3.125rem, max-content) minmax(25.45139062rem, max-content) minmax(3.15517583rem, max-content) minmax(2.61284375rem, max-content) minmax(8.13068885rem, max-content);
      }

      #hJKy6v7Y1BQEtWBw {
        grid-area: 6 / 4 / 7 / 7;
        position: relative;
      }

      #ModsPUuKGeM9aeoC {
        display: block;
      }

      #eNI74A7dmWLhXMfg {
        display: none;
      }

      #N0NNQ9InTrpLFoFR {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #sOnczf1YqVUavn4q {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #Yf9A5IFd1HPZngBl {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #M4C1SZ1Dl6JYZrrm {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #eBBSxU69aAaJ4t6i {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.77777344em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #JEKIMuTIrrslKJoY {
        min-width: 39.39530833rem;
      }

      #Dt47wVyMxkdPTXKu {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #RuZHIV0XOwBNQvFf {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695312em - var(--ffsd)));
      }

      #XXI3z3eivyRQNAXD {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.25695312em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #Vew8JRHgXiDhwtsA {
        min-width: 39.39530833rem;
      }

      #ZJOgMyCQ7FBapqor {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #hUZCKysgaRhWfkMd {
        grid-area: 8 / 5 / 9 / 8;
        grid-template-columns: 0 5.23906716rem 0 0 0 13.8720903rem 3.70496427rem 21.75314959rem 0 6.57167792rem;
        grid-template-rows: 0 minmax(5.8238289rem, max-content) minmax(13.87203482rem, max-content) minmax(3.92058329rem, max-content) minmax(2.68449561rem, max-content) minmax(3.125rem, max-content) minmax(25.45139062rem, max-content) minmax(3.15517583rem, max-content) minmax(2.61284375rem, max-content) minmax(8.13068885rem, max-content);
      }

      #bqItE7RCLOyv9rrN {
        grid-area: 8 / 5 / 9 / 8;
        position: relative;
      }

      #Wtde72kg8M6YwcMA {
        display: block;
      }

      #Jxv0NPP6UQRhz5Ra {
        display: none;
      }

      #iv1XCKpdSVjuCBKU {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ipvxIQqPGKvdy7s9 {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #isn5BP7r5XUWo3JL {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #zhcztrpvjlWNbTYO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #rbYxOfI8KuLu319s {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.77777344em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ODcjk0rSbCDnbjOX {
        min-width: 39.39530833rem;
      }

      #xD3maSGoVQRNCD0N {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #YZ1r4ouyXW9PTI9P {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695312em - var(--ffsd)));
      }

      #JGJ5JB5Kl8VZt7jR {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.25695312em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #UZYC6WCZAEKCjxAv {
        min-width: 39.39530833rem;
      }

      #tA4Agi2rzuBW6JML {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #knf3b6c1mVzKA7au {
        grid-area: 10 / 6 / 11 / 9;
        grid-template-columns: 0 5.23906716rem 0 0 0 13.8720903rem 3.70496427rem 21.75314959rem 0 6.57167792rem;
        grid-template-rows: 0 minmax(5.8238289rem, max-content) minmax(13.87203482rem, max-content) minmax(3.92058329rem, max-content) minmax(2.68449561rem, max-content) minmax(3.125rem, max-content) minmax(25.45139063rem, max-content) minmax(3.15517583rem, max-content) minmax(2.61284375rem, max-content) minmax(8.13068885rem, max-content);
      }

      #qlIn6bf0FR92TyfT {
        grid-area: 10 / 6 / 11 / 9;
        position: relative;
      }

      #Zmq1BcGFaKOW7N0J {
        grid-template-columns: 4.16666667rem 0 20.26285871rem 0 0 51.14094924rem 0 0 20.26285871rem 0 4.16666667rem;
        grid-template-rows: minmax(5.52083333rem, max-content) minmax(6.25rem, max-content) minmax(3.93229167rem, max-content) minmax(0.15121522rem, max-content) minmax(3.90625rem, max-content) minmax(68.77604167rem, max-content) minmax(4.16666667rem, max-content) minmax(68.77604167rem, max-content) minmax(4.16666667rem, max-content) minmax(68.77604167rem, max-content) minmax(5.52083333rem, max-content);
      }

      #X3JPx632LSRuAY4d {
        min-height: calc(calc(23.66492663 * var(--1vh, 1vh)) - 11.83246331px);
      }

      #uV27B7XrVHeA5mka {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #bKSg5iz4CZD3MEXc {
        grid-template-columns: 0 340.53656684%;
        left: -120.26828342%;
        grid-template-rows: 0 100%;
      }

      #pDpxDsQDp1eh8Yid {
        grid-area: 2 / 11 / 5 / 20;
        position: relative;
      }

      #OyIXdjM3gEFMIKYH {
        grid-area: 3 / 9 / 6 / 16;
        position: relative;
      }

      #VWb2tvwkmBFDR6r8 {
        grid-area: 4 / 8 / 7 / 14;
        position: relative;
      }

      #a8b72Yi8nQo6EntT {
        grid-area: 8 / 6 / 9 / 22;
        position: relative;
      }

      #Qjm9rz6trR5oVzQt {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.20833333em - var(--ffsd)));
      }

      #FLP3ypFsLN95AyTg {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.20833333em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #sidsPanTaL76AHlA {
        min-width: 90.45664856rem;
      }

      #oAq0aeW9KFVXZ7Ol {
        grid-area: 10 / 2 / 11 / 23;
        position: relative;
      }

      #ZIWGPoApdy9Md8YU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #DF38PgX5ER3v0xDS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #jS79BHcqfEGhnveX {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.77777344em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #s8r64iDJxPOiPqdH {
        min-width: 90.45664856rem;
      }

      #yrzJJM1VddXStANX {
        grid-area: 12 / 3 / 13 / 24;
        position: relative;
      }

      #Ow1SV5SYpmuU64gX {
        stroke-width: calc(100rem * 0.0 / 768.0);
      }

      #nYFaUvsXej6k3ZQa {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #jNDmrDwxIvmpGN9F {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.25695312em - var(--ffsd)));
      }

      #kVcd73LgvxkUf0bx {
        min-width: 22.61657972rem;
      }

      #PN5xyZDAshLeTFyz {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #g7JO7hLJFbhZ1c9v {
        grid-template-columns: 0 0.52083333rem 22.55147556rem 0.52083333rem;
        grid-template-rows: 0 minmax(0.52083333rem, max-content) minmax(8.45758264rem, max-content) minmax(0.52083333rem, max-content);
      }

      #jgIuBGdbY9hcjJbj {
        grid-area: 14 / 4 / 15 / 10;
        grid-template-columns: 0 23.59314222rem;
        grid-template-rows: 0 minmax(9.4992493rem, max-content);
      }

      #sEi0F6sKr42V43mj {
        grid-area: 14 / 4 / 15 / 10;
        position: relative;
      }

      #xawZlBw7Vmw28g8w {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.47221354em - var(--ffsd)));
      }

      #Q0d3leswLFoaxkqp {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.47221354em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GMCPj7pxIpKa6v2U {
        min-width: 46.9218325rem;
      }

      #hEfrwSXCUQX7IVuh {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #Rip6GLXcR8q0Bv3O {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #X6cBRlpJnMGJ8lUF {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.77777344em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #G0hWTx60TFTxFnyH {
        min-width: 46.9218325rem;
      }

      #iFyTMSfwG0AnexMm {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #BsIWI3L6rLZJsXHH {
        grid-area: 16 / 5 / 17 / 12;
        grid-template-columns: 0 0 46.85672833rem 0;
        grid-template-rows: 0 minmax(4.07986458rem, max-content) minmax(2.43771659rem, max-content) minmax(3.31597396rem, max-content);
      }

      #UI1WPzmkLr6SI09n {
        grid-area: 16 / 5 / 17 / 12;
        position: relative;
      }

      #BulTesQwb287ByAX {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.47221354em - var(--ffsd)));
      }

      #REVB22uHW9WFoxrd {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.47221354em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #RXjFLQF0zPPTOKwG {
        min-width: 46.9218325rem;
      }

      #mib8cPgYCBfUFFU7 {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #QsOasINka3ohBBZU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.77777344em - var(--ffsd)));
      }

      #D7RzeGAGeAZleErO {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.77777344em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #hnj0691Mo6sEMsz5 {
        min-width: 46.9218325rem;
      }

      #kk7Z1uC5TO81GwEN {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #uTxlUG5z05FDAAjp {
        grid-area: 18 / 7 / 23 / 13;
        grid-template-columns: 0 0 46.85672833rem 0;
        grid-template-rows: 0 minmax(4.07986458rem, max-content) minmax(2.43771659rem, max-content) minmax(3.31597396rem, max-content);
      }

      #trJdXGuJZuetLsGr {
        grid-area: 18 / 7 / 23 / 13;
        position: relative;
      }

      #LmO7NTL7CdAkUEzX {
        grid-area: 19 / 15 / 24 / 17;
        position: relative;
      }

      #Oe9rFuo4wMmT4FAU {
        grid-area: 20 / 18 / 25 / 19;
        position: relative;
      }

      #rJN6GzljJ2SbfRbK {
        grid-area: 21 / 21 / 22 / 25;
        position: relative;
      }

      #vtG7myf9p3vyMZDR {
        grid-template-columns: 4.8042278rem 0 0 0 0.3659655rem 0 7.23900315rem 12.31216733rem 3.67600625rem 10.10110328rem 13.16248282rem 0.3659655rem 15.73130542rem 6.79473625rem 3.83150464rem 1.3506292rem 2.54820369rem 5.18213384rem 0.12536888rem 2.5183464rem 5.08662224rem 0 0 0 4.8042278rem;
        grid-template-rows: minmax(3.34723812rem, max-content) minmax(4.60760708rem, max-content) minmax(37.51555273rem, max-content) minmax(6.96917043rem, max-content) minmax(38.37986017rem, max-content) minmax(10rem, max-content) minmax(4.16666667rem, max-content) minmax(0.26041667rem, max-content) minmax(4.03645833rem, max-content) minmax(6.25rem, max-content) minmax(1.90904241rem, max-content) minmax(7.74305729rem, max-content) minmax(3.92727158rem, max-content) minmax(9.4992493rem, max-content) minmax(23.10193899rem, max-content) minmax(9.83355513rem, max-content) minmax(6.73045516rem, max-content) minmax(4.65142129rem, max-content) 0 0 minmax(5.08662224rem, max-content) minmax(0.0955116rem, max-content) 0 0 minmax(3.34723812rem, max-content);
      }

      #U5lczSwYEnRk1Mt4 {
        min-height: calc(calc(18.88302489 * var(--1vh, 1vh)) - 9.44151245px);
      }
    }

    @media (min-width: 768.05px) and (max-width: 1024px) {
      #m3SYDT9FKCM13HjP {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #llJYRpJEKd1IcIhk {
        grid-template-columns: 0 244.54307452%;
        left: -72.27153726%;
        grid-template-rows: 0 100%;
      }

      #r1EFlTFVXm2e0A3n {
        grid-area: 2 / 3 / 5 / 6;
        position: relative;
      }

      #TfH5lWrMgLRuuMdS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.40811523em - var(--ffsd)));
      }

      #SXuGeBBgCKw0Kry7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.40811523em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #YtRQL1tNQCJRcW5m {
        min-width: 10.16159058rem;
      }

      #MvKcRfpmrfune5AA {
        grid-area: 3 / 7 / 4 / 8;
        position: relative;
      }

      #jQOTOlXn1E4QD7ph {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(6.90102539em - var(--ffsd)));
      }

      #yTLbXVvBvrvkVFKM {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 6.90102539em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #kXL4EaoQAP8c1x5h {
        min-width: 43.75404119rem;
      }

      #UKdOD4U3PWwpTe0d {
        grid-area: 6 / 4 / 7 / 10;
        position: relative;
      }

      #Ta7XH3vixYn13PeA {
        stroke-width: calc(100rem * 0.0 / 1024.0);
      }

      #zP5Shnye9HLNIW3b {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #s8b51UQOMuly5AiR {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271484em - var(--ffsd)));
      }

      #wOCJaesTt6mgvpfr {
        min-width: 21.12018466rem;
      }

      #p0fSmdua70RtuE0X {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #haTF8OYQSfrQtohf {
        grid-template-columns: 0 0.390625rem 21.07135653rem 0.390625rem;
        grid-template-rows: 0 minmax(0.390625rem, max-content) minmax(6.34318698rem, max-content) minmax(0.390625rem, max-content);
      }

      #GmUp5asCngXTjcfw {
        grid-area: 8 / 5 / 9 / 9;
        grid-template-columns: 0 21.85260653rem;
        grid-template-rows: 0 minmax(7.12443698rem, max-content);
      }

      #tMAOrNb5A0aiK2Uu {
        grid-area: 8 / 5 / 9 / 9;
        position: relative;
      }

      #GEbfawZRSV21NOsR {
        grid-area: 10 / 2 / 11 / 11;
        position: relative;
      }

      #GvWlHEPhc7hdjMiF {
        grid-template-columns: 16.9352989rem 11.21209457rem 0 0 4.1976103rem 1.36749904rem 10.11276245rem 6.17473474rem 21.85260653rem 11.21209457rem 16.9352989rem;
        grid-template-rows: minmax(3.125rem, max-content) minmax(0.85202341rem, max-content) minmax(2.88418848rem, max-content) minmax(0.46139841rem, max-content) minmax(22.44779226rem, max-content) minmax(24.609375rem, max-content) minmax(3.60472969rem, max-content) minmax(7.12443698rem, max-content) minmax(3.125rem, max-content) minmax(66.12940221rem, max-content) minmax(3.125rem, max-content);
      }

      #EVsnVfWBFziIwED4 {
        min-height: calc(calc(18.30607945 * var(--1vh, 1vh)) - 9.15303973px);
      }

      #Hdri1aIl6ToYC0vq {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #KJgycpXEEH2PHiBZ {
        grid-template-columns: 0 195.6048529%;
        left: -47.80242645%;
        grid-template-rows: 0 100%;
      }

      #APYUUhkfOlsktt4U {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.46875em - var(--ffsd)));
      }

      #MKY7BtHq4RLFEHWV {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.46875em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #EnWZ5NJ4wXZGyG1y {
        min-width: 93.79882812rem;
      }

      #YvCdtM9eTGVI7Fjj {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #XU61H5mU1Hegxyg1 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #EbMz9lWN05xkfKiu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.08333008em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #fTR14lQXntxrP3Id {
        min-width: 93.79882812rem;
      }

      #HshH9YO9PWARaZlp {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #miRUNBfS6pd7arzU {
        grid-area: 6 / 6 / 9 / 9;
        position: relative;
      }

      #nDTM1IrvTJqPqaWt {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #qJ34bvUj1ts5ONJ2 {
        grid-area: 7 / 5 / 10 / 8;
        grid-template-columns: 0 32.8837542rem;
        grid-template-rows: 0 minmax(42.44282599rem, max-content);
      }

      #CVKDDezLgdkzgo3I {
        grid-area: 7 / 5 / 10 / 8;
        position: relative;
      }

      #PrcyQ85wjjB0o08u {
        grid-area: 8 / 4 / 11 / 7;
        position: relative;
      }

      #vgwhkg6IqrGkge5w {
        grid-template-columns: 3.125rem 0 19.94914289rem 10.29361612rem 6.73885041rem 24.47930642rem 1.66559737rem 10.6743439rem 19.94914289rem 0 3.125rem;
        grid-template-rows: minmax(3.125rem, max-content) minmax(11.26742509rem, max-content) minmax(15.57291406rem, max-content) minmax(14.76910985rem, max-content) minmax(3.125rem, max-content) minmax(8.93779751rem, max-content) minmax(8.54001204rem, max-content) minmax(19.34143813rem, max-content) minmax(14.56137581rem, max-content) minmax(7.608959rem, max-content) minmax(3.125rem, max-content);
      }

      #FP4D4N6LhJJOZuGj {
        min-height: calc(calc(14.64264725 * var(--1vh, 1vh)) - 7.32132363px);
      }

      #Etajan3P94FrCZA7 {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #PD7rGfJaSv9ew4C8 {
        grid-template-columns: 0 320.1534076%;
        left: -110.0767038%;
        grid-template-rows: 0 100%;
      }

      #K7Wrp4f1lV4ES9FE {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.90625em - var(--ffsd)));
      }

      #wZeIsWv8ULwO9jcy {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.90625em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #p7ihhOMm87c0ACEa {
        min-width: 93.79882812rem;
      }

      #fPv2t7YHnuejKHcU {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #Tyc7EOWaz3bsR342 {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #WXwIL7gFzMa67DCC {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #n5X4InqHj6OYLYsu {
        display: block;
      }

      #XldIT6cLv2fBUqKe {
        display: none;
      }

      #p4FFndj20RBGut1m {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #tdVKy05DzOadvHGI {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.60102539em - var(--ffsd)));
      }

      #tTqGqp9n1v6v5uis {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.60102539em - var(--ffsd)));
      }

      #Y5EhKDSdHrHmGzgW {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.60102539em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #iheXlR99lIzXx0Ne {
        min-width: 28.47967422rem;
      }

      #M6hbY4UwnTeNWRUt {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #yChP2nRcxzL1YOTN {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271484em - var(--ffsd)));
      }

      #LMwFKqTE7AJ7lbir {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.69271484em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #gHR2fRPhXDM6Hisl {
        min-width: 28.47967422rem;
      }

      #aCErBJkmtBUolALX {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #d11L9LwwZabvIXmW {
        grid-template-columns: 0 2.45102818rem 0 28.43084609rem 0 2.45102818rem;
        grid-template-rows: 0 minmax(2.2076133rem, max-content) minmax(6.38052246rem, max-content) minmax(0.55506074rem, max-content) minmax(4.59635156rem, max-content) minmax(2.2076133rem, max-content);
      }

      #OUm9F4uUfkGg3Gls {
        grid-template-columns: 0 33.33290246rem;
        grid-template-rows: 0 minmax(15.94716137rem, max-content);
      }

      #QgEfIIzf18D8RQKM {
        grid-template-columns: 0 2.88917612rem 33.33290246rem 2.13363335rem;
        grid-template-rows: 0 minmax(32.90049488rem, max-content) minmax(15.94716137rem, max-content) minmax(2.734375rem, max-content);
      }

      #R4nH3NYK7paPPHzs {
        grid-area: 6 / 4 / 7 / 7;
        grid-template-columns: 0 38.35571193rem;
        grid-template-rows: 0 minmax(51.58203125rem, max-content);
      }

      #I86TgkNnnIdNV9mF {
        grid-area: 6 / 4 / 7 / 7;
        position: relative;
      }

      #BbzwfbFZPVrTIxUM {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #TpSjo6ksBYK1wmrg {
        display: block;
      }

      #Rb11CAnGbnPpu9vf {
        display: none;
      }

      #e2Ge0I5wUOeyD5zs {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #qyFXjYNNwMtVuZ89 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.60102125em - var(--ffsd)));
      }

      #rbiDzUNgYfDG2acu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.60102125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #AZjTU9md2ADPAc0F {
        min-width: 27.44917479rem;
      }

      #i0XTZt0u3J9l3l1i {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #U7tJjD7Uh5gDxwn4 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271484em - var(--ffsd)));
      }

      #Za9xwVDCXA2pliP5 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.69271484em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #m2XOjdNXKmHeAHwO {
        min-width: 27.44917479rem;
      }

      #kLVpIMZoli7sYzrB {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #m9LXQfrbEmJr2k5p {
        grid-template-columns: 0 2.9662779rem 0 27.40034666rem 0 2.9662779rem;
        grid-template-rows: 0 minmax(2.38196356rem, max-content) minmax(6.50057rem, max-content) minmax(0.55506074rem, max-content) minmax(4.12760352rem, max-content) minmax(2.38196356rem, max-content);
      }

      #hj6h0LScTtoij9rW {
        grid-template-columns: 0 33.33290246rem;
        grid-template-rows: 0 minmax(15.94716137rem, max-content);
      }

      #ufRvNwcU96kqYNf4 {
        grid-template-columns: 0 2.51140474rem 33.33290246rem 2.51140474rem;
        grid-template-rows: 0 minmax(32.90049488rem, max-content) minmax(15.94716137rem, max-content) minmax(2.734375rem, max-content);
      }

      #CENlSefUjhP6YW5b {
        grid-area: 8 / 5 / 9 / 8;
        grid-template-columns: 0 38.35571193rem;
        grid-template-rows: 0 minmax(51.58203125rem, max-content);
      }

      #eG3ccb8SJFeXwIvJ {
        grid-area: 8 / 5 / 9 / 8;
        position: relative;
      }

      #NWUTtg2IQDYEhSaQ {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #Au7GoA1EJkmz0gKh {
        display: block;
      }

      #nNIE5ZjGqDvYRj1d {
        display: none;
      }

      #s5HzwVAW1mrDp3Uf {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #HIij7OCEh7guCFzz {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.60102125em - var(--ffsd)));
      }

      #dH3MoNpEwXMeCUcv {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.60102125em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #cRBRg221gqzDGxvu {
        min-width: 29.40421058rem;
      }

      #FElht4Ltr4nzQ0gg {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #LD9IOLtK8K47oyj9 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271629em - var(--ffsd)));
      }

      #GW2f5b3rlSSixum7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.69271629em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ACpGnJk4cZWHjwN4 {
        min-width: 29.40421058rem;
      }

      #YHrHHD87BdlARGfK {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #aKAA6U6yEUFEdwiB {
        grid-template-columns: 0 1.98876rem 0 29.35538245rem 0 1.98876rem;
        grid-template-rows: 0 minmax(3.78754281rem, max-content) minmax(3.12023394rem, max-content) minmax(0.55506074rem, max-content) minmax(4.69678107rem, max-content) minmax(3.78754281rem, max-content);
      }

      #z0bY5zYMRsmxpb4L {
        grid-template-columns: 0 33.33290246rem;
        grid-template-rows: 0 minmax(15.94716137rem, max-content);
      }

      #u4z6oRNJ98jyVNor {
        grid-template-columns: 0 2.9118807rem 33.33290246rem 2.11092878rem;
        grid-template-rows: 0 minmax(32.90049488rem, max-content) minmax(15.94716137rem, max-content) minmax(2.734375rem, max-content);
      }

      #hb5jrqAkCXjZoTXa {
        grid-area: 10 / 6 / 11 / 9;
        grid-template-columns: 0 38.35571193rem;
        grid-template-rows: 0 minmax(51.58203125rem, max-content);
      }

      #xp0ymJ30yKJUmkXi {
        grid-area: 10 / 6 / 11 / 9;
        position: relative;
      }

      #ZMh7ecpl7smJEubs {
        grid-template-columns: 3.125rem 0 27.69714403rem 0 0 38.35571193rem 0 0 27.69714403rem 0 3.125rem;
        grid-template-rows: minmax(4.140625rem, max-content) minmax(4.6875rem, max-content) minmax(2.94921875rem, max-content) minmax(0.15465193rem, max-content) minmax(2.9296875rem, max-content) minmax(51.58203125rem, max-content) minmax(3.125rem, max-content) minmax(51.58203125rem, max-content) minmax(3.125rem, max-content) minmax(51.58203125rem, max-content) minmax(4.140625rem, max-content);
      }

      #ISVkDXmJFMnWiq1K {
        min-height: calc(calc(23.96614064 * var(--1vh, 1vh)) - 11.98307032px);
      }

      #LtN1C7EnSNQGg89z {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #N4Tpdpnf4HghJVjr {
        grid-template-columns: 0 320.1534076%;
        left: -110.0767038%;
        grid-template-rows: 0 100%;
      }

      #Vc6Z6VzhJe15nxoy {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.90625em - var(--ffsd)));
      }

      #Hiu5ffhXEx7BdDRZ {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.90625em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #QXoE2maBBoNIF7Gr {
        min-width: 93.79882812rem;
      }

      #SlLTi6O24aPK1PQQ {
        grid-area: 2 / 2 / 3 / 10;
        position: relative;
      }

      #D9nPJ3DqM8BwWaHM {
        grid-area: 4 / 3 / 5 / 11;
        position: relative;
      }

      #lq2ZDpzWZEJvBMiM {
        display: block;
      }

      #LgXgkEOX3zElrFEM {
        display: none;
      }

      #uxnqO6yERfC4d65D {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ubGMOqeL5rvOuMqQ {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #gNE1pDRPU0FmfvzJ {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #wcHvYwrDbIHCRtHO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #oNwbURniyG6xEZN2 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.08333008em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #OAAB3fohcFyLYSft {
        min-width: 29.54648125rem;
      }

      #XlYyt0aMHu1Zh0hp {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #l0Q2nbieDbtvDa4I {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271484em - var(--ffsd)));
      }

      #j2c6GpMXEM9JHQu4 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.69271484em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GWVsMHfr8l8cFrc7 {
        min-width: 29.54648125rem;
      }

      #vileu7dt6s5TvraX {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #PyIzu2Slr4qCZW4c {
        grid-area: 6 / 4 / 7 / 7;
        grid-template-columns: 0 3.92930037rem 0 0 0 10.40406773rem 2.7787232rem 16.31486219rem 0 4.92875844rem;
        grid-template-rows: 0 minmax(4.36787168rem, max-content) minmax(10.40402611rem, max-content) minmax(2.94043747rem, max-content) minmax(2.01337171rem, max-content) minmax(2.34375rem, max-content) minmax(19.08854297rem, max-content) minmax(2.36638187rem, max-content) minmax(1.95963281rem, max-content) minmax(6.09801663rem, max-content);
      }

      #hJKy6v7Y1BQEtWBw {
        grid-area: 6 / 4 / 7 / 7;
        position: relative;
      }

      #ModsPUuKGeM9aeoC {
        display: block;
      }

      #eNI74A7dmWLhXMfg {
        display: none;
      }

      #N0NNQ9InTrpLFoFR {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #sOnczf1YqVUavn4q {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #Yf9A5IFd1HPZngBl {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #M4C1SZ1Dl6JYZrrm {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #eBBSxU69aAaJ4t6i {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.08333008em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #JEKIMuTIrrslKJoY {
        min-width: 29.54648125rem;
      }

      #Dt47wVyMxkdPTXKu {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #RuZHIV0XOwBNQvFf {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271484em - var(--ffsd)));
      }

      #XXI3z3eivyRQNAXD {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.69271484em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #Vew8JRHgXiDhwtsA {
        min-width: 29.54648125rem;
      }

      #ZJOgMyCQ7FBapqor {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #hUZCKysgaRhWfkMd {
        grid-area: 8 / 5 / 9 / 8;
        grid-template-columns: 0 3.92930037rem 0 0 0 10.40406773rem 2.7787232rem 16.31486219rem 0 4.92875844rem;
        grid-template-rows: 0 minmax(4.36787168rem, max-content) minmax(10.40402611rem, max-content) minmax(2.94043747rem, max-content) minmax(2.01337171rem, max-content) minmax(2.34375rem, max-content) minmax(19.08854297rem, max-content) minmax(2.36638187rem, max-content) minmax(1.95963281rem, max-content) minmax(6.09801663rem, max-content);
      }

      #bqItE7RCLOyv9rrN {
        grid-area: 8 / 5 / 9 / 8;
        position: relative;
      }

      #Wtde72kg8M6YwcMA {
        display: block;
      }

      #Jxv0NPP6UQRhz5Ra {
        display: none;
      }

      #iv1XCKpdSVjuCBKU {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ipvxIQqPGKvdy7s9 {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #isn5BP7r5XUWo3JL {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #zhcztrpvjlWNbTYO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #rbYxOfI8KuLu319s {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.08333008em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ODcjk0rSbCDnbjOX {
        min-width: 29.54648125rem;
      }

      #xD3maSGoVQRNCD0N {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #YZ1r4ouyXW9PTI9P {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271484em - var(--ffsd)));
      }

      #JGJ5JB5Kl8VZt7jR {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.69271484em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #UZYC6WCZAEKCjxAv {
        min-width: 29.54648125rem;
      }

      #tA4Agi2rzuBW6JML {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #knf3b6c1mVzKA7au {
        grid-area: 10 / 6 / 11 / 9;
        grid-template-columns: 0 3.92930037rem 0 0 0 10.40406773rem 2.7787232rem 16.31486219rem 0 4.92875844rem;
        grid-template-rows: 0 minmax(4.36787168rem, max-content) minmax(10.40402611rem, max-content) minmax(2.94043747rem, max-content) minmax(2.01337171rem, max-content) minmax(2.34375rem, max-content) minmax(19.08854297rem, max-content) minmax(2.36638187rem, max-content) minmax(1.95963281rem, max-content) minmax(6.09801663rem, max-content);
      }

      #qlIn6bf0FR92TyfT {
        grid-area: 10 / 6 / 11 / 9;
        position: relative;
      }

      #Zmq1BcGFaKOW7N0J {
        grid-template-columns: 3.125rem 0 27.69714403rem 0 0 38.35571193rem 0 0 27.69714403rem 0 3.125rem;
        grid-template-rows: minmax(4.140625rem, max-content) minmax(4.6875rem, max-content) minmax(2.94921875rem, max-content) minmax(0.15465193rem, max-content) minmax(2.9296875rem, max-content) minmax(51.58203125rem, max-content) minmax(3.125rem, max-content) minmax(51.58203125rem, max-content) minmax(3.125rem, max-content) minmax(51.58203125rem, max-content) minmax(4.140625rem, max-content);
      }

      #X3JPx632LSRuAY4d {
        min-height: calc(calc(23.96614064 * var(--1vh, 1vh)) - 11.98307032px);
      }

      #uV27B7XrVHeA5mka {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #bKSg5iz4CZD3MEXc {
        grid-template-columns: 0 255.40242513%;
        left: -77.70121257%;
        grid-template-rows: 0 100%;
      }

      #pDpxDsQDp1eh8Yid {
        grid-area: 2 / 11 / 5 / 20;
        position: relative;
      }

      #OyIXdjM3gEFMIKYH {
        grid-area: 3 / 9 / 6 / 16;
        position: relative;
      }

      #VWb2tvwkmBFDR6r8 {
        grid-area: 4 / 8 / 7 / 14;
        position: relative;
      }

      #a8b72Yi8nQo6EntT {
        grid-area: 8 / 6 / 9 / 22;
        position: relative;
      }

      #Qjm9rz6trR5oVzQt {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(3.90625em - var(--ffsd)));
      }

      #FLP3ypFsLN95AyTg {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 3.90625em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #sidsPanTaL76AHlA {
        min-width: 67.84248642rem;
      }

      #oAq0aeW9KFVXZ7Ol {
        grid-area: 10 / 2 / 11 / 23;
        position: relative;
      }

      #ZIWGPoApdy9Md8YU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #DF38PgX5ER3v0xDS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #jS79BHcqfEGhnveX {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.08333008em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #s8r64iDJxPOiPqdH {
        min-width: 67.84248642rem;
      }

      #yrzJJM1VddXStANX {
        grid-area: 12 / 3 / 13 / 24;
        position: relative;
      }

      #Ow1SV5SYpmuU64gX {
        stroke-width: calc(100rem * 0.0 / 1024.0);
      }

      #nYFaUvsXej6k3ZQa {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #jNDmrDwxIvmpGN9F {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.69271484em - var(--ffsd)));
      }

      #kVcd73LgvxkUf0bx {
        min-width: 16.96243479rem;
      }

      #PN5xyZDAshLeTFyz {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #g7JO7hLJFbhZ1c9v {
        grid-template-columns: 0 0.390625rem 16.91360667rem 0.390625rem;
        grid-template-rows: 0 minmax(0.390625rem, max-content) minmax(6.34318698rem, max-content) minmax(0.390625rem, max-content);
      }

      #jgIuBGdbY9hcjJbj {
        grid-area: 14 / 4 / 15 / 10;
        grid-template-columns: 0 17.69485667rem;
        grid-template-rows: 0 minmax(7.12443698rem, max-content);
      }

      #sEi0F6sKr42V43mj {
        grid-area: 14 / 4 / 15 / 10;
        position: relative;
      }

      #xawZlBw7Vmw28g8w {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.60416016em - var(--ffsd)));
      }

      #Q0d3leswLFoaxkqp {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.60416016em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GMCPj7pxIpKa6v2U {
        min-width: 35.19137437rem;
      }

      #hEfrwSXCUQX7IVuh {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #Rip6GLXcR8q0Bv3O {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #X6cBRlpJnMGJ8lUF {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.08333008em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #G0hWTx60TFTxFnyH {
        min-width: 35.19137437rem;
      }

      #iFyTMSfwG0AnexMm {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #BsIWI3L6rLZJsXHH {
        grid-area: 16 / 5 / 17 / 12;
        grid-template-columns: 0 0 35.14254625rem 0;
        grid-template-rows: 0 minmax(3.05989844rem, max-content) minmax(1.82828744rem, max-content) minmax(2.48698047rem, max-content);
      }

      #UI1WPzmkLr6SI09n {
        grid-area: 16 / 5 / 17 / 12;
        position: relative;
      }

      #BulTesQwb287ByAX {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.60416016em - var(--ffsd)));
      }

      #REVB22uHW9WFoxrd {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.60416016em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #RXjFLQF0zPPTOKwG {
        min-width: 35.19137437rem;
      }

      #mib8cPgYCBfUFFU7 {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #QsOasINka3ohBBZU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.08333008em - var(--ffsd)));
      }

      #D7RzeGAGeAZleErO {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.08333008em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #hnj0691Mo6sEMsz5 {
        min-width: 35.19137437rem;
      }

      #kk7Z1uC5TO81GwEN {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #uTxlUG5z05FDAAjp {
        grid-area: 18 / 7 / 23 / 13;
        grid-template-columns: 0 0 35.14254625rem 0;
        grid-template-rows: 0 minmax(3.05989844rem, max-content) minmax(1.82828744rem, max-content) minmax(2.48698047rem, max-content);
      }

      #trJdXGuJZuetLsGr {
        grid-area: 18 / 7 / 23 / 13;
        position: relative;
      }

      #LmO7NTL7CdAkUEzX {
        grid-area: 19 / 15 / 24 / 17;
        position: relative;
      }

      #Oe9rFuo4wMmT4FAU {
        grid-area: 20 / 18 / 25 / 19;
        position: relative;
      }

      #rJN6GzljJ2SbfRbK {
        grid-area: 21 / 21 / 22 / 25;
        position: relative;
      }

      #vtG7myf9p3vyMZDR {
        grid-template-columns: 16.10317085rem 0 0 0 0.27447413rem 0 5.42925236rem 9.2341255rem 2.75700468rem 7.57582746rem 9.87186212rem 0.27447413rem 11.79847906rem 5.09605219rem 2.87362848rem 1.0129719rem 1.91115277rem 3.88660038rem 0.09402666rem 1.8887598rem 3.81496668rem 0 0 0 16.10317085rem;
        grid-template-rows: minmax(2.51042859rem, max-content) minmax(3.45570531rem, max-content) minmax(28.13666455rem, max-content) minmax(5.22687782rem, max-content) minmax(28.78489513rem, max-content) minmax(7.5rem, max-content) minmax(3.125rem, max-content) minmax(0.1953125rem, max-content) minmax(3.02734375rem, max-content) minmax(4.6875rem, max-content) minmax(1.43178181rem, max-content) minmax(5.80729297rem, max-content) minmax(2.94545368rem, max-content) minmax(7.12443698rem, max-content) minmax(17.32645424rem, max-content) minmax(7.37516635rem, max-content) minmax(5.04784137rem, max-content) minmax(3.48856597rem, max-content) 0 0 minmax(3.81496668rem, max-content) minmax(0.0716337rem, max-content) 0 0 minmax(2.51042859rem, max-content);
      }

      #U5lczSwYEnRk1Mt4 {
        min-height: calc(calc(19.11899201 * var(--1vh, 1vh)) - 9.559496px);
      }
    }

    @media (min-width: 1024.05px) {
      #m3SYDT9FKCM13HjP {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #llJYRpJEKd1IcIhk {
        grid-template-columns: 0 100%;
        grid-template-rows: 0 100%;
      }

      #r1EFlTFVXm2e0A3n {
        grid-area: 3 / 2 / 6 / 5;
        position: relative;
      }

      #TfH5lWrMgLRuuMdS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.80520498em - var(--ffsd)));
      }

      #SXuGeBBgCKw0Kry7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.80520498em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #YtRQL1tNQCJRcW5m {
        min-width: 7.61747346rem;
      }

      #MvKcRfpmrfune5AA {
        grid-area: 4 / 6 / 5 / 7;
        position: relative;
      }

      #jQOTOlXn1E4QD7ph {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(5.17324305em - var(--ffsd)));
      }

      #yTLbXVvBvrvkVFKM {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 5.17324305em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #kXL4EaoQAP8c1x5h {
        min-width: 32.7995155rem;
      }

      #UKdOD4U3PWwpTe0d {
        grid-area: 7 / 3 / 8 / 9;
        position: relative;
      }

      #Ta7XH3vixYn13PeA {
        stroke-width: calc(100rem * 0.0 / 1366.0);
      }

      #zP5Shnye9HLNIW3b {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #s8b51UQOMuly5AiR {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891654em - var(--ffsd)));
      }

      #wOCJaesTt6mgvpfr {
        min-width: 15.83240783rem;
      }

      #p0fSmdua70RtuE0X {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #haTF8OYQSfrQtohf {
        grid-template-columns: 0 0.29282577rem 15.7958046rem 0.29282577rem;
        grid-template-rows: 0 minmax(0.29282577rem, max-content) minmax(4.75506842rem, max-content) minmax(0.29282577rem, max-content);
      }

      #GmUp5asCngXTjcfw {
        grid-area: 9 / 4 / 10 / 8;
        grid-template-columns: 0 16.38145614rem;
        grid-template-rows: 0 minmax(5.34071996rem, max-content);
      }

      #tMAOrNb5A0aiK2Uu {
        grid-area: 9 / 4 / 10 / 8;
        position: relative;
      }

      #GEbfawZRSV21NOsR {
        grid-area: 2 / 10 / 11 / 11;
        position: relative;
      }

      #GvWlHEPhc7hdjMiF {
        grid-template-columns: 5.62225476rem 0 0 3.14667126rem 1.02512373rem 7.58087024rem 4.62879091rem 16.38145614rem 7.95384076rem 49.57284616rem 4.08814604rem;
        grid-template-rows: minmax(3.32485071rem, max-content) minmax(0.81017206rem, max-content) minmax(0.63870569rem, max-content) minmax(2.16208565rem, max-content) minmax(0.34587992rem, max-content) minmax(16.82762758rem, max-content) minmax(18.44802343rem, max-content) minmax(2.70222782rem, max-content) minmax(5.34071996rem, max-content) minmax(2.29740405rem, max-content) minmax(3.32485071rem, max-content);
      }

      #EVsnVfWBFziIwED4 {
        min-height: calc(calc(20 * var(--1vh, 1vh)) - 10px);
      }

      #Hdri1aIl6ToYC0vq {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #KJgycpXEEH2PHiBZ {
        grid-template-columns: 0 100%;
        grid-template-rows: 0 100%;
      }

      #APYUUhkfOlsktt4U {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(4.09956076em - var(--ffsd)));
      }

      #MKY7BtHq4RLFEHWV {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 4.09956076em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #EnWZ5NJ4wXZGyG1y {
        min-width: 40.37783104rem;
      }

      #YvCdtM9eTGVI7Fjj {
        grid-area: 2 / 2 / 6 / 4;
        position: relative;
      }

      #XU61H5mU1Hegxyg1 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #EbMz9lWN05xkfKiu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.56173499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #fTR14lQXntxrP3Id {
        min-width: 40.37783104rem;
      }

      #HshH9YO9PWARaZlp {
        grid-area: 7 / 3 / 11 / 5;
        position: relative;
      }

      #miRUNBfS6pd7arzU {
        grid-area: 3 / 8 / 8 / 11;
        position: relative;
      }

      #nDTM1IrvTJqPqaWt {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #qJ34bvUj1ts5ONJ2 {
        grid-area: 4 / 7 / 9 / 10;
        grid-template-columns: 0 24.65077913rem;
        grid-template-rows: 0 minmax(31.81658405rem, max-content);
      }

      #CVKDDezLgdkzgo3I {
        grid-area: 4 / 7 / 9 / 10;
        position: relative;
      }

      #PrcyQ85wjjB0o08u {
        grid-area: 5 / 6 / 10 / 9;
        position: relative;
      }

      #vgwhkg6IqrGkge5w {
        grid-template-columns: 5.62225476rem 0 40.34122782rem 0 8.96179505rem 7.71644429rem 5.05167117rem 18.3505196rem 1.24858836rem 8.00185077rem 4.70564817rem;
        grid-template-rows: minmax(5.62225476rem, max-content) 0 minmax(6.70007661rem, max-content) minmax(6.40188311rem, max-content) minmax(1.61253515rem, max-content) minmax(11.67398536rem, max-content) minmax(1.2124785rem, max-content) minmax(10.91570193rem, max-content) minmax(5.70393413rem, max-content) minmax(1.45534372rem, max-content) minmax(4.92435432rem, max-content);
      }

      #FP4D4N6LhJJOZuGj {
        min-height: calc(calc(20 * var(--1vh, 1vh)) - 10px);
      }

      #Etajan3P94FrCZA7 {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #PD7rGfJaSv9ew4C8 {
        grid-template-columns: 0 100%;
        grid-template-rows: 0 100%;
      }

      #K7Wrp4f1lV4ES9FE {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.92825769em - var(--ffsd)));
      }

      #wZeIsWv8ULwO9jcy {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.92825769em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #p7ihhOMm87c0ACEa {
        min-width: 50.15256278rem;
      }

      #fPv2t7YHnuejKHcU {
        grid-area: 2 / 2 / 3 / 7;
        position: relative;
      }

      #Tyc7EOWaz3bsR342 {
        grid-area: 4 / 3 / 5 / 10;
        position: relative;
      }

      #WXwIL7gFzMa67DCC {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #n5X4InqHj6OYLYsu {
        display: block;
      }

      #XldIT6cLv2fBUqKe {
        display: none;
      }

      #p4FFndj20RBGut1m {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #tdVKy05DzOadvHGI {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.94981698em - var(--ffsd)));
      }

      #tTqGqp9n1v6v5uis {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.94981698em - var(--ffsd)));
      }

      #Y5EhKDSdHrHmGzgW {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.94981698em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #iheXlR99lIzXx0Ne {
        min-width: 21.34933118rem;
      }

      #M6hbY4UwnTeNWRUt {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #yChP2nRcxzL1YOTN {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891654em - var(--ffsd)));
      }

      #LMwFKqTE7AJ7lbir {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.26891654em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #gHR2fRPhXDM6Hisl {
        min-width: 21.34933118rem;
      }

      #aCErBJkmtBUolALX {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #d11L9LwwZabvIXmW {
        grid-template-columns: 0 1.83760816rem 0 21.31272796rem 0 1.83713981rem;
        grid-template-rows: 0 minmax(1.65490192rem, max-content) minmax(4.78305637rem, max-content) minmax(0.41609239rem, max-content) minmax(3.44558126rem, max-content) minmax(1.65490192rem, max-content);
      }

      #OUm9F4uUfkGg3Gls {
        grid-template-columns: 0 24.98747593rem;
        grid-template-rows: 0 minmax(11.95453385rem, max-content);
      }

      #QgEfIIzf18D8RQKM {
        grid-template-columns: 0 2.16582456rem 24.98747593rem 1.59944404rem;
        grid-template-rows: 0 minmax(24.66332852rem, max-content) minmax(11.95453385rem, max-content) minmax(2.04978038rem, max-content);
      }

      #R4nH3NYK7paPPHzs {
        grid-area: 6 / 4 / 9 / 5;
        grid-template-columns: 0 28.75274452rem;
        grid-template-rows: 0 minmax(38.66764275rem, max-content);
      }

      #I86TgkNnnIdNV9mF {
        grid-area: 6 / 4 / 9 / 5;
        position: relative;
      }

      #BbzwfbFZPVrTIxUM {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #TpSjo6ksBYK1wmrg {
        display: block;
      }

      #Rb11CAnGbnPpu9vf {
        display: none;
      }

      #e2Ge0I5wUOeyD5zs {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #qyFXjYNNwMtVuZ89 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.94981388em - var(--ffsd)));
      }

      #rbiDzUNgYfDG2acu {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.94981388em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #AZjTU9md2ADPAc0F {
        min-width: 20.57683381rem;
      }

      #i0XTZt0u3J9l3l1i {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #U7tJjD7Uh5gDxwn4 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891654em - var(--ffsd)));
      }

      #Za9xwVDCXA2pliP5 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.26891654em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #m2XOjdNXKmHeAHwO {
        min-width: 20.57683381rem;
      }

      #kLVpIMZoli7sYzrB {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #m9LXQfrbEmJr2k5p {
        grid-template-columns: 0 2.22362267rem 0 20.54023059rem 0 2.22362267rem;
        grid-template-rows: 0 minmax(1.78560079rem, max-content) minmax(4.87304808rem, max-content) minmax(0.41609239rem, max-content) minmax(3.0941918rem, max-content) minmax(1.78560079rem, max-content);
      }

      #hj6h0LScTtoij9rW {
        grid-template-columns: 0 24.98747593rem;
        grid-template-rows: 0 minmax(11.95453385rem, max-content);
      }

      #ufRvNwcU96kqYNf4 {
        grid-template-columns: 0 1.8826343rem 24.98747593rem 1.8826343rem;
        grid-template-rows: 0 minmax(24.66332852rem, max-content) minmax(11.95453385rem, max-content) minmax(2.04978038rem, max-content);
      }

      #CENlSefUjhP6YW5b {
        grid-area: 7 / 6 / 10 / 8;
        grid-template-columns: 0 28.75274452rem;
        grid-template-rows: 0 minmax(38.66764275rem, max-content);
      }

      #eG3ccb8SJFeXwIvJ {
        grid-area: 7 / 6 / 10 / 8;
        position: relative;
      }

      #NWUTtg2IQDYEhSaQ {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #Au7GoA1EJkmz0gKh {
        display: block;
      }

      #nNIE5ZjGqDvYRj1d {
        display: none;
      }

      #s5HzwVAW1mrDp3Uf {
        grid-area: 2 / 2 / 7 / 7;
        position: relative;
      }

      #HIij7OCEh7guCFzz {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.94981388em - var(--ffsd)));
      }

      #dH3MoNpEwXMeCUcv {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.94981388em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.05);
        margin-bottom: calc(var(--last-font-size) * -0.05);
      }

      #cRBRg221gqzDGxvu {
        min-width: 22.04239504rem;
      }

      #FElht4Ltr4nzQ0gg {
        grid-area: 3 / 3 / 4 / 5;
        position: relative;
      }

      #LD9IOLtK8K47oyj9 {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891763em - var(--ffsd)));
      }

      #GW2f5b3rlSSixum7 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.26891763em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ACpGnJk4cZWHjwN4 {
        min-width: 22.04239504rem;
      }

      #YHrHHD87BdlARGfK {
        grid-area: 5 / 4 / 6 / 6;
        position: relative;
      }

      #aKAA6U6yEUFEdwiB {
        grid-template-columns: 0 1.49084205rem 0 22.00579182rem 0 1.49084205rem;
        grid-template-rows: 0 minmax(2.83927074rem, max-content) minmax(2.33903335rem, max-content) minmax(0.41609239rem, max-content) minmax(3.52086663rem, max-content) minmax(2.83927074rem, max-content);
      }

      #z0bY5zYMRsmxpb4L {
        grid-template-columns: 0 24.98747593rem;
        grid-template-rows: 0 minmax(11.95453385rem, max-content);
      }

      #u4z6oRNJ98jyVNor {
        grid-template-columns: 0 2.18284468rem 24.98747593rem 1.58242392rem;
        grid-template-rows: 0 minmax(24.66332852rem, max-content) minmax(11.95453385rem, max-content) minmax(2.04978038rem, max-content);
      }

      #hb5jrqAkCXjZoTXa {
        grid-area: 8 / 9 / 11 / 11;
        grid-template-columns: 0 28.75274452rem;
        grid-template-rows: 0 minmax(38.66764275rem, max-content);
      }

      #xp0ymJ30yKJUmkXi {
        grid-area: 8 / 9 / 11 / 11;
        position: relative;
      }

      #ZMh7ecpl7smJEubs {
        grid-template-columns: 5.62225476rem 0 0 28.75274452rem 1.24862846rem 20.11458657rem 8.63815795rem 1.24862846rem 28.75274452rem 0 5.62225476rem;
        grid-template-rows: minmax(3.86530015rem, max-content) minmax(3.51390922rem, max-content) minmax(2.21083455rem, max-content) minmax(0.14641288rem, max-content) minmax(2.19619327rem, max-content) 0 0 minmax(38.66764275rem, max-content) 0 0 minmax(5.62225476rem, max-content);
      }

      #ISVkDXmJFMnWiq1K {
        min-height: calc(calc(20 * var(--1vh, 1vh)) - 10px);
      }

      #LtN1C7EnSNQGg89z {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #N4Tpdpnf4HghJVjr {
        grid-template-columns: 0 100%;
        grid-template-rows: 0 100%;
      }

      #Vc6Z6VzhJe15nxoy {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.92825769em - var(--ffsd)));
      }

      #Hiu5ffhXEx7BdDRZ {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.92825769em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #QXoE2maBBoNIF7Gr {
        min-width: 50.15256278rem;
      }

      #SlLTi6O24aPK1PQQ {
        grid-area: 2 / 2 / 3 / 7;
        position: relative;
      }

      #D9nPJ3DqM8BwWaHM {
        grid-area: 4 / 3 / 5 / 10;
        position: relative;
      }

      #lq2ZDpzWZEJvBMiM {
        display: block;
      }

      #LgXgkEOX3zElrFEM {
        display: none;
      }

      #uxnqO6yERfC4d65D {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ubGMOqeL5rvOuMqQ {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #gNE1pDRPU0FmfvzJ {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #wcHvYwrDbIHCRtHO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #oNwbURniyG6xEZN2 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.56173499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #OAAB3fohcFyLYSft {
        min-width: 22.14904597rem;
      }

      #XlYyt0aMHu1Zh0hp {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #l0Q2nbieDbtvDa4I {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891654em - var(--ffsd)));
      }

      #j2c6GpMXEM9JHQu4 {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.26891654em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GWVsMHfr8l8cFrc7 {
        min-width: 22.14904597rem;
      }

      #vileu7dt6s5TvraX {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #PyIzu2Slr4qCZW4c {
        grid-area: 6 / 4 / 9 / 5;
        grid-template-columns: 0 2.94553703rem 0 0 0 7.79924257rem 2.0830253rem 12.23017488rem 0 3.69476475rem;
        grid-template-rows: 0 minmax(3.27430498rem, max-content) minmax(7.79921138rem, max-content) minmax(2.20425181rem, max-content) minmax(1.50929182rem, max-content) minmax(1.75695461rem, max-content) minmax(14.3094202rem, max-content) minmax(1.77392023rem, max-content) minmax(1.46900732rem, max-content) minmax(4.57128041rem, max-content);
      }

      #hJKy6v7Y1BQEtWBw {
        grid-area: 6 / 4 / 9 / 5;
        position: relative;
      }

      #ModsPUuKGeM9aeoC {
        display: block;
      }

      #eNI74A7dmWLhXMfg {
        display: none;
      }

      #N0NNQ9InTrpLFoFR {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #sOnczf1YqVUavn4q {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #Yf9A5IFd1HPZngBl {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #M4C1SZ1Dl6JYZrrm {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #eBBSxU69aAaJ4t6i {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.56173499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #JEKIMuTIrrslKJoY {
        min-width: 22.14904597rem;
      }

      #Dt47wVyMxkdPTXKu {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #RuZHIV0XOwBNQvFf {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891654em - var(--ffsd)));
      }

      #XXI3z3eivyRQNAXD {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.26891654em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #Vew8JRHgXiDhwtsA {
        min-width: 22.14904597rem;
      }

      #ZJOgMyCQ7FBapqor {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #hUZCKysgaRhWfkMd {
        grid-area: 7 / 6 / 10 / 8;
        grid-template-columns: 0 2.94553703rem 0 0 0 7.79924257rem 2.0830253rem 12.23017488rem 0 3.69476475rem;
        grid-template-rows: 0 minmax(3.27430498rem, max-content) minmax(7.79921138rem, max-content) minmax(2.20425181rem, max-content) minmax(1.50929182rem, max-content) minmax(1.75695461rem, max-content) minmax(14.3094202rem, max-content) minmax(1.77392023rem, max-content) minmax(1.46900732rem, max-content) minmax(4.57128041rem, max-content);
      }

      #bqItE7RCLOyv9rrN {
        grid-area: 7 / 6 / 10 / 8;
        position: relative;
      }

      #Wtde72kg8M6YwcMA {
        display: block;
      }

      #Jxv0NPP6UQRhz5Ra {
        display: none;
      }

      #iv1XCKpdSVjuCBKU {
        grid-area: 2 / 2 / 11 / 11;
        position: relative;
      }

      #ipvxIQqPGKvdy7s9 {
        grid-area: 3 / 3 / 4 / 7;
        position: relative;
      }

      #isn5BP7r5XUWo3JL {
        grid-area: 5 / 4 / 6 / 8;
        position: relative;
      }

      #zhcztrpvjlWNbTYO {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #rbYxOfI8KuLu319s {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.56173499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #ODcjk0rSbCDnbjOX {
        min-width: 22.14904597rem;
      }

      #xD3maSGoVQRNCD0N {
        grid-area: 7 / 5 / 8 / 9;
        position: relative;
      }

      #YZ1r4ouyXW9PTI9P {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891654em - var(--ffsd)));
      }

      #JGJ5JB5Kl8VZt7jR {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.26891654em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #UZYC6WCZAEKCjxAv {
        min-width: 22.14904597rem;
      }

      #tA4Agi2rzuBW6JML {
        grid-area: 9 / 6 / 10 / 10;
        position: relative;
      }

      #knf3b6c1mVzKA7au {
        grid-area: 8 / 9 / 11 / 11;
        grid-template-columns: 0 2.94553703rem 0 0 0 7.79924257rem 2.0830253rem 12.23017488rem 0 3.69476475rem;
        grid-template-rows: 0 minmax(3.27430498rem, max-content) minmax(7.79921138rem, max-content) minmax(2.20425181rem, max-content) minmax(1.50929182rem, max-content) minmax(1.75695461rem, max-content) minmax(14.3094202rem, max-content) minmax(1.77392023rem, max-content) minmax(1.46900732rem, max-content) minmax(4.57128041rem, max-content);
      }

      #qlIn6bf0FR92TyfT {
        grid-area: 8 / 9 / 11 / 11;
        position: relative;
      }

      #Zmq1BcGFaKOW7N0J {
        grid-template-columns: 5.62225476rem 0 0 28.75274452rem 1.24862846rem 20.11458657rem 8.63815795rem 1.24862846rem 28.75274452rem 0 5.62225476rem;
        grid-template-rows: minmax(3.86530015rem, max-content) minmax(3.51390922rem, max-content) minmax(2.21083455rem, max-content) minmax(0.14641288rem, max-content) minmax(2.19619327rem, max-content) 0 0 minmax(38.66764275rem, max-content) 0 0 minmax(5.62225476rem, max-content);
      }

      #X3JPx632LSRuAY4d {
        min-height: calc(calc(20 * var(--1vh, 1vh)) - 10px);
      }

      #uV27B7XrVHeA5mka {
        grid-area: 2 / 2 / 3 / 3;
        position: relative;
      }

      #bKSg5iz4CZD3MEXc {
        grid-template-columns: 0 100%;
        grid-template-rows: 0 100%;
      }

      #pDpxDsQDp1eh8Yid {
        grid-area: 2 / 4 / 13 / 7;
        position: relative;
      }

      #OyIXdjM3gEFMIKYH {
        grid-area: 4 / 3 / 21 / 6;
        position: relative;
      }

      #VWb2tvwkmBFDR6r8 {
        grid-area: 12 / 2 / 25 / 5;
        position: relative;
      }

      #a8b72Yi8nQo6EntT {
        grid-area: 3 / 12 / 5 / 24;
        position: relative;
      }

      #Qjm9rz6trR5oVzQt {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(2.92825769em - var(--ffsd)));
      }

      #FLP3ypFsLN95AyTg {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 2.92825769em);
        --last-font-size: var(--first-font-size);
        margin-top: 0;
        margin-bottom: 0;
      }

      #sidsPanTaL76AHlA {
        min-width: 36.67273058rem;
      }

      #oAq0aeW9KFVXZ7Ol {
        grid-area: 6 / 8 / 7 / 17;
        position: relative;
      }

      #ZIWGPoApdy9Md8YU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #DF38PgX5ER3v0xDS {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #jS79BHcqfEGhnveX {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.56173499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #s8r64iDJxPOiPqdH {
        min-width: 36.67273058rem;
      }

      #yrzJJM1VddXStANX {
        grid-area: 8 / 9 / 9 / 18;
        position: relative;
      }

      #Ow1SV5SYpmuU64gX {
        stroke-width: calc(100rem * 0.0 / 1366.0);
      }

      #nYFaUvsXej6k3ZQa {
        grid-area: 2 / 2 / 5 / 5;
        position: relative;
      }

      #jNDmrDwxIvmpGN9F {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.26891654em - var(--ffsd)));
      }

      #kVcd73LgvxkUf0bx {
        min-width: 12.7156173rem;
      }

      #PN5xyZDAshLeTFyz {
        grid-area: 3 / 3 / 4 / 4;
        position: relative;
      }

      #g7JO7hLJFbhZ1c9v {
        grid-template-columns: 0 0.29282577rem 12.67901407rem 0.29282577rem;
        grid-template-rows: 0 minmax(0.29282577rem, max-content) minmax(4.75506842rem, max-content) minmax(0.29282577rem, max-content);
      }

      #jgIuBGdbY9hcjJbj {
        grid-area: 10 / 10 / 11 / 14;
        grid-template-columns: 0 13.26466561rem;
        grid-template-rows: 0 minmax(5.34071996rem, max-content);
      }

      #sEi0F6sKr42V43mj {
        grid-area: 10 / 10 / 11 / 14;
        position: relative;
      }

      #xawZlBw7Vmw28g8w {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.95216691em - var(--ffsd)));
      }

      #Q0d3leswLFoaxkqp {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.95216691em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #GMCPj7pxIpKa6v2U {
        min-width: 26.3806496rem;
      }

      #hEfrwSXCUQX7IVuh {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #Rip6GLXcR8q0Bv3O {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #X6cBRlpJnMGJ8lUF {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.56173499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #G0hWTx60TFTxFnyH {
        min-width: 26.3806496rem;
      }

      #iFyTMSfwG0AnexMm {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #BsIWI3L6rLZJsXHH {
        grid-area: 14 / 11 / 15 / 15;
        grid-template-columns: 0 0 26.34404638rem 0;
        grid-template-rows: 0 minmax(2.29380381rem, max-content) minmax(1.37054637rem, max-content) minmax(1.86432504rem, max-content);
      }

      #UI1WPzmkLr6SI09n {
        grid-area: 14 / 11 / 15 / 15;
        position: relative;
      }

      #BulTesQwb287ByAX {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.95216691em - var(--ffsd)));
      }

      #REVB22uHW9WFoxrd {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.95216691em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #RXjFLQF0zPPTOKwG {
        min-width: 26.3806496rem;
      }

      #mib8cPgYCBfUFFU7 {
        grid-area: 2 / 2 / 3 / 4;
        position: relative;
      }

      #QsOasINka3ohBBZU {
        font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), calc(1.56173499em - var(--ffsd)));
      }

      #D7RzeGAGeAZleErO {
        --first-font-size: max(calc(12px * var(--rfso, var(--bfso, 1))), 1.56173499em);
        --last-font-size: var(--first-font-size);
        margin-top: calc(var(--first-font-size) * -0.2);
        margin-bottom: calc(var(--last-font-size) * -0.2);
      }

      #hnj0691Mo6sEMsz5 {
        min-width: 26.3806496rem;
      }

      #kk7Z1uC5TO81GwEN {
        grid-area: 4 / 3 / 5 / 5;
        position: relative;
      }

      #uTxlUG5z05FDAAjp {
        grid-area: 16 / 13 / 22 / 16;
        grid-template-columns: 0 0 26.34404638rem 0;
        grid-template-rows: 0 minmax(2.29380381rem, max-content) minmax(1.37054637rem, max-content) minmax(1.86432504rem, max-content);
      }

      #trJdXGuJZuetLsGr {
        grid-area: 16 / 13 / 22 / 16;
        position: relative;
      }

      #LmO7NTL7CdAkUEzX {
        grid-area: 17 / 19 / 23 / 20;
        position: relative;
      }

      #Oe9rFuo4wMmT4FAU {
        grid-area: 18 / 21 / 24 / 22;
        position: relative;
      }

      #rJN6GzljJ2SbfRbK {
        grid-area: 19 / 23 / 20 / 25;
        position: relative;
      }

      #vtG7myf9p3vyMZDR {
        grid-template-columns: 0 6.92221413rem 7.74584196rem 16.45057897rem 5.97434334rem 5.17603642rem 1.28830135rem 0 0 0 0.20575513rem 0 13.05891048rem 13.07938077rem 0.20575513rem 10.08632585rem 0 2.57838865rem 2.91352766rem 1.43266503rem 2.91352766rem 1.48636408rem 2.85982861rem 0 5.62225476rem;
        grid-template-rows: minmax(1.42119895rem, max-content) minmax(2.4441012rem, max-content) minmax(0.14641288rem, max-content) 0 minmax(2.26939971rem, max-content) minmax(3.51390922rem, max-content) minmax(1.07331228rem, max-content) minmax(4.35334407rem, max-content) minmax(2.20801213rem, max-content) minmax(5.34071996rem, max-content) minmax(2.33350212rem, max-content) minmax(3.91824516rem, max-content) minmax(6.73675137rem, max-content) minmax(5.52867521rem, max-content) minmax(3.78403336rem, max-content) minmax(2.61514755rem, max-content) 0 0 minmax(2.85982861rem, max-content) minmax(0.05369905rem, max-content) 0 0 0 minmax(5.62225476rem, max-content);
      }

      #U5lczSwYEnRk1Mt4 {
        min-height: calc(calc(20 * var(--1vh, 1vh)) - 10px);
      }
    }

    @keyframes baseline-RIGHT-3ba8ed2d-82ef-49e0-99fb-81eccb6c145b {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-711a1356-bd77-426d-a998-56148b6d771f {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-4d87794d-2ae3-4361-acfe-a934c8183f9f {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-b80b09ec-8cf7-4260-ad3c-74c4b5b7443a {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes fade-RIGHT-f6f0487e-e98a-4dd1-975a-e2696ed90e19 {
      0% {
        opacity: 0.0;
        animation-timing-function: cubic-bezier(0.4, 0.8, 0.74, 1.0);
      }

      100% {
        opacity: 1.0;
      }
    }

    @keyframes baseline-LEFT-88a79d67-68ae-4823-9e8b-c9960ec7c96b {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-73b8ea7e-ae1a-45ba-a73d-077df6f758e0 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-ec198788-5d57-4c78-b9fb-827d871b137d {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-24f045d6-76c3-4b29-96da-53c9d9c82380 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-5049b086-a75d-4e2f-80aa-072431e7d5ef {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-549a3e9f-69c5-4c40-9efc-df0eece31110 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-8b1230b5-c881-4e1c-abaa-d13ac86b77b5 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes fade-RIGHT-3509078e-876d-451a-a4ab-c96f891854b0 {
      0% {
        opacity: 0.0;
        animation-timing-function: cubic-bezier(0.4, 0.8, 0.74, 1.0);
      }

      100% {
        opacity: 1.0;
      }
    }

    @keyframes baseline-RIGHT-6022fc98-3986-4f77-b021-3a742e729d1b {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes pulse {
      0% {
        background-color: rgba(226, 226, 226, 0.05);
      }

      50% {
        background-color: rgba(226, 226, 226, 0.1);
      }

      100% {
        background-color: rgba(226, 226, 226, 0.05);
      }
    }

    @keyframes baseline-LEFT-570e43d2-858f-4638-b71d-657d9e6749a6 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes fade-RIGHT-64ff3dfd-5a66-46b2-89aa-49d3fc8b270a {
      0% {
        opacity: 0.0;
        animation-timing-function: cubic-bezier(0.4, 0.8, 0.74, 1.0);
      }

      100% {
        opacity: 1.0;
      }
    }

    @keyframes baseline-LEFT-0758ddc6-3f90-4be9-8a06-04fe37ad13f7 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-b27f0dc1-e512-41ae-aa04-7c235cf4ea13 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes linear_fade {
      0% {
        opacity: 0.0;
      }

      100% {
        opacity: 1.0;
      }
    }

    @keyframes baseline-LEFT-0715cb1e-a0fa-4e28-988d-29e24e1e5d17 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-71cfd0de-1ec7-4f3b-9552-e461662fd283 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-084f6c05-50e7-43f6-a5dd-df21fc0b066c {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-6828db0b-9142-40de-9214-8310b0db9d59 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-e65d2d17-1aa2-4978-8154-a7f2bd7b3783 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-56869f64-b13b-43a9-9da6-b732aae8b420 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-d216d269-091b-4cbd-8bf0-6f86c1a38581 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-0746dfe1-cf6b-4be9-aa82-818a11427791 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes fade-RIGHT-4f453e4c-45e3-4eeb-8e0b-6f44ac8e2479 {
      0% {
        opacity: 0.0;
        animation-timing-function: cubic-bezier(0.4, 0.8, 0.74, 1.0);
      }

      100% {
        opacity: 1.0;
      }
    }

    @keyframes baseline-RIGHT-cc727496-84e7-47ff-86d4-e599353963e8 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-dad5eb11-78fd-4c7f-9de8-27a17eb3aba8 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes fade-RIGHT-334585be-928e-46ce-892f-c9f5910e6e3c {
      0% {
        opacity: 0.0;
        animation-timing-function: cubic-bezier(0.4, 0.8, 0.74, 1.0);
      }

      100% {
        opacity: 1.0;
      }
    }

    @keyframes baseline-RIGHT-a064448e-fdcf-499c-a69c-0af10a7af100 {
      0% {
        transform: translate(100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-LEFT-34d66088-7f98-41d8-8b07-701f377b7904 {
      0% {
        transform: translate(-100%, 0%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-da8b7297-dc89-4b19-aad0-b270ca6e61f1 {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }

    @keyframes baseline-RIGHT-7d29ac74-bc18-4d0a-82b9-c1b81f0f190d {
      0% {
        transform: translate(0%, 100%);
        animation-timing-function: cubic-bezier(0.15, 1.03, 0.34, 0.99);
      }

      100% {
        transform: translate(0px, 0px);
      }
    }
  </style>
  <noscript>
    <style>
      @keyframes pulse {}

      .animated {
        animation-play-state: running !important;
      }
    </style>
  </noscript>
 
  <script nonce='11d22053-efc4-404b-a221-5710321243f0'>
    !function () { "use strict"; function t(t, n) { let e; return (...o) => { clearTimeout(e), e = setTimeout((() => { t(...o) }), n) } } class n { constructor() { this.callbacks = [], window.addEventListener("DOMContentLoaded", (() => this.onDOMContentLoaded())) } onDOMContentLoaded() { this.callbacks.sort(((t, n) => t.priority - n.priority)).forEach((({ callback: t }) => t())) } runOnLoad(t) { "loading" === document.readyState ? this.callbacks.push(t) : t.callback() } } function e(t, e = Number.MAX_VALUE) { var o; (window.canva_scriptExecutor = null !== (o = window.canva_scriptExecutor) && void 0 !== o ? o : new n).runOnLoad({ callback: t, priority: e }) } class o { constructor(t) { this.items = [], this.previousWidth = document.documentElement.clientWidth, this.previousHeight = window.innerHeight; const n = t((() => this.onWindowResize()), 100); window.addEventListener("resize", n) } onWindowResize() { const t = document.documentElement.clientWidth, n = window.innerHeight, e = this.previousWidth !== t, o = this.previousHeight !== n; this.items.forEach((t => { const n = () => { t.callback(), t.executed = !0 }; (!t.executed || e && t.options.runOnWidthChange || o && t.options.runOnHeightChange) && n() })), this.previousWidth = t, this.previousHeight = n } runOnResize(t, n) { this.items.push({ callback: t, options: n, executed: n.runOnLoad }), this.items.sort(((t, n) => t.options.priority - n.options.priority)), n.runOnLoad && e(t, n.priority) } } function i(n, e, i = t) { var r; (window.canva_debounceResize = null !== (r = window.canva_debounceResize) && void 0 !== r ? r : new o(i)).runOnResize(n, { runOnLoad: !1, runOnWidthChange: !0, runOnHeightChange: !1, priority: Number.MAX_VALUE, ...e }) } const r = "--minfs", c = "--rzf", a = "--rfso", s = "--bfso"; function u(t, n, e = .001) { return Math.abs(t - n) < e } function d(t, n) { return window.getComputedStyle(t).getPropertyValue(n) } function l(t, n, e) { t.style.setProperty(n, e) } function m(t, n) { const e = document.createElement("div"); e.style.setProperty(t, n), document.body.append(e); const o = d(e, t); return e.remove(), o } function f() { const t = function () { const t = parseFloat(m("font-size", "0.1px")); return t > 1 ? t : 0 }(), n = function (t) { const n = 2 * Math.max(t, 1); return n / parseFloat(m("font-size", `${n}px`)) }(t); if (function (t) { if (0 === t) return; l(document.documentElement, r, `${t}px`), i((() => { const n = 100 * t, { clientWidth: e } = document.documentElement; l(document.documentElement, c, n > e ? (e / n).toPrecision(4) : null) }), { runOnLoad: !0 }) }(t * Math.max(1, n)), u(n, 1)) return; const e = u(parseFloat(d(document.documentElement, "font-size")), parseFloat(m("grid-template-columns", "1rem"))); l(document.documentElement, e ? a : s, n.toPrecision(4)) } function h() { document.querySelectorAll("img, image, video, svg").forEach((t => t.addEventListener("contextmenu", (t => t.preventDefault())))) } const p = t => { const n = { type: "CLICKED_LINK", link: t.currentTarget.getAttribute("href") }; navigator.sendBeacon("_api/analytics/events", JSON.stringify(n)) }; function g() { [...document.querySelectorAll("a[href][data-interstitial-link]")].forEach((t => { t.addEventListener("click", p) })) } const v = "--sbw", w = "--inner1Vh"; function y(t, n, e) { t.style.setProperty(n, e) } function E() { y(document.documentElement, w, window.innerHeight / 100 + "px"), function () { const t = window.innerWidth - document.documentElement.clientWidth; y(document.documentElement, v, t >= 0 ? `${t}px` : null) }() } var b; const O = "undefined" != typeof window ? null === (b = window.navigator) || void 0 === b ? void 0 : b.userAgent : void 0; const L = !(!O || (A = O, !A.match(/AppleWebKit\//) || A.match(/Chrome\//) || A.match(/Chromium\//))); var A; function x() { document.querySelectorAll("svg").forEach((t => t.style.background = "url('data:image/png;base64,')")) } let C; function W() { C || (C = Array.from(document.querySelectorAll("foreignObject")).filter((t => 0 === t.getBoundingClientRect().width))); const t = function () { const t = document.createElement("div"); t.style.fontSize = "100vw", document.body.append(t); const n = parseFloat(window.getComputedStyle(t).fontSize); return t.remove(), n / window.innerWidth }(); Array.from(C).forEach((n => function (t) { return new Promise(((n, e) => { const o = t.querySelector("img"); o && !o.complete ? (o.addEventListener("load", (() => n())), o.addEventListener("error", (() => e()))) : n() })) }(n).finally((() => function (t, n) { const e = Array.from(t.children); e.forEach(((t, n) => { if (t.hasAttribute("data-foreign-object-container")) t.style.transformOrigin = "", t.style.transform = ""; else { const o = document.createElement("div"); o.setAttribute("data-foreign-object-container", ""), t.insertAdjacentElement("beforebegin", o), t.remove(), o.append(t), e[n] = o } })); const o = t.getScreenCTM(); if (!o) return; const { a: i, b: r, c: c, d: a } = o.scale(n); e.forEach((t => { if (!t.hasAttribute("data-foreign-object-container")) return; const { style: n } = t; n.transformOrigin = "0px 0px", n.transform = `matrix(${i}, ${r}, ${c}, ${a}, 0, 0)` })) }(n, t))))) } [function () { e(f) }, function () { i(E, { runOnLoad: !0, runOnHeightChange: !0, priority: 1 }) }, function () { L && i(W, { runOnLoad: !0 }) }, function () { L && e(x) }, function () { e(h) }, function () { e(g) }].forEach((t => t())) }();
  </script>
  <script nonce="11d22053-efc4-404b-a221-5710321243f0">
    window.C_CAPTCHA_IMPLEMENTATION = 'RECAPTCHA';
  </script>
  <script nonce="11d22053-efc4-404b-a221-5710321243f0">
    window.C_CAPTCHA_KEY = '6Ldk59waAAAAAMPqkICbJjfMivZLCGtTpa6Wn6zO';
  </script>

</head>

<body>
  <div id="root">
    
    <a id="page-1" aria-hidden="true" style="visibility:hidden;"></a>
    <section id="EVsnVfWBFziIwED4"
      style="position:relative;overflow:hidden;display:grid;align-items:center;grid-template-columns:auto 100rem auto;z-index:0;">
      
      <div id="llJYRpJEKd1IcIhk"
        style="grid-area:1 / 1 / 2 / 4;display:grid;position:absolute;min-height:100%;min-width:100%;">
        <div id="m3SYDT9FKCM13HjP" style="z-index:0;">
          <div id="nRTYZjiccwvK7Wdf" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
            <div id="bdrkdZ4ctzahlv69" style="width:100%;height:100%;opacity:1.0;">
              <div id="hVspxlTfqbpZayhX"
                style="background-color:#ffffff;opacity:1.0;transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                <div id="M7Kz7fDMiejzIq9i"
                  style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(118.57638889% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                  <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/10cce6aa2b52136c78413f2a3f929228.jpg" alt="Green Gradient" loading="lazy"
                    sizes="(max-width: 375px) 462.37715107vw, (min-width: 375.05px) and (max-width: 480px) 421.95244532vw, (min-width: 480.05px) and (max-width: 768px) 326.05743269vw, (min-width: 768.05px) and (max-width: 1024px) 244.54307452vw, (min-width: 1024.05px) 100vw"
                    style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 57.83308931%;transform:translate(-50%, -57.83308931%) rotate(0deg);">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div id="GvWlHEPhc7hdjMiF" style="display:grid;position:relative;grid-area:1 / 2 / 2 / 3;">
        <!-- Logo -->
        <div id="r1EFlTFVXm2e0A3n" style="display: none; z-index:4;">
          <div id="li4MJX9TfoFPk8fe" style="padding-top:100%;">
            <div id="yi9jNdRYuHQxFS0z" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
              <div class="animation_container" style="width:100%;height:100%;">
                <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                  <div class="animated"
                    style="width:100%;height:100%;animation:baseline-LEFT-570e43d2-858f-4638-b71d-657d9e6749a6 581ms 100ms both paused;">
                    <div id="A8teBQZA2zM7zHWV" style="width:100%;height:100%;opacity:1.0;">
                      <div id="O5NIyDq6xJPpsSUY"
                        style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                        <div style="display: none;" id="U4gmlGit7s9xIuGy"
                          style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                          <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/70bb7308d2c085bad8c94fcfb29d6601.svg"
                            alt="Abstract Geometric Square Lines Icon" loading="lazy"
                            style="width:100%;height:100%;display:NONE;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div id="MvKcRfpmrfune5AA" style="z-index:6;">
          <div id="YtRQL1tNQCJRcW5m" style="box-sizing:border-box;width:100%;height:100%;">
            <div class="animation_container" style="width:100%;height:100%;">
              <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                <div class="animated"
                  style="width:100%;height:100%;animation:baseline-LEFT-b80b09ec-8cf7-4260-ad3c-74c4b5b7443a 581ms 100ms both paused;">
                  <div id="SXuGeBBgCKw0Kry7"
                    style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                    <p id="TfH5lWrMgLRuuMdS"
                      style="color:#0c2323;font-family:YAFdJkmvhGI-0;line-height:1.29769537em;text-transform:uppercase;letter-spacing:0em;">
                      <span id="KXGSRrx2deotO3Sj" style="color:#0c2323;font-weight:700;">JOYALAS</span><br></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="UKdOD4U3PWwpTe0d" style="z-index:7;">
          <div id="kXL4EaoQAP8c1x5h" style="box-sizing:border-box;width:100%;height:100%;">
            <div class="animation_container" style="width:100%;height:100%;">
              <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                <div class="animated"
                  style="width:100%;height:100%;animation:baseline-LEFT-5049b086-a75d-4e2f-80aa-072431e7d5ef 581ms 100ms both paused;">
                  <div id="yTLbXVvBvrvkVFKM"
                    style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                    <p id="jQOTOlXn1E4QD7ph"
                      style="color:#0c2323;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.18868205em;text-align:left;text-transform:none;letter-spacing:0em;">
                      <span id="dDOlonmMGngqlKOb" style="text-decoration-line:none;color:#0c2323;">Bengkel Las Listrik Lampung</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="tMAOrNb5A0aiK2Uu">
          <div id="GmUp5asCngXTjcfw" style="display:grid;position:relative;">
            <div id="haTF8OYQSfrQtohf" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
              <div id="zP5Shnye9HLNIW3b" style="z-index:2;">
                <div id="jcEQs80qg1GpHXFW" style="box-sizing:border-box;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-LEFT-0746dfe1-cf6b-4be9-aa82-818a11427791 581ms 100ms both paused;">
                        <svg id="ge63zBjNhhP76Aep" viewBox="0 0 98.1528 32.0" preserveAspectRatio="none"
                          style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                          <g id="a5ODC9dNmTQPQahz" style="transform:scale(1, 1);">
                            <g id="k1B5xKjyDNjgkc3J" style="clip-path:url(#eGvoNu7lFmxY7CgC);">
                              <clippath id="eGvoNu7lFmxY7CgC">
                                <path
                                  d="M82.15279598,0 C90.98935146,0 98.15279598,7.16344404 98.15279598,16 C98.15279598,24.83655548 90.98935146,32 82.15279598,32 L16,32 C7.16344404,32 0,24.83655548 0,16 C0,7.16344404 7.16344404,0 16,0 Z">
                                </path>
                              </clippath>
                              <path id="wmRJ9FCfsOpaPbVd"
                                d="M82.15279598,0 C90.98935146,0 98.15279598,7.16344404 98.15279598,16 C98.15279598,24.83655548 90.98935146,32 82.15279598,32 L16,32 C7.16344404,32 0,24.83655548 0,16 C0,7.16344404 7.16344404,0 16,0 Z"
                                style="fill:#ffffff;opacity:1.0;"></path>
                              <path id="Ta7XH3vixYn13PeA"
                                d="M82.15279598,0 C90.98935146,0 98.15279598,7.16344404 98.15279598,16 C98.15279598,24.83655548 90.98935146,32 82.15279598,32 L16,32 C7.16344404,32 0,24.83655548 0,16 C0,7.16344404 7.16344404,0 16,0 Z"
                                style="fill:none;stroke-linecap:butt; vector-effect:non-scaling-stroke;stroke:#ffffff;">
                              </path>
                            </g>
                          </g>
                        </svg></div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="p0fSmdua70RtuE0X" style="z-index:3;">
                <div id="wOCJaesTt6mgvpfr" style="box-sizing:border-box;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-LEFT-34d66088-7f98-41d8-8b07-701f377b7904 581ms 100ms both paused;">
                        <div id="RTXwAwUfRJmOdW6L"
                          style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:center;width:100%;height:100%;">
                          <p id="s8b51UQOMuly5AiR"
                            style="color:#0c2323;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.26922589em;text-align:center;text-transform:uppercase;letter-spacing:0em;">
                            <a id="rf0mC2WX8nqskw5M" href="#page-5"
                              style="text-decoration-line:none;color:#0c2323;font-style:normal;font-weight:700;">Hubungi Kami</a></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="GEbfawZRSV21NOsR" style="z-index:5;">
          <div id="lNU3vVMqgzQ6txyr" style="padding-top:100%;">
            <div id="rSH0SnlShCrlNWEr" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
              <div class="animation_container" style="width:100%;height:100%;">
                <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                  <div class="animated"
                    style="width:100%;height:100%;animation:baseline-RIGHT-a064448e-fdcf-499c-a69c-0af10a7af100 500ms 100ms both paused;">
                    <svg id="UtXpffoiKyQ4ohKe" viewBox="0 0 500.0 500.0"
                      style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                      <g id="uXHjPD82QTGHyruW" style="transform:scale(1, 1);">
                        <foreignobject id="Ix4c9JbEyuZE7WeV" style="width:500px;height:500px;">
                          <div id="boy1VlpEgulvlT62"
                            style="clip-path:path(M450,500 L50,500 C22.39999962,500 0,477.60000038 0,450 L0,50 C0,22.39999962 22.39999962,0 50,0 L450,0 C477.60000038,0 500,22.39999962 500,50 L500,450 C500,477.6000061 477.6000061,500 450,500 Z);">
                            <div id="rtLrTeeHA50J2h3v" style="transform:scale(1, 1);transform-origin:250px 250px;"><img
                                src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/8772143f6bc1ef4b4299bdb41d924c16.jpg" alt="Smartphone on Black Background"
                                loading="lazy"
                                sizes="(max-width: 375px) 137.28580363vw, (min-width: 375.05px) and (max-width: 480px) 140.08755472vw, (min-width: 480.05px) and (max-width: 768px) 132.34151786vw, (min-width: 768.05px) and (max-width: 1024px) 99.2561384vw, (min-width: 1024.05px) 74.40577285vw"
                                style="transform:translate(-137.89627576px, 0px) rotate(0deg);transform-origin:375.23452158px 250px;width:750.46904315px;height:500px;display:block;opacity:1.0;object-fit:fill;">
                            </div>
                          </div>
                        </foreignobject>
                        <path id="cdZtSlYErVESlV7W"
                          d="M450,1.5 C476.70000076,1.5 498.5,23.29999924 498.5,50 L498.5,450 C498.5,476.70000076 476.70000076,498.5 450,498.5 L50,498.5 C23.29999924,498.5 1.5,476.70000076 1.5,450 L1.5,50 C1.5,23.29999924 23.29999924,1.5 50,1.5 L450,1.5 M450,0 L50,0 C22.39999962,0 0,22.39999962 0,50 L0,450 C0,477.60000038 22.39999962,500 50,500 L450,500 C477.60000038,500 500,477.60000038 500,450 L500,50 C500,22.39999962 477.6000061,0 450,0 Z"
                          style="fill:#64b289;opacity:1.0;"></path>
                      </g>
                    </svg></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <a id="page-2" aria-hidden="true" style="visibility:hidden;"></a>
    <section id="FP4D4N6LhJJOZuGj"
      style="position:relative;overflow:hidden;display:grid;align-items:center;grid-template-columns:auto 100rem auto;z-index:0;margin-top:-1px;">
      <div id="KJgycpXEEH2PHiBZ"
        style="grid-area:1 / 1 / 2 / 4;display:grid;position:absolute;min-height:100%;min-width:100%;">
        <div id="Hdri1aIl6ToYC0vq" style="z-index:0;">
          <div id="ILTYOAEgaCiaUISG" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
            <div id="UOELU4kwqKEkoWHo" style="width:100%;height:100%;opacity:1.0;">
              <div id="KPgvq3i5djCZN2JR"
                style="background-color:#0c2323;opacity:1.0;transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="vgwhkg6IqrGkge5w" style="display:grid;position:relative;grid-area:1 / 2 / 2 / 3;">
        <div id="YvCdtM9eTGVI7Fjj" style="z-index:5;">
          <div id="fTR14lQXntxrP3Id" style="box-sizing:border-box;width:100%;height:100%;">
            <div class="animation_container" style="width:100%;height:100%;">
              <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                <div class="animated"
                  style="width:100%;height:100%;animation:baseline-LEFT-0715cb1e-a0fa-4e28-988d-29e24e1e5d17 625ms 100ms both paused;">
                  <div id="EbMz9lWN05xkfKiu"
                    style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                    <div id="MKY7BtHq4RLFEHWV"
              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
              <p id="APYUUhkfOlsktt4U"
                style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.19642857em;text-align:left;text-transform:none;letter-spacing:0em;">
                <span id="n5TxTBNA9aZ114MC" style="text-decoration-line:none;color:#6dcd9a;">Tentang Kami</span></p>
            </div>
                    <p id="XU61H5mU1Hegxyg1"
                      style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-transform:none;letter-spacing:0em; margin-top: 2rem;">
                      <span id="lWY7Pbp1OwUmmD1J"
                        style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">Layanan jasa bengkel las listrik untuk kebutuhan aksesoris rumah, kantor, apartemen, dan fasilitas umum yang membutuhkan produk-produk besi dengan model tertentu.</span>
                        </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="HshH9YO9PWARaZlp" style="z-index:6;">
          <div id="fTR14lQXntxrP3Id" style="box-sizing:border-box;width:100%;height:100%;">
            <div class="animation_container" style="width:100%;height:100%;">
              <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                <div class="animated"
                  style="width:100%;height:100%;animation:baseline-LEFT-0715cb1e-a0fa-4e28-988d-29e24e1e5d17 625ms 100ms both paused;">
                  <div id="EbMz9lWN05xkfKiu"
                    style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                    <div id="MKY7BtHq4RLFEHWV"
              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
              <p id="APYUUhkfOlsktt4U"
                style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.19642857em;text-align:left;text-transform:none;letter-spacing:0em;">
            </div>
                    <p id="XU61H5mU1Hegxyg1"
                      style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-transform:none;letter-spacing:0em; margin-top: 2rem;">
                        <span>
                          Layanan Kami : <br>
                          Kanopi | Kerajinan Besi | Konstruksi Baja | Pintu Besi | Pintu Garasi | Pagar Besi | Railing Balkon | Railing Tangga | Tangga Besi | Teralis Jendela | Teralis Pintu
                        </span>
                        </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="miRUNBfS6pd7arzU" style="z-index:2;">
          <div id="h04pxlnQg2uuo5Vg" style="padding-top:100%;">
            <div id="RbidLBrqsqpAXYfd" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
              <div class="animation_container" style="width:100%;height:100%;">
                <div class="animated"
                  style="width:100%;height:100%;animation:fade-RIGHT-f6f0487e-e98a-4dd1-975a-e2696ed90e19 1063ms 100ms both paused;">
                  <div id="UCPUE6bGz0GtnbLZ" style="width:100%;height:100%;opacity:1.0;">
                    <div id="sNgEG6uCOrJsLWeb"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                      <div id="A5qiFyMMkKvSxEzE"
                        style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/abcf5707d76897e51261565014bba300.svg" alt="Lime Green Blur Circle Illustration"
                          loading="lazy"
                          style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="CVKDDezLgdkzgo3I">
          <div id="qJ34bvUj1ts5ONJ2" style="display:grid;position:relative;">
            <div id="nDTM1IrvTJqPqaWt" style="z-index:4;">
              <div id="w36mbvmJONV8n2Tq" style="padding-top:129.06928369%;">
                <div id="LzRrJSYAFSM0sQ0q" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-RIGHT-da8b7297-dc89-4b19-aad0-b270ca6e61f1 641ms 100ms both paused;">
                        <div id="bf0U3WY5E7tSY4Ni" style="width:100%;height:100%;opacity:1.0;">
                          <div id="agEgFGzBfMmTREDe"
                            style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                            <div id="OgegWNjXLIpmXnkv"
                              style="width:calc(104.77236571% * max(1, var(--scale-fill, 1)));height:calc(121.83908487% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                              <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/d8e6575845eefe965b4be6d9967951f8.jpg"
                                alt="Man Using Smartphone for Phone Call" loading="lazy"
                                sizes="(max-width: 375px) 58.51826797vw, (min-width: 375.05px) and (max-width: 480px) 59.71251833vw, (min-width: 480.05px) and (max-width: 768px) 45.93744961vw, (min-width: 768.05px) and (max-width: 1024px) 34.45308721vw, (min-width: 1024.05px) 25.82720446vw"
                                style="width:100%;height:100%;display:block;object-fit:cover;object-position:52.27749258% 46.14630773%;transform:translate(-52.27749258%, -46.14630773%) rotate(0deg);">
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="PrcyQ85wjjB0o08u" style="z-index:1;">
          <div id="Kjt48qtc5zY7i473" style="padding-top:100%;">
            <div id="KJLFzu8kqZZjJx8J" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
              <div class="animation_container" style="width:100%;height:100%;">
                <div class="animated"
                  style="width:100%;height:100%;animation:fade-RIGHT-3509078e-876d-451a-a4ab-c96f891854b0 1162ms 100ms both paused;">
                  <div id="JmeIAsIbSf1zEBjU" style="width:100%;height:100%;opacity:1.0;">
                    <div id="lEEBnGd1rpB0ChuT"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                      <div id="wWgTSGAmL5Uj4bAY"
                        style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/abcf5707d76897e51261565014bba300.svg" alt="Lime Green Blur Circle Illustration"
                          loading="lazy"
                          style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <a id="page-3" aria-hidden="true" style="visibility:hidden;"></a>
    <section id="ISVkDXmJFMnWiq1K"
      style="position:relative;overflow:hidden;display:grid;align-items:center;grid-template-columns:auto 100rem auto;z-index:0;margin-top:-1px;">
      <div id="PD7rGfJaSv9ew4C8"
        style="grid-area:1 / 1 / 2 / 4;display:grid;position:absolute;min-height:100%;min-width:100%;">
        <div id="Etajan3P94FrCZA7" style="z-index:0;">
          <div id="mXjZSmru0PHZxnER" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
            <div id="SdIzhHUTER7RfeR1" style="width:100%;height:100%;opacity:1.0;">
              <div id="Fj9JQkqdecoPsGMb"
                style="background-color:#ffffff;opacity:1.0;transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="ZMh7ecpl7smJEubs" style="display:grid;position:relative;grid-area:1 / 2 / 2 / 3;">
        <div id="fPv2t7YHnuejKHcU" style="z-index:3;">
          <div id="p7ihhOMm87c0ACEa" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
            <div id="wZeIsWv8ULwO9jcy"
              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
              <p id="K7Wrp4f1lV4ES9FE"
                style="color:#0c2323;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.2em;text-align:left;text-transform:none;letter-spacing:0em;">
                <span id="droPuimisw10ZsZo" style="text-decoration-line:none;color:#0c2323;">Layanan Bengkel Las</span>
              </p>
            </div>
          </div>
        </div>
        <div id="Tyc7EOWaz3bsR342" style="z-index:20;">
          <div id="b9yaKKK1TAYChMLk" style="padding-top:0.16496206%;transform:rotate(0deg);">
            <div id="H01tcgDxcsx2yOl6" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><svg
                id="Wky8XlKGtY9hRCLE" viewBox="0 0 1212.4 2.0" preserveAspectRatio="none"
                style="display:block;width:100%;height:100%;overflow:visible;opacity:1.0;min-height:1px;stroke:#0c2323;fill:#0c2323;background:url(%27data_image/png%3bbase64%2c%27.html);">
                <g id="AsLRLTEqYVmYpK5Y">
                  <path d="M0,1 L1212.4,1" style="fill:none;stroke-width:2px;stroke-linecap:butt;"></path>
                </g>
              </svg></div>
          </div>
        </div>
        <div id="I86TgkNnnIdNV9mF">
          <div id="R4nH3NYK7paPPHzs" style="display:grid;position:relative;">
            <div id="QgEfIIzf18D8RQKM" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
              <div id="WXwIL7gFzMa67DCC" style="z-index:5;">
                <div id="pPgeRfuTK86zicyF" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                  <div id="e81rW859EZxLVBs9" style="width:100%;height:100%;opacity:1.0;">
                    <div id="rtI32BEGnarn7sfo"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                      <div id="Id84KisLifTAkiur"
                        style="width:calc(201.85112301% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/6e30fbc6f6e436577625bfb3198d53d4.jpg" alt="Man Typing on Laptop" loading="lazy"
                          sizes="(max-width: 375px) 184.62649384vw, (min-width: 375.05px) and (max-width: 480px) 165.16572858vw, (min-width: 480.05px) and (max-width: 768px) 103.22858036vw, (min-width: 768.05px) and (max-width: 1024px) 77.42143527vw, (min-width: 1024.05px) 58.03773771vw"
                          style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="OUm9F4uUfkGg3Gls" style="display:grid;position:relative;grid-area:3 / 3 / 4 / 4;">
                <div id="d11L9LwwZabvIXmW" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
                  <div id="p4FFndj20RBGut1m" style="z-index:9;">
                    <div id="ZFnM5Fv9rPh6jTnf" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-LEFT-549a3e9f-69c5-4c40-9efc-df0eece31110 877ms 100ms both paused;">
                            <svg id="n5X4InqHj6OYLYsu" viewBox="0 0 75.9649 36.3432" preserveAspectRatio="none"
                              style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                              <g id="nfuQh04snon0H1Qp" style="transform:scale(1, 1);">
                                <path id="mAlF3LDebfVGZfx0"
                                  d="M2.22556295,0 L73.73931132,0 C74.32956731,0 74.89564796,0.23447828 75.31302197,0.6518523 75.73039599,1.06922631 75.96487427,1.63530696 75.96487427,2.22556295 L75.96487427,34.11763011 C75.96487426,35.34677458 74.96845579,36.34319305 73.73931132,36.34319305 L2.22556295,36.34319305 C0.99641847,36.34319305 0,35.34677458 0,34.11763011 L0,2.22556295 C0,0.99641847 0.99641847,0 2.22556295,0 Z"
                                  style="fill:#0c2323;opacity:1.0;"></path>
                              </g>
                            </svg><svg id="XldIT6cLv2fBUqKe" viewBox="0 0 65.6541 37.8924" preserveAspectRatio="none"
                              style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                              <g id="cy88xzcShasheruG" style="transform:scale(1, 1);">
                                <path id="ChX9JQov3wH0MTgX"
                                  d="M1.92348482,0 L63.73059843,0 C64.24073832,0 64.72998421,0.20265228 65.09070759,0.56337566 65.45143097,0.92409904 65.65408325,1.41334493 65.65408325,1.92348482 L65.65408325,35.96894834 C65.65408325,36.47908824 65.45143097,36.96833413 65.09070759,37.32905751 64.72998422,37.68978089 64.24073832,37.89243317 63.73059843,37.89243317 L1.92348482,37.89243317 C1.41334493,37.89243317 0.92409904,37.68978088 0.56337566,37.32905751 0.20265228,36.96833413 0,36.47908823 0,35.96894834 L0,1.92348482 C0,1.41334493 0.20265228,0.92409904 0.56337566,0.56337566 0.92409904,0.20265228 1.41334493,0 1.92348482,0 Z"
                                  style="fill:#0c2323;opacity:1.0;"></path>
                              </g>
                            </svg></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="M6hbY4UwnTeNWRUt" style="z-index:11;">
                    <div id="iheXlR99lIzXx0Ne" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-LEFT-e65d2d17-1aa2-4978-8154-a7f2bd7b3783 500ms 100ms both paused;">
                            <div id="Y5EhKDSdHrHmGzgW"
                              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                              <p id="tdVKy05DzOadvHGI"
                                style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.27653983em;text-align:center;text-transform:uppercase;letter-spacing:0em;">
                                <span id="SaO3WSabi5hJbb0M"
                                  style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:700;">Kanopi</span></p>
                              <p id="tTqGqp9n1v6v5uis"
                                style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.27653983em;text-align:center;text-transform:uppercase;letter-spacing:0em;">
                                <span id="iHKiDjoysVA05N1z"
                                  style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:700;"></span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="aCErBJkmtBUolALX" style="z-index:10;">
                    <div id="gHR2fRPhXDM6Hisl" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-LEFT-084f6c05-50e7-43f6-a5dd-df21fc0b066c 877ms 100ms both paused;">
                            <div id="LMwFKqTE7AJ7lbir"
                              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                              <p id="yChP2nRcxzL1YOTN"
                                style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768632em;text-align:center;text-transform:none;letter-spacing:0em;">
                                <span id="F7a4CCNjnpD2VzGW"
                                  style="text-decoration-line:none;color:#6dcd9a;font-weight:600;"></span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="eG3ccb8SJFeXwIvJ">
          <div id="CENlSefUjhP6YW5b" style="display:grid;position:relative;">
            <div id="ufRvNwcU96kqYNf4" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
              <div id="BbzwfbFZPVrTIxUM" style="z-index:7;">
                <div id="TewbkiL9EekwjmYH" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                  <div id="hsqE1GEJzWOv3wf6" style="width:100%;height:100%;opacity:1.0;">
                    <div id="uJm5IuvEGVtfpXVY"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                      <div id="Ig9kowCv4rCW9Tvh"
                        style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(111.6077585% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/4a7b04788eaf8c25104453ffc6a236b8.jpg"
                          alt="Man in White Dress Shirt and Black Tie" loading="lazy"
                          sizes="(max-width: 375px) 91.46666667vw, (min-width: 375.05px) and (max-width: 480px) 81.82551879vw, (min-width: 480.05px) and (max-width: 768px) 51.14094924vw, (min-width: 768.05px) and (max-width: 1024px) 38.35571193vw, (min-width: 1024.05px) 28.75274452vw"
                          style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="hj6h0LScTtoij9rW" style="display:grid;position:relative;grid-area:3 / 3 / 4 / 4;">
                <div id="m9LXQfrbEmJr2k5p" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
                  <div id="e2Ge0I5wUOeyD5zs" style="z-index:13;">
                    <div id="cAePwCvUdaM8zmBl" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-LEFT-88a79d67-68ae-4823-9e8b-c9960ec7c96b 877ms 100ms both paused;">
                            <svg id="TpSjo6ksBYK1wmrg" viewBox="0 0 75.9649 36.3432" preserveAspectRatio="none"
                              style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                              <g id="jbNXnw6s0QOQrEJc" style="transform:scale(1, 1);">
                                <path id="HXYrTyfgDKGmgAzX"
                                  d="M2.22556295,0 L73.73931132,0 C74.32956731,0 74.89564796,0.23447828 75.31302197,0.6518523 75.73039599,1.06922631 75.96487427,1.63530696 75.96487427,2.22556295 L75.96487427,34.11763011 C75.96487426,35.34677458 74.96845579,36.34319305 73.73931132,36.34319305 L2.22556295,36.34319305 C0.99641847,36.34319305 0,35.34677458 0,34.11763011 L0,2.22556295 C0,0.99641847 0.99641847,0 2.22556295,0 Z"
                                  style="fill:#0c2323;opacity:1.0;"></path>
                              </g>
                            </svg><svg id="Rb11CAnGbnPpu9vf" viewBox="0 0 65.6541 38.7857" preserveAspectRatio="none"
                              style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                              <g id="IJxLnl9hr7LuJjGB" style="transform:scale(1, 1);">
                                <path id="PLSsGVrOaCXlST6x"
                                  d="M1.92348482,0 L63.73059843,0 C64.24073832,0 64.72998421,0.20265228 65.09070759,0.56337566 65.45143097,0.92409904 65.65408325,1.41334493 65.65408325,1.92348482 L65.65408325,36.86226652 C65.65408325,37.37240641 65.45143097,37.8616523 65.09070759,38.22237568 64.72998421,38.58309906 64.24073832,38.78575134 63.73059843,38.78575134 L1.92348482,38.78575134 C1.41334493,38.78575134 0.92409904,38.58309906 0.56337566,38.22237568 0.20265228,37.86165231 0,37.37240641 0,36.86226652 L0,1.92348482 C0,1.41334493 0.20265228,0.92409904 0.56337566,0.56337566 0.92409904,0.20265228 1.41334493,0 1.92348482,0 Z"
                                  style="fill:#0c2323;opacity:1.0;"></path>
                              </g>
                            </svg></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="i0XTZt0u3J9l3l1i" style="z-index:15;">
                    <div id="AZjTU9md2ADPAc0F" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-RIGHT-d216d269-091b-4cbd-8bf0-6f86c1a38581 500ms 100ms both paused;">
                            <div id="rbiDzUNgYfDG2acu"
                              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                              <p id="qyFXjYNNwMtVuZ89"
                                style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.27654186em;text-align:center;text-transform:uppercase;letter-spacing:0em;">
                                <span id="O8Rt17QhFOotHXUr"
                                  style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:700;">PAGAR BESI</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="kLVpIMZoli7sYzrB" style="z-index:14;">
                    <div id="m2XOjdNXKmHeAHwO" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-RIGHT-ec198788-5d57-4c78-b9fb-827d871b137d 877ms 100ms both paused;">
                            <div id="Za9xwVDCXA2pliP5"
                              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                              <p id="U7tJjD7Uh5gDxwn4"
                                style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.26922589em;text-align:center;text-transform:none;letter-spacing:0em;">
                                <span id="GEd90RhUmJnW5YUO"
                                  style="text-decoration-line:none;color:#6dcd9a;font-weight:600;"></span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="xp0ymJ30yKJUmkXi">
          <div id="hb5jrqAkCXjZoTXa" style="display:grid;position:relative;">
            <div id="u4z6oRNJ98jyVNor" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
              <div id="NWUTtg2IQDYEhSaQ" style="z-index:2;">
                <div id="vvrHPmeJrEFRZVOI" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                  <div id="ajIHSxyd3dFXiDsl" style="width:100%;height:100%;opacity:1.0;">
                    <div id="vZKLwiLBDBBvUjCX"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                      <div id="EYe69RKy1O2YE64Q"
                        style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(111.6077585% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/fe28b7be48169de3679e28a8b9345a7d.jpg" alt="Smartphone on Black Background"
                          loading="lazy"
                          sizes="(max-width: 375px) 91.46666667vw, (min-width: 375.05px) and (max-width: 480px) 81.82551879vw, (min-width: 480.05px) and (max-width: 768px) 51.14094924vw, (min-width: 768.05px) and (max-width: 1024px) 38.35571193vw, (min-width: 1024.05px) 28.75274452vw"
                          style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="z0bY5zYMRsmxpb4L" style="display:grid;position:relative;grid-area:3 / 3 / 4 / 4;">
                <div id="aKAA6U6yEUFEdwiB" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
                  <div id="s5HzwVAW1mrDp3Uf" style="z-index:17;">
                    <div id="EyZAGx0lH5Vbltwf" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-RIGHT-4d87794d-2ae3-4361-acfe-a934c8183f9f 877ms 100ms both paused;">
                            <svg id="Au7GoA1EJkmz0gKh" viewBox="0 0 75.9649 36.3432" preserveAspectRatio="none"
                              style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                              <g id="CSr8DCOU8RZy632T" style="transform:scale(1, 1);">
                                <path id="uPwor8W9OBufE8GD"
                                  d="M2.22556295,0 L73.73931132,0 C74.32956731,0 74.89564796,0.23447828 75.31302197,0.6518523 75.73039599,1.06922631 75.96487427,1.63530696 75.96487427,2.22556295 L75.96487427,34.11763011 C75.96487426,35.34677458 74.96845579,36.34319305 73.73931132,36.34319305 L2.22556295,36.34319305 C0.99641847,36.34319305 0,35.34677458 0,34.11763011 L0,2.22556295 C0,0.99641847 0.99641847,0 2.22556295,0 Z"
                                  style="fill:#0c2323;opacity:1.0;"></path>
                              </g>
                            </svg><svg id="nNIE5ZjGqDvYRj1d" viewBox="0 0 65.6541 38.508" preserveAspectRatio="none"
                              style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                              <g id="GVBWsxrmagKIpzuS" style="transform:scale(1, 1);">
                                <path id="IGpG2pH6R8Z96gfZ"
                                  d="M1.92348482,0 L63.73059843,0 C64.24073832,0 64.72998421,0.20265228 65.09070759,0.56337566 65.45143097,0.92409904 65.65408325,1.41334493 65.65408325,1.92348482 L65.65408325,36.58454511 C65.65408325,37.09468501 65.45143097,37.5839309 65.09070759,37.94465428 64.72998422,38.30537766 64.24073832,38.50802994 63.73059843,38.50802994 L1.92348482,38.50802994 C1.41334493,38.50802994 0.92409904,38.30537766 0.56337566,37.94465428 0.20265228,37.5839309 0,37.094685 0,36.58454511 L0,1.92348482 C0,1.41334493 0.20265228,0.92409904 0.56337566,0.56337566 0.92409904,0.20265228 1.41334493,0 1.92348482,0 Z"
                                  style="fill:#0c2323;opacity:1.0;"></path>
                              </g>
                            </svg></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="FElht4Ltr4nzQ0gg" style="z-index:19; margin-top: -1rem;">
                    <div id="cRBRg221gqzDGxvu" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-RIGHT-6022fc98-3986-4f77-b021-3a742e729d1b 500ms 100ms both paused;">
                            <div id="dH3MoNpEwXMeCUcv"
                              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                              <p id="HIij7OCEh7guCFzz"
                                style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.27654186em;text-align:center;text-transform:uppercase;letter-spacing:0em;">
                                <span id="Kb2mdP0AF1hKuXk8"
                                  style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:700;">KERAJINAN BESI</span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="YHrHHD87BdlARGfK" style="z-index:18;">
                    <div id="ACpGnJk4cZWHjwN4" style="box-sizing:border-box;width:100%;height:100%;">
                      <div class="animation_container" style="width:100%;height:100%;">
                        <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                          <div class="animated"
                            style="width:100%;height:100%;animation:baseline-RIGHT-b27f0dc1-e512-41ae-aa04-7c235cf4ea13 877ms 100ms both paused;">
                            <div id="GW2f5b3rlSSixum7"
                              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                              <p id="LD9IOLtK8K47oyj9"
                                style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768499em;text-align:center;text-transform:none;letter-spacing:0em;">
                                <span id="abfftJN19OlhqRNX"
                                  style="text-decoration-line:none;color:#6dcd9a;font-weight:600;"></span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <a id="page-4" aria-hidden="true" style="visibility:hidden;"></a>
    <section id="X3JPx632LSRuAY4d"
      style="position:relative;overflow:hidden;display:grid;align-items:center;grid-template-columns:auto 100rem auto;z-index:0;margin-top:-1px;">
      <div id="N4Tpdpnf4HghJVjr"
        style="grid-area:1 / 1 / 2 / 4;display:grid;position:absolute;min-height:100%;min-width:100%;">
        <div id="LtN1C7EnSNQGg89z" style="z-index:0;">
          <div id="OddA5NqHMXcezghf" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
            <div id="V7YUnkAyTcCHIWOw" style="width:100%;height:100%;opacity:1.0;">
              <div id="ryvMG0Q99T3h27vR"
                style="background-color:#ffffff;opacity:1.0;transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="Zmq1BcGFaKOW7N0J" style="display:grid;position:relative;grid-area:1 / 2 / 2 / 3;">
        <div id="SlLTi6O24aPK1PQQ" style="z-index:17;">
          <div id="QXoE2maBBoNIF7Gr" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
            <div id="Hiu5ffhXEx7BdDRZ"
              style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
              <p id="Vc6Z6VzhJe15nxoy"
                style="color:#0c2323;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.2em;text-align:left;text-transform:none;letter-spacing:0em;">
                <span id="RaKQCTMbIOWQ4cai" style="color:#0c2323;">Mengapa Memilih Kami ?</span><br></p>
            </div>
          </div>
        </div>
        <div id="D9nPJ3DqM8BwWaHM" style="z-index:4;">
          <div id="lqTW6Qb4btRWHwdq" style="padding-top:0.16496206%;transform:rotate(0deg);">
            <div id="f2C0jRDaxfL2TNPR" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><svg
                id="rOkCiQKJqsD9WgCR" viewBox="0 0 1212.4 2.0" preserveAspectRatio="none"
                style="display:block;width:100%;height:100%;overflow:visible;opacity:1.0;min-height:1px;stroke:#0c2323;fill:#0c2323;background:url(%27data_image/png%3bbase64%2c%27.html);">
                <g id="ILLgiVi3SzRdfzWg">
                  <path d="M0,1 L1212.4,1" style="fill:none;stroke-width:2px;stroke-linecap:butt;"></path>
                </g>
              </svg></div>
          </div>
        </div>
        <div id="hJKy6v7Y1BQEtWBw">
          <div id="PyIzu2Slr4qCZW4c" style="display:grid;position:relative;">
            <div id="uxnqO6yERfC4d65D" style="z-index:1;">
              <div id="N804m7Bi4zQevqbJ" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <svg id="lq2ZDpzWZEJvBMiM" viewBox="0 0 87.4117 117.5542" preserveAspectRatio="none"
                  style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                  <g id="yAfhXAryPuSwFlUL" style="transform:scale(1, 1);">
                    <path id="xOfKDOTpATPiiRxZ"
                      d="M2.2255613,0 L85.18617423,0 C86.4153178,0 87.41173553,0.99641773 87.41173553,2.2255613 L87.41173553,115.32863791 C87.41173554,115.91889347 87.17725743,116.4849737 86.75988372,116.90234741 86.34251001,117.31972111 85.77642979,117.55419922 85.18617423,117.55419922 L2.2255613,117.55419922 C1.63530575,117.55419922 1.06922552,117.31972111 0.65185181,116.9023474 0.2344781,116.4849737 0,115.91889347 0,115.32863791 L0,2.2255613 C0,1.63530575 0.2344781,1.06922552 0.65185181,0.65185181 1.06922552,0.23447811 1.63530574,0 2.2255613,0 Z"
                      style="fill:#0c2323;opacity:1.0;"></path>
                  </g>
                </svg><svg id="LgXgkEOX3zElrFEM" viewBox="0 0 76.3368 121.775" preserveAspectRatio="none"
                  style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                  <g id="DtHHhgKkgm468OnQ" style="transform:scale(1, 1);">
                    <path id="EbzL7PX5CeyEQmrl"
                      d="M1.94358682,0 L74.39319754,0 C75.4666109,0 76.33678436,0.87017346 76.33678436,1.94358682 L76.33678436,119.83142996 C76.33678436,120.90484332 75.4666109,121.77501678 74.39319754,121.77501678 L1.94358682,121.77501678 C1.42811555,121.77501679 0.93375663,121.57024662 0.5692634,121.20575338 0.20477016,120.84126015 0,120.34690124 0,119.83142996 L0,1.94358682 C0,1.42811555 0.20477017,0.93375663 0.5692634,0.5692634 0.93375663,0.20477017 1.42811555,0 1.94358682,0 Z"
                      style="fill:#0c2323;opacity:1.0;"></path>
                  </g>
                </svg></div>
            </div>
            <div id="ubGMOqeL5rvOuMqQ" style="z-index:8;">
              <div id="lbExwOFcS4BLcago" style="padding-top:99.9996%;">
                <div id="hceffcBm1v5C3oWK" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-LEFT-0758ddc6-3f90-4be9-8a06-04fe37ad13f7 568ms 100ms both paused;">
                        <svg id="TqALdYaqnH8zJ8fo" viewBox="0 0 500.0 499.998"
                          style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                          <g id="tDXJI6ASidPY4lXT" style="transform:scale(1, 1);">
                            <foreignobject id="JVVPFON1QGktwdLJ" style="width:500px;height:499.998px;">
                              <div id="KsuvQqZJhQwUD1Nw"
                                style="clip-path:path(M500,250.0019989 C500,388.0670166 388.06900024,499.99801636 250,499.99801636 C111.92900085,499.99801636 0,388.0670166 0,250.0019989 C0,111.93000031 111.92900085,0 250,0 C388.0710144,0 500,111.93000031 500,250.0019989 Z);">
                                <div id="BNkLk9VJfLYATxES" style="transform:scale(1, 1);transform-origin:250px 250px;">
                                  <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/07ad9b84865c6b557880ce1a2897c469.svg"
                                    alt="A Happy Woman in a Sweater " loading="lazy"
                                    style="transform:translate(0px, -124.76677139px) rotate(0deg);transform-origin:250px 374.76577139px;width:500px;height:749.53154279px;display:block;opacity:1.0;object-fit:fill;">
                                </div>
                              </div>
                            </foreignobject>
                          </g>
                        </svg></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="gNE1pDRPU0FmfvzJ" style="z-index:5;">
              <div id="arh5HOM17lwlPh5f" style="padding-top:15.27272727%;transform:rotate(0deg);">
                <div id="i0E6yWtEI9t5133T" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
                  <div id="oFJrDcJVDn47SQyt" style="width:100%;height:100%;opacity:1.0;">
                    <div id="jPScOEfSdIviM9Rc"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative; display: none;">
                      <div id="w0pOZwaFBWCApVcm"
                        style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/ecbeddaed32d586a14533074461330a6.svg" alt="Testimonial Stars Icon"
                          loading="lazy"
                          style="width:100%;height:100%;display:none;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="XlYyt0aMHu1Zh0hp" style="z-index:14;">
              <div id="OAAB3fohcFyLYSft" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <div id="oNwbURniyG6xEZN2"
                  style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                  <p id="l0Q2nbieDbtvDa4I"
                    style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768632em;text-align:justify;text-transform:none;letter-spacing:0em;">
                    <span id="RNf5ospcMimRu0Gj" style="text-decoration-line:none;color:#6dcd9a;font-weight:600; font-size: 21px;">Harga Terjangkau</span></p>
                  <p id="wcHvYwrDbIHCRtHO"
                    style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-align:left;text-transform:none;letter-spacing:0em; margin-top: 1rem;">
                    <span id="q0iaos7tklGCbGLY"
                      style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">Kami memiliki layanan jasa las dengan harga yang terjangkau</span></p>
                </div>
              </div>
            </div>
            <div id="vileu7dt6s5TvraX" style="z-index:11; display: none;">
              <div id="GWVsMHfr8l8cFrc7" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <div id="j2c6GpMXEM9JHQu4"
                  style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                  <p id="l0Q2nbieDbtvDa4I"
                    style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768632em;text-align:justify;text-transform:none;letter-spacing:0em;">
                    <span id="RNf5ospcMimRu0Gj" style="text-decoration-line:none;color:#6dcd9a;font-weight:600;"></span></p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="bqItE7RCLOyv9rrN">
          <div id="hUZCKysgaRhWfkMd" style="display:grid;position:relative;">
            <div id="N0NNQ9InTrpLFoFR" style="z-index:2;">
              <div id="Lj9ax7PTVPLObYQU" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <svg id="ModsPUuKGeM9aeoC" viewBox="0 0 87.4117 117.5542" preserveAspectRatio="none"
                  style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                  <g id="q2XC6t4DIiPo9Gmr" style="transform:scale(1, 1);">
                    <path id="GQIwhi4f3OBLYKCf"
                      d="M2.2255613,0 L85.18617423,0 C86.4153178,0 87.41173553,0.99641773 87.41173553,2.2255613 L87.41173553,115.32863791 C87.41173554,115.91889347 87.17725743,116.4849737 86.75988372,116.90234741 86.34251001,117.31972111 85.77642979,117.55419922 85.18617423,117.55419922 L2.2255613,117.55419922 C1.63530575,117.55419922 1.06922552,117.31972111 0.65185181,116.9023474 0.2344781,116.4849737 0,115.91889347 0,115.32863791 L0,2.2255613 C0,1.63530575 0.2344781,1.06922552 0.65185181,0.65185181 1.06922552,0.23447811 1.63530574,0 2.2255613,0 Z"
                      style="fill:#0c2323;opacity:1.0;"></path>
                  </g>
                </svg><svg id="eNI74A7dmWLhXMfg" viewBox="0 0 76.3368 121.775" preserveAspectRatio="none"
                  style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                  <g id="qERS0B7BYAzTdMsS" style="transform:scale(1, 1);">
                    <path id="qUnNQtyTuxFFIHym"
                      d="M1.94358682,0 L74.39319754,0 C75.4666109,0 76.33678436,0.87017346 76.33678436,1.94358682 L76.33678436,119.83142996 C76.33678436,120.90484332 75.4666109,121.77501678 74.39319754,121.77501678 L1.94358682,121.77501678 C1.42811555,121.77501679 0.93375663,121.57024662 0.5692634,121.20575338 0.20477016,120.84126015 0,120.34690124 0,119.83142996 L0,1.94358682 C0,1.42811555 0.20477017,0.93375663 0.5692634,0.5692634 0.93375663,0.20477017 1.42811555,0 1.94358682,0 Z"
                      style="fill:#0c2323;opacity:1.0;"></path>
                  </g>
                </svg></div>
            </div>
            <div id="sOnczf1YqVUavn4q" style="z-index:9;">
              <div id="Vjo8IgHQsHsAhW56" style="padding-top:99.9996%;">
                <div id="FEIlWAkKHQL3cNe7" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-LEFT-dad5eb11-78fd-4c7f-9de8-27a17eb3aba8 568ms 100ms both paused;">
                        <svg id="w7V5auu1aZUPtIsz" viewBox="0 0 500.0 499.998"
                          style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                          <g id="sOmnF5oBbDELsaCj" style="transform:scale(1, 1);">
                            <foreignobject id="UXJJLQPEvCoojPft" style="width:500px;height:499.998px;">
                              <div id="tmjGLMunG28mH7yk"
                                style="clip-path:path(M500,250.0019989 C500,388.0670166 388.06900024,499.99801636 250,499.99801636 C111.92900085,499.99801636 0,388.0670166 0,250.0019989 C0,111.93000031 111.92900085,0 250,0 C388.0710144,0 500,111.93000031 500,250.0019989 Z);">
                                <div id="fQCSosmtn3xSqOGr" style="transform:scale(1, 1);transform-origin:250px 250px;">
                                  <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/4701afd44363185b01089031d3fc733c.svg"
                                    alt="Deaf Man Doing American Sign Language" loading="lazy"
                                    style="transform:translate(-124.53033708px, 0px) rotate(0deg);transform-origin:374.53033708px 249.999px;width:749.06067416px;height:499.998px;display:block;opacity:1.0;object-fit:fill;">
                                </div>
                              </div>
                            </foreignobject>
                          </g>
                        </svg></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="Yf9A5IFd1HPZngBl" style="z-index:6; display: none;">
              <div id="gUf2tluKz3LvVkla" style="padding-top:15.27272727%;transform:rotate(0deg);">
                <div id="EojMXYuJ9hYUCyct" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
                  <div id="XZ8EJe4SEKAFTSE8" style="width:100%;height:100%;opacity:1.0;">
                    <div id="VPlpWB6xQrbfSUy3"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                      <div id="d1hr0ENE6vmB6qad"
                        style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/ecbeddaed32d586a14533074461330a6.svg" alt="Testimonial Stars Icon"
                          loading="lazy"
                          style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="Dt47wVyMxkdPTXKu" style="z-index:15;">
              <div id="JEKIMuTIrrslKJoY" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <div id="eBBSxU69aAaJ4t6i"
                  style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                  <p id="l0Q2nbieDbtvDa4I"
                    style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768632em;text-align:justify;text-transform:none;letter-spacing:0em;">
                    <span id="RNf5ospcMimRu0Gj" style="text-decoration-line:none;color:#6dcd9a;font-weight:600; font-size: 21px;">Pemesanan Mudah</span></p>
                  <p id="M4C1SZ1Dl6JYZrrm"
                    style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-align:left;text-transform:none;letter-spacing:0em; margin-top: 1rem;">
                    <span id="tfvRvPLcDVcywhRA"
                      style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">Anda tak perlu khawatir lagi, karna memesan jasa bengkel las kami sangatlah mudah</span></p>
                </div>
              </div>
            </div>
            <div id="ZJOgMyCQ7FBapqor" style="z-index:12;">
              <div id="Vew8JRHgXiDhwtsA" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <div id="XXI3z3eivyRQNAXD"
                  style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                  <p id="RuZHIV0XOwBNQvFf"
                    style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768632em;text-align:justify;text-transform:none;letter-spacing:0em;">
                    <span id="fl9Tv5EUnXz34hwc" style="text-decoration-line:none;color:#6dcd9a;font-weight:600;"></span></p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="qlIn6bf0FR92TyfT">
          <div id="knf3b6c1mVzKA7au" style="display:grid;position:relative;">
            <div id="iv1XCKpdSVjuCBKU" style="z-index:3;">
              <div id="wcE65kkGQRN7fMQF" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <svg id="Wtde72kg8M6YwcMA" viewBox="0 0 87.4117 117.5542" preserveAspectRatio="none"
                  style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                  <g id="b11z0tDSiFzj7jWk" style="transform:scale(1, 1);">
                    <path id="To8GwzurzorF3S2U"
                      d="M2.2255613,0 L85.18617423,0 C86.4153178,0 87.41173553,0.99641773 87.41173553,2.2255613 L87.41173553,115.32863791 C87.41173554,115.91889347 87.17725743,116.4849737 86.75988372,116.90234741 86.34251001,117.31972111 85.77642979,117.55419922 85.18617423,117.55419922 L2.2255613,117.55419922 C1.63530575,117.55419922 1.06922552,117.31972111 0.65185181,116.9023474 0.2344781,116.4849737 0,115.91889347 0,115.32863791 L0,2.2255613 C0,1.63530575 0.2344781,1.06922552 0.65185181,0.65185181 1.06922552,0.23447811 1.63530574,0 2.2255613,0 Z"
                      style="fill:#0c2323;opacity:1.0;"></path>
                  </g>
                </svg><svg id="Jxv0NPP6UQRhz5Ra" viewBox="0 0 76.3368 121.775" preserveAspectRatio="none"
                  style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                  <g id="mXkLgMNavYv8sJui" style="transform:scale(1, 1);">
                    <path id="NSY8CAncAHhrEwnq"
                      d="M1.94358682,0 L74.39319754,0 C75.4666109,0 76.33678436,0.87017346 76.33678436,1.94358682 L76.33678436,119.83142996 C76.33678436,120.90484332 75.4666109,121.77501678 74.39319754,121.77501678 L1.94358682,121.77501678 C1.42811555,121.77501679 0.93375663,121.57024662 0.5692634,121.20575338 0.20477016,120.84126015 0,120.34690124 0,119.83142996 L0,1.94358682 C0,1.42811555 0.20477017,0.93375663 0.5692634,0.5692634 0.93375663,0.20477017 1.42811555,0 1.94358682,0 Z"
                      style="fill:#0c2323;opacity:1.0;"></path>
                  </g>
                </svg></div>
            </div>
            <div id="ipvxIQqPGKvdy7s9" style="z-index:10;">
              <div id="JK7u7AQbrTMyrIk4" style="padding-top:99.9996%;">
                <div id="gwbFlNsGHjmzvPUS" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-RIGHT-7d29ac74-bc18-4d0a-82b9-c1b81f0f190d 568ms 100ms both paused;">
                        <svg id="blucHrPqe6VCyBFA" viewBox="0 0 500.0 499.998"
                          style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                          <g id="b8BlHnf3aFYMZn7X" style="transform:scale(1, 1);">
                            <foreignobject id="pAxizfxW5yEXAR5Z" style="width:500px;height:499.998px;">
                              <div id="r9oEnDhYk2vPvdH5"
                                style="clip-path:path(M500,250.0019989 C500,388.0670166 388.06900024,499.99801636 250,499.99801636 C111.92900085,499.99801636 0,388.0670166 0,250.0019989 C0,111.93000031 111.92900085,0 250,0 C388.0710144,0 500,111.93000031 500,250.0019989 Z);">
                                <div id="G6Tw9nWqZghoEszi" style="transform:scale(1, 1);transform-origin:250px 250px;">
                                  <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/c2b8c634c072c4afe292a5c3f07acc2e.svg"
                                    alt="Business Portrait of Young Woman " loading="lazy"
                                    style="transform:translate(0px, -125.001px) rotate(0deg);transform-origin:250px 375px;width:500px;height:750px;display:block;opacity:1.0;object-fit:fill;">
                                </div>
                              </div>
                            </foreignobject>
                          </g>
                        </svg></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="isn5BP7r5XUWo3JL" style="z-index:7; display: none;">
              <div id="clQgkyVwzAQdbzNh" style="padding-top:15.27272727%;transform:rotate(0deg);">
                <div id="nlriZVtvtoHTYBYi" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
                  <div id="sYLVPeMrA8UgkGaZ" style="width:100%;height:100%;opacity:1.0;">
                    <div id="XN8B5xK0pmn8mr1K"
                      style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                      <div id="ktAoWaGX5J68CQBC"
                        style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                        <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/ecbeddaed32d586a14533074461330a6.svg" alt="Testimonial Stars Icon"
                          loading="lazy"
                          style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="xD3maSGoVQRNCD0N" style="z-index:16;">
              <div id="ODcjk0rSbCDnbjOX" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <div id="rbYxOfI8KuLu319s"
                  style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                  <p id="l0Q2nbieDbtvDa4I"
                    style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768632em;text-align:justify;text-transform:none;letter-spacing:0em;">
                    <span id="RNf5ospcMimRu0Gj" style="text-decoration-line:none;color:#6dcd9a;font-weight:600; font-size: 21px;">Pengerjaan Cepat</span></p>
                  <p id="zhcztrpvjlWNbTYO"
                    style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-align:left;text-transform:none;letter-spacing:0em; margin-top: 1rem;">
                    <span id="aoBgnddYmmKALO9a"
                      style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">Pengerjaan yang cepat tanpa menurunkan kualitas</span></p>
                </div>
              </div>
            </div>
            <div id="tA4Agi2rzuBW6JML" style="z-index:13;">
              <div id="UZYC6WCZAEKCjxAv" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
                <div id="JGJ5JB5Kl8VZt7jR"
                  style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                  <p id="YZ1r4ouyXW9PTI9P"
                    style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.55768632em;text-align:justify;text-transform:none;letter-spacing:0em;">
                    <span id="RhKrLl7lCpitCAxC" style="text-decoration-line:none;color:#6dcd9a;font-weight:600;"></span></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <a id="page-5" aria-hidden="true" style="visibility:hidden;"></a>
    <section id="U5lczSwYEnRk1Mt4"
      style="position:relative;overflow:hidden;display:grid;align-items:center;grid-template-columns:auto 100rem auto;z-index:0;margin-top:-1px;">
      <div id="bKSg5iz4CZD3MEXc"
        style="grid-area:1 / 1 / 2 / 4;display:grid;position:absolute;min-height:100%;min-width:100%;">
        <div id="uV27B7XrVHeA5mka" style="z-index:0;">
          <div id="qily9uvZZ6tu8wWA" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);">
            <div id="FVEsDhMk5RnBCbNo" style="width:100%;height:100%;opacity:1.0;">
              <div id="ZRSYiVHrXU2IS9gp"
                style="background-color:#0c2323;opacity:1.0;transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="vtG7myf9p3vyMZDR" style="display:grid;position:relative;grid-area:1 / 2 / 2 / 3;">
        <div id="pDpxDsQDp1eh8Yid" style="z-index:6;">
          <div id="Km9YSwIBdD5U8SMn" style="padding-top:100%;transform:rotate(0deg);">
            <div id="VtWOxcFPTAdcpqOd" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
              <div id="LJE70y0nATEDHVYf" style="width:100%;height:100%;opacity:1.0;">
                <div id="zl1CSAGHYrC0GEwG"
                  style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                  <div id="USjwAkjybZ1dx8WF"
                    style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                    <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/abcf5707d76897e51261565014bba300.svg" alt="Lime Green Blur Circle Illustration"
                      loading="lazy"
                      style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="OyIXdjM3gEFMIKYH" style="z-index:7;">
          <div id="dns3lhCUvwryh9vG" style="padding-top:154.41630636%;">
            <div id="DHmLfWpptbtQw7WV" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
              <div class="animation_container" style="width:100%;height:100%;">
                <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                  <div class="animated"
                    style="width:100%;height:100%;animation:baseline-LEFT-711a1356-bd77-426d-a998-56148b6d771f 500ms 100ms both paused;">
                    <svg id="hhTT6RqqMXKN1F02" viewBox="0 0 323.8 500.0"
                      style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                      <g id="HLlf7ASd8SMWhLEp" style="transform:scale(1, 1);">
                        <foreignobject id="h2eRmo3ShBpEOu52" style="width:323.8px;height:500px;">
                          <div id="dVr7YebZScDxBbiU"
                            style="clip-path:path(M323.79998779,49.09999847 L323.79998779,208 C323.79998779,222.19999695 317.59997559,235.69999695 306.8999939,245.1000061 C296.19998169,254.3999939 290,267.8999939 290,282.20001221 L290,450.8999939 C290,478 268,500 240.8999939,500 L49.09999847,500 C22,500 0,478 0,450.8999939 L0,49.09999847 C0,22 22,0 49.09999847,0 L274.79998779,0 C301.8999939,0 323.79998779,22 323.79998779,49.09999847 Z);">
                            <div id="ZN9YVmHs8wiL07uL" style="transform:scale(1, 1);transform-origin:162px 250px;"><img
                                src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/5451fe419274736ef0746ca1a5357026.jpg" alt="Smartphone with Camera Closeup"
                                loading="lazy"
                                sizes="(max-width: 375px) 151.22077422vw, (min-width: 375.05px) and (max-width: 480px) 154.30691247vw, (min-width: 480.05px) and (max-width: 768px) 124.296875vw, (min-width: 768.05px) and (max-width: 1024px) 93.22265625vw, (min-width: 1024.05px) 69.88286969vw"
                                style="transform:translate(-169.50710166px, 0px) rotate(0deg);transform-origin:375px 250px;width:750px;height:500px;display:block;opacity:1.0;object-fit:fill;">
                            </div>
                          </div>
                        </foreignobject>
                      </g>
                    </svg></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="VWb2tvwkmBFDR6r8" style="z-index:5;">
          <div id="YztXiuYhEviJZDxn" style="padding-top:100%;transform:rotate(0deg);">
            <div id="Kwb8HotE46ShbEVL" style="position:absolute;top:0px;left:0px;width:100%;height:100%;">
              <div id="LlpopzjrSkXqIeOA" style="width:100%;height:100%;opacity:1.0;">
                <div id="oeVwGFHYjY0dSXyR"
                  style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;">
                  <div id="dXwWa9IBwo33wgFb"
                    style="width:calc(100% * max(1, var(--scale-fill, 1)));height:calc(100% / min(1, var(--scale-fill, 1)));position:absolute;top:50%;left:50%;opacity:1.0;animation:pulse 1.5s ease-in-out infinite;">
                    <img src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/img/abcf5707d76897e51261565014bba300.svg" alt="Lime Green Blur Circle Illustration"
                      loading="lazy"
                      style="width:100%;height:100%;display:block;object-fit:cover;object-position:50% 50%;transform:translate(-50%, -50%) rotate(0deg);">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="a8b72Yi8nQo6EntT" style="z-index:1;">
          <div id="C1U3Urs9q4kWxh35" style="padding-top:0.28926964%;transform:rotate(0deg);">
            <div id="HfgEej3CCFI0syy9" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><svg
                id="ch0YnGfHFX5mkNCO" viewBox="0 0 691.396445912917 2.0" preserveAspectRatio="none"
                style="display:block;width:100%;height:100%;overflow:visible;opacity:1.0;min-height:1px;stroke:#6dcd9a;fill:#6dcd9a;background:url(%27data_image/png%3bbase64%2c%27.html);">
                <g id="lhQZYo9o5ujG2xXb">
                  <path d="M0,1 L691.39644591,1" style="fill:none;stroke-width:2px;stroke-linecap:butt;"></path>
                </g>
              </svg></div>
          </div>
        </div>
        <div id="oAq0aeW9KFVXZ7Ol" style="z-index:8;">
          <div id="sidsPanTaL76AHlA" style="box-sizing:border-box;width:100%;height:100%;">
            <div class="animation_container" style="width:100%;height:100%;">
              <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                <div class="animated"
                  style="width:100%;height:100%;animation:baseline-RIGHT-cc727496-84e7-47ff-86d4-e599353963e8 602ms 100ms both paused;">
                  <div id="FLP3ypFsLN95AyTg"
                    style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                    <p id="Qjm9rz6trR5oVzQt"
                      style="color:#6dcd9a;direction:ltr;font-family:YAFdJs2qTWQ-0;margin-left:0em;line-height:1.2em;text-transform:none;letter-spacing:0em;">
                      <span id="imfvJePsmRRZ7hLV" style="text-decoration-line:none;color:#6dcd9a;">Bagaimana Cara Menghubungi Kami ?</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="yrzJJM1VddXStANX" style="z-index:15;">
          <div id="s8r64iDJxPOiPqdH" style="box-sizing:border-box;width:100%;height:100%;">
            <div class="animation_container" style="width:100%;height:100%;">
              <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                <div class="animated"
                  style="width:100%;height:100%;animation:baseline-RIGHT-73b8ea7e-ae1a-45ba-a73d-077df6f758e0 602ms 100ms both paused;">
                  <div id="jS79BHcqfEGhnveX"
                    style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                    <p id="ZIWGPoApdy9Md8YU"
                      style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-transform:none;letter-spacing:0em;">
                      <span id="szlwrecU0ST0sJkM"
                        style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">Anda Bisa Menghubungi Kami</span></p>
                    <p id="DF38PgX5ER3v0xDS"
                      style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-transform:none;letter-spacing:0em;">
                      <span id="wWCXp8LO5pD4ufRB"
                        style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">Via Nomor Telepon Atau Via Whatsapp Berikut.</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="sEi0F6sKr42V43mj">
          <div id="jgIuBGdbY9hcjJbj" style="display:grid;position:relative;">
            <div id="g7JO7hLJFbhZ1c9v" style="display:grid;position:relative;grid-area:2 / 2 / 3 / 3;">
              <div id="nYFaUvsXej6k3ZQa" style="z-index:3;">
                <div id="Cr1AdXM8vNzPkb00" style="box-sizing:border-box;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-RIGHT-24f045d6-76c3-4b29-96da-53c9d9c82380 602ms 100ms both paused;">
                        <svg id="Zh7P9uXjiC5E0uhu" viewBox="0 0 79.4779 32.0" preserveAspectRatio="none"
                          style="width:100%;height:100%;opacity:1.0;overflow:hidden;position:absolute;top:0%;left:0%;background:url(%27data_image/png%3bbase64%2c%27.html);">
                          <g id="QMZiGzqt8EL3FH3Z" style="transform:scale(1, 1);">
                            <g id="srcRDi0KBOzKFYhF" style="clip-path:url(#luKYE377lq1CfxG0);">
                              <clippath id="luKYE377lq1CfxG0">
                                <path
                                  d="M63.47791737,0 C72.31447285,0 79.47791737,7.16344404 79.47791737,16 C79.47791737,24.83655548 72.31447285,32 63.47791737,32 L16,32 C7.16344404,32 0,24.83655548 0,16 C0,7.16344404 7.16344404,0 16,0 Z">
                                </path>
                              </clippath>
                              <path id="WMbERnE8hhvY0OZm"
                                d="M63.47791737,0 C72.31447285,0 79.47791737,7.16344404 79.47791737,16 C79.47791737,24.83655548 72.31447285,32 63.47791737,32 L16,32 C7.16344404,32 0,24.83655548 0,16 C0,7.16344404 7.16344404,0 16,0 Z"
                                style="fill:#ffffff;opacity:1.0;"></path>
                              <path id="Ow1SV5SYpmuU64gX"
                                d="M63.47791737,0 C72.31447285,0 79.47791737,7.16344404 79.47791737,16 C79.47791737,24.83655548 72.31447285,32 63.47791737,32 L16,32 C7.16344404,32 0,24.83655548 0,16 C0,7.16344404 7.16344404,0 16,0 Z"
                                style="fill:none;stroke-linecap:butt;vector-effect:non-scaling-stroke;stroke:#ffffff;">
                              </path>
                            </g>
                          </g>
                        </svg></div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="PN5xyZDAshLeTFyz" style="z-index:4;">
                <div id="kVcd73LgvxkUf0bx" style="box-sizing:border-box;width:100%;height:100%;">
                  <div class="animation_container" style="width:100%;height:100%;">
                    <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                      <div class="animated"
                        style="width:100%;height:100%;animation:baseline-RIGHT-6828db0b-9142-40de-9214-8310b0db9d59 602ms 100ms both paused;">
                        <div id="UIc6sWpxRzmmBM7s"
                          style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:center;width:100%;height:100%;">
                          <p id="jNDmrDwxIvmpGN9F"
                            style="color:#0c2323;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.26922589em;text-align:center;text-transform:uppercase;letter-spacing:0em;">
                            <a href="#" target="_blank" id="aAUW5k3tCMSwN8U6" style="color:#0c2323;font-weight:700;">WHATSAPPS</a><br></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="UI1WPzmkLr6SI09n">
          <div id="BsIWI3L6rLZJsXHH" style="display:grid;position:relative;">
            <div id="hEfrwSXCUQX7IVuh" style="z-index:11;">
              <div id="GMCPj7pxIpKa6v2U" style="box-sizing:border-box;width:100%;height:100%;">
                <div class="animation_container" style="width:100%;height:100%;">
                  <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                    <div class="animated"
                      style="width:100%;height:100%;animation:baseline-RIGHT-71cfd0de-1ec7-4f3b-9552-e461662fd283 602ms 100ms both paused;">
                      <div id="Q0d3leswLFoaxkqp"
                        style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                        <p id="xawZlBw7Vmw28g8w"
                          style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.57500394em;text-align:left;text-transform:none;letter-spacing:0em;">
                          <span id="NnbyEtMUiTau056y"
                            style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:700;">Phone</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="iFyTMSfwG0AnexMm" style="z-index:10;">
              <div id="G0hWTx60TFTxFnyH" style="box-sizing:border-box;width:100%;height:100%;">
                <div class="animation_container" style="width:100%;height:100%;">
                  <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                    <div class="animated"
                      style="width:100%;height:100%;animation:baseline-RIGHT-8b1230b5-c881-4e1c-abaa-d13ac86b77b5 602ms 100ms both paused;">
                      <div id="X6cBRlpJnMGJ8lUF"
                        style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                        <p id="Rip6GLXcR8q0Bv3O"
                          style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-align:left;text-transform:none;letter-spacing:0em;">
                          <span id="cUsuXKuzas6adX8i"
                            style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">(123)
                            456-7890</span></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="trJdXGuJZuetLsGr">
          <div id="uTxlUG5z05FDAAjp" style="display:grid;position:relative;">
            <div id="mib8cPgYCBfUFFU7" style="z-index:14;">
              <div id="RXjFLQF0zPPTOKwG" style="box-sizing:border-box;width:100%;height:100%;">
                <div class="animation_container" style="width:100%;height:100%;">
                  <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                    <div class="animated"
                      style="width:100%;height:100%;animation:baseline-RIGHT-3ba8ed2d-82ef-49e0-99fb-81eccb6c145b 602ms 100ms both paused;">
                      <div id="REVB22uHW9WFoxrd"
                        style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                        <p id="BulTesQwb287ByAX"
                          style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.57500394em;text-align:left;text-transform:none;letter-spacing:0em;">
                          <span id="reEFCc1V9dX7osij"
                            style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:700;">Alamat</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="kk7Z1uC5TO81GwEN" style="z-index:13;">
              <div id="hnj0691Mo6sEMsz5" style="box-sizing:border-box;width:100%;height:100%;">
                <div class="animation_container" style="width:100%;height:100%;">
                  <div style="width:100%;height:100%;transform:rotate(0deg);overflow:hidden;">
                    <div class="animated"
                      style="width:100%;height:100%;animation:baseline-RIGHT-56869f64-b13b-43a9-9da6-b732aae8b420 602ms 100ms both paused;">
                      <div id="D7RzeGAGeAZleErO"
                        style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;">
                        <p id="QsOasINka3ohBBZU"
                          style="color:#6dcd9a;direction:ltr;font-family:YADW1-vpsoc-0;margin-left:0em;line-height:1.59375249em;text-align:left;text-transform:none;letter-spacing:0em;">
                          <span id="XYuwoidwUK0ujWex"
                            style="text-decoration-line:none;color:#6dcd9a;font-style:normal;font-weight:400;">Jl. Salim Batubara, Kupang Teba, Kec. Tlk. Betung Utara, Kota Bandar Lampung, Lampung 35212 - Depan Travel Rama Tranz</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <div id="footer" style="background-color: #0c2323; color: #fff; padding: 2rem; display: flex; justify-content: space-between; flex-wrap: wrap;">
      <div style="margin: 2rem;" class="copyright"><span style="font-size: 1.2rem;">Copyright 2024 | <a href="https://joyalas.websidn.com" style="font-weight: bolder;">JOYALAS</a></span></div>
      <div style="margin: 2rem;" class="develoopment">
        <span style="font-size: 1.2rem;">Developer By | <a href="https://websidn.com" target="_blank" style="font-weight: bolder;">WEBSIDN</a> - <a href="https://newus.id" target="_blank" style="font-weight: bolder;">NEWUS TECHNOLOGY</a> </span>
      </div>
    </div>
    <style>
      @media (max-width:576px){
        #footer span{
          font-size: 3rem !important;
        }
      }  
    </style>

    <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/js/939898b427480d700449229ff00dbb8a6f9f77442b532f697866e6914ab8843a.js" async=""
      nonce="11d22053-efc4-404b-a221-5710321243f0"></script>
    <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/js/388fb330498371d4935abbff11d34d4c30842ca3c4a128cdd290d29db98acb41.js" async=""
      nonce="11d22053-efc4-404b-a221-5710321243f0"></script>
    <script src="<?php echo esc_url(get_template_directory_uri());  ?>/demo/joyalas/assets/js/781b7c2778641097cc201ef02652a4376abe12baf4b506965843770004e198e1.js" async=""
      nonce="11d22053-efc4-404b-a221-5710321243f0"></script>
  </div>

  <script nonce="11d22053-efc4-404b-a221-5710321243f0">
    const lang = navigator.language ? navigator.language : 'en';
    const loaded = new Promise((resolve) => {
      if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', resolve);
        return;
      }
      resolve();
    })
    Promise.all([fetch('_footer?lang=' + encodeURIComponent(lang)), loaded]).then(([response]) => {
      if (response.status !== 200) {
        return;
      }
      response.text().then(footerStr => {
        const div = document.createElement('div');
        div.innerHTML = footerStr;
        for (const child of [...div.children]) {
          if (child.tagName.toLowerCase() !== 'script') {
            document.body.append(child);
          }
        }

        (() => { !function (e) { "use strict"; const t = document.getElementById("modal_backdrop"), n = document.getElementById("modal"), o = document.getElementById("captcha-form"), c = document.getElementById("report_button"), d = document.getElementById("form_report"), s = document.getElementById("form_cancel"), l = document.getElementById("form_submit_reason"), a = document.getElementById("form_go_back"), r = document.getElementById("form_submit_captcha"), m = document.getElementById("form_close"), i = document.getElementById("form_close_initial"), u = document.getElementById("report_reason_0"), p = document.getElementById("error_message"), _ = document.getElementById("error_message_captcha"), y = new Map; y.set(0, document.getElementById("form_step_terms")), y.set(1, document.getElementById("form_step_report_reason")), y.set(4, document.getElementById("form_step_report_other")); const E = document.getElementById("form_step_report_ip"); E && y.set(5, E), y.set(2, document.getElementById("form_step_captcha")), y.set(3, document.getElementById("form_step_success")); const f = document.getElementById("report_reason_4"), g = document.getElementById("form_close_ip"), h = document.getElementById("form_go_back_ip"), I = document.getElementById("report_reason_other"), k = document.getElementById("form_close_other"), w = document.getElementById("form_go_back_other"); function v() { t.classList.remove("active"), n.classList.remove("active"), c.classList.remove("active"), c.focus() } function B(e) { y.forEach(((t, n) => { n === e ? (t.style.display = "block", L(t)) : t.style.display = "none" })) } let b, C = !1; const T = "NETEASE" === window.C_CAPTCHA_IMPLEMENTATION ? () => b : () => { const e = o.elements.namedItem("g-recaptcha-response"); return null == e ? void 0 : e.value }; t.onclick = v, s.onclick = v, m.onclick = v, i.onclick = v, g && (g.onclick = v), k.onclick = v, c.onclick = function () { y.forEach(((e, t) => { e.style.display = 0 === t ? "block" : "none" })), t.classList.add("active"), n.classList.add("active"), c.classList.add("active"), u.checked = !0, setTimeout((() => { L(y.get(0)) }), 350) }, d.onclick = d.dataset.reportUrl ? function () { const { origin: e, pathname: t } = window.location, n = e + t, o = d.dataset.reportUrl + encodeURIComponent(n); window.open(o) } : () => B(1), l.onclick = () => { null != E && f.checked ? B(5) : I.checked ? B(4) : (B(2), function () { if (C) return; const e = document.createElement("script"); e.src = "NETEASE" === window.C_CAPTCHA_IMPLEMENTATION ? "https://cstaticdun.126.net/load.min.js" : "https://www.google.com/recaptcha/api.js", e.async = !0, e.defer = !0, document.head.appendChild(e), C = !0, e.onload = "NETEASE" === window.C_CAPTCHA_IMPLEMENTATION ? () => { var e; null === (e = window.initNECaptcha) || void 0 === e || e.call(window, { captchaId: window.C_CAPTCHA_KEY, element: "#netease-captcha", protocol: "https", width: "auto", onVerify: (e, t) => { b = t.validate } }) } : () => { } }()) }, a.onclick = () => B(1), h && (h.onclick = () => B(1)), w.onclick = () => B(1), o.addEventListener("submit", (function (e) { e.preventDefault(), p.style.display = "none", _.style.display = "none"; const t = function () { let e = ""; const t = document.getElementsByName("report_reason"); for (let n = 0; n < t.length; n++) { const o = t[n]; o.checked && (e = o.value) } return e }(), n = T(); if (!n) return void (_.style.display = "block"); const o = { reason: t, challenge: n }, c = window.location.origin + window.location.pathname + "/_api/report"; r.classList.add("loading"), fetch(c, { method: "POST", body: JSON.stringify(o), headers: { "Content-Type": "application/json; charset=utf-8" } }).then((e => { r.classList.remove("loading"), e.ok ? B(3) : p.style.display = "block" })) })); const A = new Map, L = e => { const t = A.get(e); null != t && document.removeEventListener("keydown", t); const n = e.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'), o = e, c = n[n.length - 1], d = function (e) { ("Tab" === e.key || 9 === e.keyCode) && (e.shiftKey ? document.activeElement === o && (c.focus(), e.preventDefault()) : document.activeElement === c && (o.focus(), e.preventDefault())) }; A.set(e, d), document.addEventListener("keydown", d), o.focus() }; e.keepFocus = L, Object.defineProperty(e, "__esModule", { value: !0 }) }({}); })();
        window.dispatchEvent(new Event('resize'));
      });
    });
  </script>

</body>

</html>
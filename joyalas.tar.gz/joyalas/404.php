<?php
/**
 * Template Name: 404
 * 
 */
?>

<script>
    window.location.href = "<?= site_url('') ?>";
</script>